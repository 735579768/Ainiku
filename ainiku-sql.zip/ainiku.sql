/*
Navicat MySQL Data Transfer

Source Server         : conn
Source Server Version : 50160
Source Host           : localhost:3306
Source Database       : ainiku

Target Server Type    : MYSQL
Target Server Version : 50160
File Encoding         : 65001

Date: 2015-12-15 16:51:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for kl_addons
-- ----------------------------
DROP TABLE IF EXISTS `kl_addons`;
CREATE TABLE `kl_addons` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(50) DEFAULT NULL,
  `mark` char(50) DEFAULT NULL,
  `version` char(50) DEFAULT NULL,
  `author` char(50) DEFAULT NULL,
  `descr` varchar(255) DEFAULT NULL,
  `install` tinyint(1) NOT NULL DEFAULT '1',
  `param` text,
  `type` char(50) DEFAULT 'other',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_addons
-- ----------------------------
INSERT INTO `kl_addons` VALUES ('4', '系统信息', 'AdminInfo', '1.0', 'qiaokeli', '插件描述', '1', null, 'system', '1');
INSERT INTO `kl_addons` VALUES ('6', 'HTML编辑器', 'Editor', '4.1.7', 'qiaokeli', 'Editor', '1', '{\"edittype\":\"1\"}', 'system', '1');
INSERT INTO `kl_addons` VALUES ('7', '系统内容信息', 'ConInfo', '1.0', 'qiaokeli', '插件描述', '1', null, 'system', '1');
INSERT INTO `kl_addons` VALUES ('33', '留言插件', 'Comments', '1.0', 'qiaokeli', '留言', '1', '{\"update_time\":1450167937,\"name\":\"\",\"email\":\"\",\"url\":\"\"}', 'other', '1');
INSERT INTO `kl_addons` VALUES ('39', '二维码', 'Erweima', '1.0', 'qiaokeli', '生成二维码', '1', null, 'other', '1');
INSERT INTO `kl_addons` VALUES ('25', '系统路径信息', 'PathInfo', '1.0', 'qiaokeli', '系统路径信息', '1', null, 'system', '1');
INSERT INTO `kl_addons` VALUES ('24', '访问流量', 'Chart', '1.0', 'qiaokeli', '流量分析图表', '1', null, 'system', '1');
INSERT INTO `kl_addons` VALUES ('26', '关于我们', 'About', '1.0', 'qiaokeli', '企业信息', '1', null, 'system', '1');
INSERT INTO `kl_addons` VALUES ('27', 'QQ登陆', 'Qlogin', '1.0', 'qiaokeli', 'QQ互联', '1', null, 'other', '1');
INSERT INTO `kl_addons` VALUES ('38', 'excel导入', 'Phpexcel', '1.0', 'qiaokeli', 'excel导入工具', '1', null, 'other', '1');
INSERT INTO `kl_addons` VALUES ('40', '支付宝', 'Alipay', '1.0', 'qiaokeli', '支付宝', '1', '{\"update_time\":1449833012,\"account\":\"735579768@qq.com\",\"appid\":\"2088002656310382\",\"appkey\":\"dpon93lktfivsvgmyhg3i0frycgab4sn\",\"api\":\"shuang\"}', 'system', '1');
INSERT INTO `kl_addons` VALUES ('41', '中国银联', 'Unionpay', '1.0', 'qiaokeli', '银联支付', '1', '{\"update_time\":1449459057,\"MEMBER_ID\":\"435410153110034\"}', 'system', '1');
INSERT INTO `kl_addons` VALUES ('42', '财付通', 'Tenpay', '1.0', 'qiaokeli', '财付通', '1', '{\"update_time\":1449474966,\"partner\":\"11111111111\",\"key\":\"2222222222\"}', 'system', '1');

-- ----------------------------
-- Table structure for kl_area
-- ----------------------------
DROP TABLE IF EXISTS `kl_area`;
CREATE TABLE `kl_area` (
  `area_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `chengxiang` int(11) DEFAULT NULL,
  `area_name` varchar(50) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`area_id`)
) ENGINE=MyISAM AUTO_INCREMENT=742135 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_area
-- ----------------------------
INSERT INTO `kl_area` VALUES ('1', '0', null, '北京市', '11');
INSERT INTO `kl_area` VALUES ('2', '0', null, '天津市', '12');
INSERT INTO `kl_area` VALUES ('3', '0', null, '河北省', '13');
INSERT INTO `kl_area` VALUES ('4', '0', null, '山西省', '14');
INSERT INTO `kl_area` VALUES ('5', '0', null, '内蒙古自治区', '15');
INSERT INTO `kl_area` VALUES ('6', '0', null, '辽宁省', '21');
INSERT INTO `kl_area` VALUES ('7', '0', null, '吉林省', '22');
INSERT INTO `kl_area` VALUES ('8', '0', null, '黑龙江省', '23');
INSERT INTO `kl_area` VALUES ('9', '0', null, '上海市', '31');
INSERT INTO `kl_area` VALUES ('10', '0', null, '江苏省', '32');
INSERT INTO `kl_area` VALUES ('11', '0', null, '浙江省', '33');
INSERT INTO `kl_area` VALUES ('12', '0', null, '安徽省', '34');
INSERT INTO `kl_area` VALUES ('13', '0', null, '福建省', '35');
INSERT INTO `kl_area` VALUES ('14', '0', null, '江西省', '36');
INSERT INTO `kl_area` VALUES ('15', '0', null, '山东省', '37');
INSERT INTO `kl_area` VALUES ('16', '0', null, '河南省', '41');
INSERT INTO `kl_area` VALUES ('17', '0', null, '湖北省', '42');
INSERT INTO `kl_area` VALUES ('18', '0', null, '湖南省', '43');
INSERT INTO `kl_area` VALUES ('19', '0', null, '广东省', '44');
INSERT INTO `kl_area` VALUES ('20', '0', null, '广西壮族自治区', '45');
INSERT INTO `kl_area` VALUES ('21', '0', null, '海南省', '46');
INSERT INTO `kl_area` VALUES ('22', '0', null, '重庆市', '50');
INSERT INTO `kl_area` VALUES ('23', '0', null, '四川省', '51');
INSERT INTO `kl_area` VALUES ('24', '0', null, '贵州省', '52');
INSERT INTO `kl_area` VALUES ('25', '0', null, '云南省', '53');
INSERT INTO `kl_area` VALUES ('26', '0', null, '西藏自治区', '54');
INSERT INTO `kl_area` VALUES ('27', '0', null, '陕西省', '61');
INSERT INTO `kl_area` VALUES ('28', '0', null, '甘肃省', '62');
INSERT INTO `kl_area` VALUES ('29', '0', null, '青海省', '63');
INSERT INTO `kl_area` VALUES ('30', '0', null, '宁夏回族自治区', '64');
INSERT INTO `kl_area` VALUES ('31', '0', null, '新疆维吾尔自治区', '65');
INSERT INTO `kl_area` VALUES ('32', '1', null, '市辖区', '1101');
INSERT INTO `kl_area` VALUES ('33', '1', null, '县', '1102');
INSERT INTO `kl_area` VALUES ('34', '11', null, '杭州市', '3301');
INSERT INTO `kl_area` VALUES ('35', '11', null, '宁波市', '3302');
INSERT INTO `kl_area` VALUES ('36', '11', null, '温州市', '3303');
INSERT INTO `kl_area` VALUES ('37', '11', null, '嘉兴市', '3304');
INSERT INTO `kl_area` VALUES ('38', '11', null, '湖州市', '3305');
INSERT INTO `kl_area` VALUES ('39', '11', null, '绍兴市', '3306');
INSERT INTO `kl_area` VALUES ('40', '11', null, '金华市', '3307');
INSERT INTO `kl_area` VALUES ('41', '11', null, '衢州市', '3308');
INSERT INTO `kl_area` VALUES ('42', '11', null, '舟山市', '3309');
INSERT INTO `kl_area` VALUES ('43', '11', null, '台州市', '3310');
INSERT INTO `kl_area` VALUES ('44', '11', null, '丽水市', '3311');
INSERT INTO `kl_area` VALUES ('45', '2', null, '市辖区', '1201');
INSERT INTO `kl_area` VALUES ('46', '2', null, '县', '1202');
INSERT INTO `kl_area` VALUES ('47', '21', null, '海口市', '4601');
INSERT INTO `kl_area` VALUES ('48', '21', null, '三亚市', '4602');
INSERT INTO `kl_area` VALUES ('49', '21', null, '三沙市', '4603');
INSERT INTO `kl_area` VALUES ('50', '21', null, '省直辖县级行政区划', '4690');
INSERT INTO `kl_area` VALUES ('51', '12', null, '合肥市', '3401');
INSERT INTO `kl_area` VALUES ('52', '12', null, '芜湖市', '3402');
INSERT INTO `kl_area` VALUES ('53', '12', null, '蚌埠市', '3403');
INSERT INTO `kl_area` VALUES ('54', '12', null, '淮南市', '3404');
INSERT INTO `kl_area` VALUES ('55', '12', null, '马鞍山市', '3405');
INSERT INTO `kl_area` VALUES ('56', '12', null, '淮北市', '3406');
INSERT INTO `kl_area` VALUES ('57', '12', null, '铜陵市', '3407');
INSERT INTO `kl_area` VALUES ('58', '3', null, '石家庄市', '1301');
INSERT INTO `kl_area` VALUES ('59', '12', null, '安庆市', '3408');
INSERT INTO `kl_area` VALUES ('60', '3', null, '唐山市', '1302');
INSERT INTO `kl_area` VALUES ('61', '12', null, '黄山市', '3410');
INSERT INTO `kl_area` VALUES ('62', '3', null, '秦皇岛市', '1303');
INSERT INTO `kl_area` VALUES ('63', '12', null, '滁州市', '3411');
INSERT INTO `kl_area` VALUES ('64', '3', null, '邯郸市', '1304');
INSERT INTO `kl_area` VALUES ('65', '12', null, '阜阳市', '3412');
INSERT INTO `kl_area` VALUES ('66', '3', null, '邢台市', '1305');
INSERT INTO `kl_area` VALUES ('67', '12', null, '宿州市', '3413');
INSERT INTO `kl_area` VALUES ('68', '3', null, '保定市', '1306');
INSERT INTO `kl_area` VALUES ('69', '12', null, '六安市', '3415');
INSERT INTO `kl_area` VALUES ('70', '3', null, '张家口市', '1307');
INSERT INTO `kl_area` VALUES ('71', '12', null, '亳州市', '3416');
INSERT INTO `kl_area` VALUES ('72', '3', null, '承德市', '1308');
INSERT INTO `kl_area` VALUES ('73', '12', null, '池州市', '3417');
INSERT INTO `kl_area` VALUES ('74', '3', null, '沧州市', '1309');
INSERT INTO `kl_area` VALUES ('75', '12', null, '宣城市', '3418');
INSERT INTO `kl_area` VALUES ('76', '22', null, '市辖区', '5001');
INSERT INTO `kl_area` VALUES ('77', '3', null, '廊坊市', '1310');
INSERT INTO `kl_area` VALUES ('78', '22', null, '县', '5002');
INSERT INTO `kl_area` VALUES ('79', '3', null, '衡水市', '1311');
INSERT INTO `kl_area` VALUES ('80', '13', null, '福州市', '3501');
INSERT INTO `kl_area` VALUES ('81', '13', null, '厦门市', '3502');
INSERT INTO `kl_area` VALUES ('82', '23', null, '成都市', '5101');
INSERT INTO `kl_area` VALUES ('83', '13', null, '莆田市', '3503');
INSERT INTO `kl_area` VALUES ('84', '4', null, '太原市', '1401');
INSERT INTO `kl_area` VALUES ('85', '23', null, '自贡市', '5103');
INSERT INTO `kl_area` VALUES ('86', '13', null, '三明市', '3504');
INSERT INTO `kl_area` VALUES ('87', '23', null, '攀枝花市', '5104');
INSERT INTO `kl_area` VALUES ('88', '4', null, '大同市', '1402');
INSERT INTO `kl_area` VALUES ('89', '13', null, '泉州市', '3505');
INSERT INTO `kl_area` VALUES ('90', '23', null, '泸州市', '5105');
INSERT INTO `kl_area` VALUES ('91', '4', null, '阳泉市', '1403');
INSERT INTO `kl_area` VALUES ('92', '13', null, '漳州市', '3506');
INSERT INTO `kl_area` VALUES ('93', '23', null, '德阳市', '5106');
INSERT INTO `kl_area` VALUES ('94', '4', null, '长治市', '1404');
INSERT INTO `kl_area` VALUES ('95', '13', null, '南平市', '3507');
INSERT INTO `kl_area` VALUES ('96', '23', null, '绵阳市', '5107');
INSERT INTO `kl_area` VALUES ('97', '4', null, '晋城市', '1405');
INSERT INTO `kl_area` VALUES ('98', '13', null, '龙岩市', '3508');
INSERT INTO `kl_area` VALUES ('99', '23', null, '广元市', '5108');
INSERT INTO `kl_area` VALUES ('100', '4', null, '朔州市', '1406');
INSERT INTO `kl_area` VALUES ('101', '13', null, '宁德市', '3509');
INSERT INTO `kl_area` VALUES ('102', '4', null, '晋中市', '1407');
INSERT INTO `kl_area` VALUES ('103', '23', null, '遂宁市', '5109');
INSERT INTO `kl_area` VALUES ('104', '23', null, '内江市', '5110');
INSERT INTO `kl_area` VALUES ('105', '4', null, '运城市', '1408');
INSERT INTO `kl_area` VALUES ('106', '23', null, '乐山市', '5111');
INSERT INTO `kl_area` VALUES ('107', '4', null, '忻州市', '1409');
INSERT INTO `kl_area` VALUES ('108', '23', null, '南充市', '5113');
INSERT INTO `kl_area` VALUES ('109', '4', null, '临汾市', '1410');
INSERT INTO `kl_area` VALUES ('110', '23', null, '眉山市', '5114');
INSERT INTO `kl_area` VALUES ('111', '4', null, '吕梁市', '1411');
INSERT INTO `kl_area` VALUES ('112', '23', null, '宜宾市', '5115');
INSERT INTO `kl_area` VALUES ('113', '23', null, '广安市', '5116');
INSERT INTO `kl_area` VALUES ('114', '23', null, '达州市', '5117');
INSERT INTO `kl_area` VALUES ('115', '23', null, '雅安市', '5118');
INSERT INTO `kl_area` VALUES ('116', '23', null, '巴中市', '5119');
INSERT INTO `kl_area` VALUES ('117', '23', null, '资阳市', '5120');
INSERT INTO `kl_area` VALUES ('118', '23', null, '阿坝藏族羌族自治州', '5132');
INSERT INTO `kl_area` VALUES ('119', '23', null, '甘孜藏族自治州', '5133');
INSERT INTO `kl_area` VALUES ('120', '23', null, '凉山彝族自治州', '5134');
INSERT INTO `kl_area` VALUES ('121', '14', null, '南昌市', '3601');
INSERT INTO `kl_area` VALUES ('122', '14', null, '景德镇市', '3602');
INSERT INTO `kl_area` VALUES ('123', '14', null, '萍乡市', '3603');
INSERT INTO `kl_area` VALUES ('124', '14', null, '九江市', '3604');
INSERT INTO `kl_area` VALUES ('125', '14', null, '新余市', '3605');
INSERT INTO `kl_area` VALUES ('126', '14', null, '鹰潭市', '3606');
INSERT INTO `kl_area` VALUES ('127', '14', null, '赣州市', '3607');
INSERT INTO `kl_area` VALUES ('128', '14', null, '吉安市', '3608');
INSERT INTO `kl_area` VALUES ('129', '14', null, '宜春市', '3609');
INSERT INTO `kl_area` VALUES ('130', '5', null, '呼和浩特市', '1501');
INSERT INTO `kl_area` VALUES ('131', '14', null, '抚州市', '3610');
INSERT INTO `kl_area` VALUES ('132', '5', null, '包头市', '1502');
INSERT INTO `kl_area` VALUES ('133', '14', null, '上饶市', '3611');
INSERT INTO `kl_area` VALUES ('134', '5', null, '乌海市', '1503');
INSERT INTO `kl_area` VALUES ('135', '5', null, '赤峰市', '1504');
INSERT INTO `kl_area` VALUES ('136', '5', null, '通辽市', '1505');
INSERT INTO `kl_area` VALUES ('137', '5', null, '鄂尔多斯市', '1506');
INSERT INTO `kl_area` VALUES ('138', '5', null, '呼伦贝尔市', '1507');
INSERT INTO `kl_area` VALUES ('139', '24', null, '贵阳市', '5201');
INSERT INTO `kl_area` VALUES ('140', '5', null, '巴彦淖尔市', '1508');
INSERT INTO `kl_area` VALUES ('141', '24', null, '六盘水市', '5202');
INSERT INTO `kl_area` VALUES ('142', '5', null, '乌兰察布市', '1509');
INSERT INTO `kl_area` VALUES ('143', '24', null, '遵义市', '5203');
INSERT INTO `kl_area` VALUES ('144', '5', null, '兴安盟', '1522');
INSERT INTO `kl_area` VALUES ('145', '24', null, '安顺市', '5204');
INSERT INTO `kl_area` VALUES ('146', '5', null, '锡林郭勒盟', '1525');
INSERT INTO `kl_area` VALUES ('147', '24', null, '毕节市', '5205');
INSERT INTO `kl_area` VALUES ('148', '5', null, '阿拉善盟', '1529');
INSERT INTO `kl_area` VALUES ('149', '24', null, '铜仁市', '5206');
INSERT INTO `kl_area` VALUES ('150', '24', null, '黔西南布依族苗族自治州', '5223');
INSERT INTO `kl_area` VALUES ('151', '24', null, '黔东南苗族侗族自治州', '5226');
INSERT INTO `kl_area` VALUES ('152', '24', null, '黔南布依族苗族自治州', '5227');
INSERT INTO `kl_area` VALUES ('153', '15', null, '济南市', '3701');
INSERT INTO `kl_area` VALUES ('154', '15', null, '青岛市', '3702');
INSERT INTO `kl_area` VALUES ('155', '15', null, '淄博市', '3703');
INSERT INTO `kl_area` VALUES ('156', '15', null, '枣庄市', '3704');
INSERT INTO `kl_area` VALUES ('157', '15', null, '东营市', '3705');
INSERT INTO `kl_area` VALUES ('158', '15', null, '烟台市', '3706');
INSERT INTO `kl_area` VALUES ('159', '15', null, '潍坊市', '3707');
INSERT INTO `kl_area` VALUES ('160', '15', null, '济宁市', '3708');
INSERT INTO `kl_area` VALUES ('161', '15', null, '泰安市', '3709');
INSERT INTO `kl_area` VALUES ('162', '15', null, '威海市', '3710');
INSERT INTO `kl_area` VALUES ('163', '15', null, '日照市', '3711');
INSERT INTO `kl_area` VALUES ('164', '15', null, '莱芜市', '3712');
INSERT INTO `kl_area` VALUES ('165', '15', null, '临沂市', '3713');
INSERT INTO `kl_area` VALUES ('166', '15', null, '德州市', '3714');
INSERT INTO `kl_area` VALUES ('167', '15', null, '聊城市', '3715');
INSERT INTO `kl_area` VALUES ('168', '6', null, '沈阳市', '2101');
INSERT INTO `kl_area` VALUES ('169', '15', null, '滨州市', '3716');
INSERT INTO `kl_area` VALUES ('170', '6', null, '大连市', '2102');
INSERT INTO `kl_area` VALUES ('171', '25', null, '昆明市', '5301');
INSERT INTO `kl_area` VALUES ('172', '15', null, '菏泽市', '3717');
INSERT INTO `kl_area` VALUES ('173', '6', null, '鞍山市', '2103');
INSERT INTO `kl_area` VALUES ('174', '25', null, '曲靖市', '5303');
INSERT INTO `kl_area` VALUES ('175', '6', null, '抚顺市', '2104');
INSERT INTO `kl_area` VALUES ('176', '25', null, '玉溪市', '5304');
INSERT INTO `kl_area` VALUES ('177', '6', null, '本溪市', '2105');
INSERT INTO `kl_area` VALUES ('178', '25', null, '保山市', '5305');
INSERT INTO `kl_area` VALUES ('179', '6', null, '丹东市', '2106');
INSERT INTO `kl_area` VALUES ('180', '25', null, '昭通市', '5306');
INSERT INTO `kl_area` VALUES ('181', '6', null, '锦州市', '2107');
INSERT INTO `kl_area` VALUES ('182', '25', null, '丽江市', '5307');
INSERT INTO `kl_area` VALUES ('183', '6', null, '营口市', '2108');
INSERT INTO `kl_area` VALUES ('184', '25', null, '普洱市', '5308');
INSERT INTO `kl_area` VALUES ('185', '6', null, '阜新市', '2109');
INSERT INTO `kl_area` VALUES ('186', '25', null, '临沧市', '5309');
INSERT INTO `kl_area` VALUES ('187', '6', null, '辽阳市', '2110');
INSERT INTO `kl_area` VALUES ('188', '25', null, '楚雄彝族自治州', '5323');
INSERT INTO `kl_area` VALUES ('189', '6', null, '盘锦市', '2111');
INSERT INTO `kl_area` VALUES ('190', '25', null, '红河哈尼族彝族自治州', '5325');
INSERT INTO `kl_area` VALUES ('191', '6', null, '铁岭市', '2112');
INSERT INTO `kl_area` VALUES ('192', '25', null, '文山壮族苗族自治州', '5326');
INSERT INTO `kl_area` VALUES ('193', '6', null, '朝阳市', '2113');
INSERT INTO `kl_area` VALUES ('194', '25', null, '西双版纳傣族自治州', '5328');
INSERT INTO `kl_area` VALUES ('195', '6', null, '葫芦岛市', '2114');
INSERT INTO `kl_area` VALUES ('196', '25', null, '大理白族自治州', '5329');
INSERT INTO `kl_area` VALUES ('197', '25', null, '德宏傣族景颇族自治州', '5331');
INSERT INTO `kl_area` VALUES ('198', '16', null, '郑州市', '4101');
INSERT INTO `kl_area` VALUES ('199', '25', null, '怒江傈僳族自治州', '5333');
INSERT INTO `kl_area` VALUES ('200', '16', null, '开封市', '4102');
INSERT INTO `kl_area` VALUES ('201', '25', null, '迪庆藏族自治州', '5334');
INSERT INTO `kl_area` VALUES ('202', '16', null, '洛阳市', '4103');
INSERT INTO `kl_area` VALUES ('203', '16', null, '平顶山市', '4104');
INSERT INTO `kl_area` VALUES ('204', '16', null, '安阳市', '4105');
INSERT INTO `kl_area` VALUES ('205', '16', null, '鹤壁市', '4106');
INSERT INTO `kl_area` VALUES ('206', '16', null, '新乡市', '4107');
INSERT INTO `kl_area` VALUES ('207', '16', null, '焦作市', '4108');
INSERT INTO `kl_area` VALUES ('208', '16', null, '濮阳市', '4109');
INSERT INTO `kl_area` VALUES ('209', '16', null, '许昌市', '4110');
INSERT INTO `kl_area` VALUES ('210', '16', null, '漯河市', '4111');
INSERT INTO `kl_area` VALUES ('211', '16', null, '三门峡市', '4112');
INSERT INTO `kl_area` VALUES ('212', '16', null, '南阳市', '4113');
INSERT INTO `kl_area` VALUES ('213', '7', null, '长春市', '2201');
INSERT INTO `kl_area` VALUES ('214', '16', null, '商丘市', '4114');
INSERT INTO `kl_area` VALUES ('215', '7', null, '吉林市', '2202');
INSERT INTO `kl_area` VALUES ('216', '16', null, '信阳市', '4115');
INSERT INTO `kl_area` VALUES ('217', '7', null, '四平市', '2203');
INSERT INTO `kl_area` VALUES ('218', '16', null, '周口市', '4116');
INSERT INTO `kl_area` VALUES ('219', '7', null, '辽源市', '2204');
INSERT INTO `kl_area` VALUES ('220', '16', null, '驻马店市', '4117');
INSERT INTO `kl_area` VALUES ('221', '7', null, '通化市', '2205');
INSERT INTO `kl_area` VALUES ('222', '16', null, '省直辖县级行政区划', '4190');
INSERT INTO `kl_area` VALUES ('223', '7', null, '白山市', '2206');
INSERT INTO `kl_area` VALUES ('224', '26', null, '拉萨市', '5401');
INSERT INTO `kl_area` VALUES ('225', '7', null, '松原市', '2207');
INSERT INTO `kl_area` VALUES ('226', '26', null, '昌都地区', '5421');
INSERT INTO `kl_area` VALUES ('227', '7', null, '白城市', '2208');
INSERT INTO `kl_area` VALUES ('228', '26', null, '山南地区', '5422');
INSERT INTO `kl_area` VALUES ('229', '7', null, '延边朝鲜族自治州', '2224');
INSERT INTO `kl_area` VALUES ('230', '26', null, '日喀则地区', '5423');
INSERT INTO `kl_area` VALUES ('231', '26', null, '那曲地区', '5424');
INSERT INTO `kl_area` VALUES ('232', '26', null, '阿里地区', '5425');
INSERT INTO `kl_area` VALUES ('233', '26', null, '林芝地区', '5426');
INSERT INTO `kl_area` VALUES ('234', '17', null, '武汉市', '4201');
INSERT INTO `kl_area` VALUES ('235', '17', null, '黄石市', '4202');
INSERT INTO `kl_area` VALUES ('236', '17', null, '十堰市', '4203');
INSERT INTO `kl_area` VALUES ('237', '17', null, '宜昌市', '4205');
INSERT INTO `kl_area` VALUES ('238', '17', null, '襄阳市', '4206');
INSERT INTO `kl_area` VALUES ('239', '17', null, '鄂州市', '4207');
INSERT INTO `kl_area` VALUES ('240', '17', null, '荆门市', '4208');
INSERT INTO `kl_area` VALUES ('241', '8', null, '哈尔滨市', '2301');
INSERT INTO `kl_area` VALUES ('242', '17', null, '孝感市', '4209');
INSERT INTO `kl_area` VALUES ('243', '8', null, '齐齐哈尔市', '2302');
INSERT INTO `kl_area` VALUES ('244', '17', null, '荆州市', '4210');
INSERT INTO `kl_area` VALUES ('245', '8', null, '鸡西市', '2303');
INSERT INTO `kl_area` VALUES ('246', '17', null, '黄冈市', '4211');
INSERT INTO `kl_area` VALUES ('247', '27', null, '西安市', '6101');
INSERT INTO `kl_area` VALUES ('248', '8', null, '鹤岗市', '2304');
INSERT INTO `kl_area` VALUES ('249', '17', null, '咸宁市', '4212');
INSERT INTO `kl_area` VALUES ('250', '27', null, '铜川市', '6102');
INSERT INTO `kl_area` VALUES ('251', '8', null, '双鸭山市', '2305');
INSERT INTO `kl_area` VALUES ('252', '17', null, '随州市', '4213');
INSERT INTO `kl_area` VALUES ('253', '27', null, '宝鸡市', '6103');
INSERT INTO `kl_area` VALUES ('254', '8', null, '大庆市', '2306');
INSERT INTO `kl_area` VALUES ('255', '17', null, '恩施土家族苗族自治州', '4228');
INSERT INTO `kl_area` VALUES ('256', '27', null, '咸阳市', '6104');
INSERT INTO `kl_area` VALUES ('257', '8', null, '伊春市', '2307');
INSERT INTO `kl_area` VALUES ('258', '27', null, '渭南市', '6105');
INSERT INTO `kl_area` VALUES ('259', '17', null, '省直辖县级行政区划', '4290');
INSERT INTO `kl_area` VALUES ('260', '8', null, '佳木斯市', '2308');
INSERT INTO `kl_area` VALUES ('261', '27', null, '延安市', '6106');
INSERT INTO `kl_area` VALUES ('262', '8', null, '七台河市', '2309');
INSERT INTO `kl_area` VALUES ('263', '27', null, '汉中市', '6107');
INSERT INTO `kl_area` VALUES ('264', '8', null, '牡丹江市', '2310');
INSERT INTO `kl_area` VALUES ('265', '27', null, '榆林市', '6108');
INSERT INTO `kl_area` VALUES ('266', '8', null, '黑河市', '2311');
INSERT INTO `kl_area` VALUES ('267', '27', null, '安康市', '6109');
INSERT INTO `kl_area` VALUES ('268', '8', null, '绥化市', '2312');
INSERT INTO `kl_area` VALUES ('269', '27', null, '商洛市', '6110');
INSERT INTO `kl_area` VALUES ('270', '8', null, '大兴安岭地区', '2327');
INSERT INTO `kl_area` VALUES ('271', '18', null, '长沙市', '4301');
INSERT INTO `kl_area` VALUES ('272', '18', null, '株洲市', '4302');
INSERT INTO `kl_area` VALUES ('273', '18', null, '湘潭市', '4303');
INSERT INTO `kl_area` VALUES ('274', '18', null, '衡阳市', '4304');
INSERT INTO `kl_area` VALUES ('275', '18', null, '邵阳市', '4305');
INSERT INTO `kl_area` VALUES ('276', '18', null, '岳阳市', '4306');
INSERT INTO `kl_area` VALUES ('277', '18', null, '常德市', '4307');
INSERT INTO `kl_area` VALUES ('278', '18', null, '张家界市', '4308');
INSERT INTO `kl_area` VALUES ('279', '18', null, '益阳市', '4309');
INSERT INTO `kl_area` VALUES ('280', '18', null, '郴州市', '4310');
INSERT INTO `kl_area` VALUES ('281', '18', null, '永州市', '4311');
INSERT INTO `kl_area` VALUES ('282', '28', null, '兰州市', '6201');
INSERT INTO `kl_area` VALUES ('283', '18', null, '怀化市', '4312');
INSERT INTO `kl_area` VALUES ('284', '9', null, '市辖区', '3101');
INSERT INTO `kl_area` VALUES ('285', '28', null, '嘉峪关市', '6202');
INSERT INTO `kl_area` VALUES ('286', '18', null, '娄底市', '4313');
INSERT INTO `kl_area` VALUES ('287', '9', null, '县', '3102');
INSERT INTO `kl_area` VALUES ('288', '28', null, '金昌市', '6203');
INSERT INTO `kl_area` VALUES ('289', '18', null, '湘西土家族苗族自治州', '4331');
INSERT INTO `kl_area` VALUES ('290', '28', null, '白银市', '6204');
INSERT INTO `kl_area` VALUES ('291', '28', null, '天水市', '6205');
INSERT INTO `kl_area` VALUES ('292', '28', null, '武威市', '6206');
INSERT INTO `kl_area` VALUES ('293', '28', null, '张掖市', '6207');
INSERT INTO `kl_area` VALUES ('294', '28', null, '平凉市', '6208');
INSERT INTO `kl_area` VALUES ('295', '28', null, '酒泉市', '6209');
INSERT INTO `kl_area` VALUES ('296', '28', null, '庆阳市', '6210');
INSERT INTO `kl_area` VALUES ('297', '28', null, '定西市', '6211');
INSERT INTO `kl_area` VALUES ('298', '28', null, '陇南市', '6212');
INSERT INTO `kl_area` VALUES ('299', '28', null, '临夏回族自治州', '6229');
INSERT INTO `kl_area` VALUES ('300', '28', null, '甘南藏族自治州', '6230');
INSERT INTO `kl_area` VALUES ('301', '10', null, '南京市', '3201');
INSERT INTO `kl_area` VALUES ('302', '19', null, '广州市', '4401');
INSERT INTO `kl_area` VALUES ('303', '10', null, '无锡市', '3202');
INSERT INTO `kl_area` VALUES ('304', '19', null, '韶关市', '4402');
INSERT INTO `kl_area` VALUES ('305', '10', null, '徐州市', '3203');
INSERT INTO `kl_area` VALUES ('306', '19', null, '深圳市', '4403');
INSERT INTO `kl_area` VALUES ('307', '10', null, '常州市', '3204');
INSERT INTO `kl_area` VALUES ('308', '19', null, '珠海市', '4404');
INSERT INTO `kl_area` VALUES ('309', '10', null, '苏州市', '3205');
INSERT INTO `kl_area` VALUES ('310', '19', null, '汕头市', '4405');
INSERT INTO `kl_area` VALUES ('311', '10', null, '南通市', '3206');
INSERT INTO `kl_area` VALUES ('312', '19', null, '佛山市', '4406');
INSERT INTO `kl_area` VALUES ('313', '10', null, '连云港市', '3207');
INSERT INTO `kl_area` VALUES ('314', '19', null, '江门市', '4407');
INSERT INTO `kl_area` VALUES ('315', '10', null, '淮安市', '3208');
INSERT INTO `kl_area` VALUES ('316', '29', null, '西宁市', '6301');
INSERT INTO `kl_area` VALUES ('317', '19', null, '湛江市', '4408');
INSERT INTO `kl_area` VALUES ('318', '29', null, '海东市', '6302');
INSERT INTO `kl_area` VALUES ('319', '10', null, '盐城市', '3209');
INSERT INTO `kl_area` VALUES ('320', '19', null, '茂名市', '4409');
INSERT INTO `kl_area` VALUES ('321', '29', null, '海北藏族自治州', '6322');
INSERT INTO `kl_area` VALUES ('322', '10', null, '扬州市', '3210');
INSERT INTO `kl_area` VALUES ('323', '19', null, '肇庆市', '4412');
INSERT INTO `kl_area` VALUES ('324', '10', null, '镇江市', '3211');
INSERT INTO `kl_area` VALUES ('325', '29', null, '黄南藏族自治州', '6323');
INSERT INTO `kl_area` VALUES ('326', '19', null, '惠州市', '4413');
INSERT INTO `kl_area` VALUES ('327', '29', null, '海南藏族自治州', '6325');
INSERT INTO `kl_area` VALUES ('328', '10', null, '泰州市', '3212');
INSERT INTO `kl_area` VALUES ('329', '19', null, '梅州市', '4414');
INSERT INTO `kl_area` VALUES ('330', '10', null, '宿迁市', '3213');
INSERT INTO `kl_area` VALUES ('331', '29', null, '果洛藏族自治州', '6326');
INSERT INTO `kl_area` VALUES ('332', '19', null, '汕尾市', '4415');
INSERT INTO `kl_area` VALUES ('333', '29', null, '玉树藏族自治州', '6327');
INSERT INTO `kl_area` VALUES ('334', '19', null, '河源市', '4416');
INSERT INTO `kl_area` VALUES ('335', '29', null, '海西蒙古族藏族自治州', '6328');
INSERT INTO `kl_area` VALUES ('336', '19', null, '阳江市', '4417');
INSERT INTO `kl_area` VALUES ('337', '19', null, '清远市', '4418');
INSERT INTO `kl_area` VALUES ('338', '19', null, '东莞市', '4419');
INSERT INTO `kl_area` VALUES ('339', '19', null, '中山市', '4420');
INSERT INTO `kl_area` VALUES ('340', '19', null, '潮州市', '4451');
INSERT INTO `kl_area` VALUES ('341', '19', null, '揭阳市', '4452');
INSERT INTO `kl_area` VALUES ('342', '19', null, '云浮市', '4453');
INSERT INTO `kl_area` VALUES ('343', '30', null, '银川市', '6401');
INSERT INTO `kl_area` VALUES ('344', '30', null, '石嘴山市', '6402');
INSERT INTO `kl_area` VALUES ('345', '30', null, '吴忠市', '6403');
INSERT INTO `kl_area` VALUES ('346', '30', null, '固原市', '6404');
INSERT INTO `kl_area` VALUES ('347', '20', null, '南宁市', '4501');
INSERT INTO `kl_area` VALUES ('348', '30', null, '中卫市', '6405');
INSERT INTO `kl_area` VALUES ('349', '20', null, '柳州市', '4502');
INSERT INTO `kl_area` VALUES ('350', '20', null, '桂林市', '4503');
INSERT INTO `kl_area` VALUES ('351', '20', null, '梧州市', '4504');
INSERT INTO `kl_area` VALUES ('352', '20', null, '北海市', '4505');
INSERT INTO `kl_area` VALUES ('353', '20', null, '防城港市', '4506');
INSERT INTO `kl_area` VALUES ('354', '31', null, '乌鲁木齐市', '6501');
INSERT INTO `kl_area` VALUES ('355', '20', null, '钦州市', '4507');
INSERT INTO `kl_area` VALUES ('356', '31', null, '克拉玛依市', '6502');
INSERT INTO `kl_area` VALUES ('357', '20', null, '贵港市', '4508');
INSERT INTO `kl_area` VALUES ('358', '31', null, '吐鲁番地区', '6521');
INSERT INTO `kl_area` VALUES ('359', '20', null, '玉林市', '4509');
INSERT INTO `kl_area` VALUES ('360', '31', null, '哈密地区', '6522');
INSERT INTO `kl_area` VALUES ('361', '20', null, '百色市', '4510');
INSERT INTO `kl_area` VALUES ('362', '31', null, '昌吉回族自治州', '6523');
INSERT INTO `kl_area` VALUES ('363', '20', null, '贺州市', '4511');
INSERT INTO `kl_area` VALUES ('364', '31', null, '博尔塔拉蒙古自治州', '6527');
INSERT INTO `kl_area` VALUES ('365', '20', null, '河池市', '4512');
INSERT INTO `kl_area` VALUES ('366', '31', null, '巴音郭楞蒙古自治州', '6528');
INSERT INTO `kl_area` VALUES ('367', '20', null, '来宾市', '4513');
INSERT INTO `kl_area` VALUES ('368', '31', null, '阿克苏地区', '6529');
INSERT INTO `kl_area` VALUES ('369', '20', null, '崇左市', '4514');
INSERT INTO `kl_area` VALUES ('370', '31', null, '克孜勒苏柯尔克孜自治州', '6530');
INSERT INTO `kl_area` VALUES ('371', '31', null, '喀什地区', '6531');
INSERT INTO `kl_area` VALUES ('372', '31', null, '和田地区', '6532');
INSERT INTO `kl_area` VALUES ('373', '31', null, '伊犁哈萨克自治州', '6540');
INSERT INTO `kl_area` VALUES ('374', '31', null, '塔城地区', '6542');
INSERT INTO `kl_area` VALUES ('375', '31', null, '阿勒泰地区', '6543');
INSERT INTO `kl_area` VALUES ('376', '31', null, '自治区直辖县级行政区划', '6590');
INSERT INTO `kl_area` VALUES ('377', '32', null, '东城区', '110101');
INSERT INTO `kl_area` VALUES ('378', '32', null, '西城区', '110102');
INSERT INTO `kl_area` VALUES ('379', '32', null, '朝阳区', '110105');
INSERT INTO `kl_area` VALUES ('380', '32', null, '丰台区', '110106');
INSERT INTO `kl_area` VALUES ('381', '32', null, '石景山区', '110107');
INSERT INTO `kl_area` VALUES ('382', '32', null, '海淀区', '110108');
INSERT INTO `kl_area` VALUES ('383', '32', null, '门头沟区', '110109');
INSERT INTO `kl_area` VALUES ('384', '32', null, '房山区', '110111');
INSERT INTO `kl_area` VALUES ('385', '32', null, '通州区', '110112');
INSERT INTO `kl_area` VALUES ('386', '32', null, '顺义区', '110113');
INSERT INTO `kl_area` VALUES ('387', '32', null, '昌平区', '110114');
INSERT INTO `kl_area` VALUES ('388', '32', null, '大兴区', '110115');
INSERT INTO `kl_area` VALUES ('389', '32', null, '怀柔区', '110116');
INSERT INTO `kl_area` VALUES ('390', '32', null, '平谷区', '110117');
INSERT INTO `kl_area` VALUES ('391', '70', null, '市辖区', '130701');
INSERT INTO `kl_area` VALUES ('392', '70', null, '桥东区', '130702');
INSERT INTO `kl_area` VALUES ('393', '70', null, '桥西区', '130703');
INSERT INTO `kl_area` VALUES ('394', '70', null, '宣化区', '130705');
INSERT INTO `kl_area` VALUES ('395', '70', null, '下花园区', '130706');
INSERT INTO `kl_area` VALUES ('396', '70', null, '宣化县', '130721');
INSERT INTO `kl_area` VALUES ('397', '70', null, '张北县', '130722');
INSERT INTO `kl_area` VALUES ('398', '70', null, '康保县', '130723');
INSERT INTO `kl_area` VALUES ('399', '70', null, '沽源县', '130724');
INSERT INTO `kl_area` VALUES ('400', '70', null, '尚义县', '130725');
INSERT INTO `kl_area` VALUES ('401', '70', null, '蔚县', '130726');
INSERT INTO `kl_area` VALUES ('402', '70', null, '阳原县', '130727');
INSERT INTO `kl_area` VALUES ('403', '70', null, '怀安县', '130728');
INSERT INTO `kl_area` VALUES ('404', '70', null, '万全县', '130729');
INSERT INTO `kl_area` VALUES ('405', '33', null, '密云县', '110228');
INSERT INTO `kl_area` VALUES ('406', '70', null, '怀来县', '130730');
INSERT INTO `kl_area` VALUES ('407', '33', null, '延庆县', '110229');
INSERT INTO `kl_area` VALUES ('408', '70', null, '涿鹿县', '130731');
INSERT INTO `kl_area` VALUES ('409', '100', null, '市辖区', '140601');
INSERT INTO `kl_area` VALUES ('410', '100', null, '朔城区', '140602');
INSERT INTO `kl_area` VALUES ('411', '70', null, '赤城县', '130732');
INSERT INTO `kl_area` VALUES ('412', '100', null, '平鲁区', '140603');
INSERT INTO `kl_area` VALUES ('413', '70', null, '崇礼县', '130733');
INSERT INTO `kl_area` VALUES ('414', '100', null, '山阴县', '140621');
INSERT INTO `kl_area` VALUES ('415', '100', null, '应县', '140622');
INSERT INTO `kl_area` VALUES ('416', '100', null, '右玉县', '140623');
INSERT INTO `kl_area` VALUES ('417', '100', null, '怀仁县', '140624');
INSERT INTO `kl_area` VALUES ('418', '45', null, '和平区', '120101');
INSERT INTO `kl_area` VALUES ('419', '45', null, '河东区', '120102');
INSERT INTO `kl_area` VALUES ('420', '45', null, '河西区', '120103');
INSERT INTO `kl_area` VALUES ('421', '45', null, '南开区', '120104');
INSERT INTO `kl_area` VALUES ('422', '72', null, '市辖区', '130801');
INSERT INTO `kl_area` VALUES ('423', '45', null, '河北区', '120105');
INSERT INTO `kl_area` VALUES ('424', '72', null, '双桥区', '130802');
INSERT INTO `kl_area` VALUES ('425', '45', null, '红桥区', '120106');
INSERT INTO `kl_area` VALUES ('426', '72', null, '双滦区', '130803');
INSERT INTO `kl_area` VALUES ('427', '45', null, '东丽区', '120110');
INSERT INTO `kl_area` VALUES ('428', '102', null, '市辖区', '140701');
INSERT INTO `kl_area` VALUES ('429', '72', null, '鹰手营子矿区', '130804');
INSERT INTO `kl_area` VALUES ('430', '102', null, '榆次区', '140702');
INSERT INTO `kl_area` VALUES ('431', '45', null, '西青区', '120111');
INSERT INTO `kl_area` VALUES ('432', '72', null, '承德县', '130821');
INSERT INTO `kl_area` VALUES ('433', '45', null, '津南区', '120112');
INSERT INTO `kl_area` VALUES ('434', '102', null, '榆社县', '140721');
INSERT INTO `kl_area` VALUES ('435', '72', null, '兴隆县', '130822');
INSERT INTO `kl_area` VALUES ('436', '102', null, '左权县', '140722');
INSERT INTO `kl_area` VALUES ('437', '45', null, '北辰区', '120113');
INSERT INTO `kl_area` VALUES ('438', '72', null, '平泉县', '130823');
INSERT INTO `kl_area` VALUES ('439', '102', null, '和顺县', '140723');
INSERT INTO `kl_area` VALUES ('440', '45', null, '武清区', '120114');
INSERT INTO `kl_area` VALUES ('441', '72', null, '滦平县', '130824');
INSERT INTO `kl_area` VALUES ('442', '45', null, '宝坻区', '120115');
INSERT INTO `kl_area` VALUES ('443', '102', null, '昔阳县', '140724');
INSERT INTO `kl_area` VALUES ('444', '72', null, '隆化县', '130825');
INSERT INTO `kl_area` VALUES ('445', '45', null, '滨海新区', '120116');
INSERT INTO `kl_area` VALUES ('446', '102', null, '寿阳县', '140725');
INSERT INTO `kl_area` VALUES ('447', '72', null, '丰宁满族自治县', '130826');
INSERT INTO `kl_area` VALUES ('448', '102', null, '太谷县', '140726');
INSERT INTO `kl_area` VALUES ('449', '72', null, '宽城满族自治县', '130827');
INSERT INTO `kl_area` VALUES ('450', '102', null, '祁县', '140727');
INSERT INTO `kl_area` VALUES ('451', '72', null, '围场满族蒙古族自治县', '130828');
INSERT INTO `kl_area` VALUES ('452', '102', null, '平遥县', '140728');
INSERT INTO `kl_area` VALUES ('453', '102', null, '灵石县', '140729');
INSERT INTO `kl_area` VALUES ('454', '102', null, '介休市', '140781');
INSERT INTO `kl_area` VALUES ('455', '46', null, '宁河县', '120221');
INSERT INTO `kl_area` VALUES ('456', '46', null, '静海县', '120223');
INSERT INTO `kl_area` VALUES ('457', '46', null, '蓟县', '120225');
INSERT INTO `kl_area` VALUES ('458', '74', null, '市辖区', '130901');
INSERT INTO `kl_area` VALUES ('459', '74', null, '新华区', '130902');
INSERT INTO `kl_area` VALUES ('460', '74', null, '运河区', '130903');
INSERT INTO `kl_area` VALUES ('461', '105', null, '市辖区', '140801');
INSERT INTO `kl_area` VALUES ('462', '74', null, '沧县', '130921');
INSERT INTO `kl_area` VALUES ('463', '105', null, '盐湖区', '140802');
INSERT INTO `kl_area` VALUES ('464', '74', null, '青县', '130922');
INSERT INTO `kl_area` VALUES ('465', '105', null, '临猗县', '140821');
INSERT INTO `kl_area` VALUES ('466', '74', null, '东光县', '130923');
INSERT INTO `kl_area` VALUES ('467', '105', null, '万荣县', '140822');
INSERT INTO `kl_area` VALUES ('468', '74', null, '海兴县', '130924');
INSERT INTO `kl_area` VALUES ('469', '105', null, '闻喜县', '140823');
INSERT INTO `kl_area` VALUES ('470', '74', null, '盐山县', '130925');
INSERT INTO `kl_area` VALUES ('471', '105', null, '稷山县', '140824');
INSERT INTO `kl_area` VALUES ('472', '74', null, '肃宁县', '130926');
INSERT INTO `kl_area` VALUES ('473', '105', null, '新绛县', '140825');
INSERT INTO `kl_area` VALUES ('474', '74', null, '南皮县', '130927');
INSERT INTO `kl_area` VALUES ('475', '105', null, '绛县', '140826');
INSERT INTO `kl_area` VALUES ('476', '74', null, '吴桥县', '130928');
INSERT INTO `kl_area` VALUES ('477', '105', null, '垣曲县', '140827');
INSERT INTO `kl_area` VALUES ('478', '74', null, '献县', '130929');
INSERT INTO `kl_area` VALUES ('479', '105', null, '夏县', '140828');
INSERT INTO `kl_area` VALUES ('480', '58', null, '市辖区', '130101');
INSERT INTO `kl_area` VALUES ('481', '74', null, '孟村回族自治县', '130930');
INSERT INTO `kl_area` VALUES ('482', '58', null, '长安区', '130102');
INSERT INTO `kl_area` VALUES ('483', '105', null, '平陆县', '140829');
INSERT INTO `kl_area` VALUES ('484', '74', null, '泊头市', '130981');
INSERT INTO `kl_area` VALUES ('485', '58', null, '桥东区', '130103');
INSERT INTO `kl_area` VALUES ('486', '105', null, '芮城县', '140830');
INSERT INTO `kl_area` VALUES ('487', '74', null, '任丘市', '130982');
INSERT INTO `kl_area` VALUES ('488', '58', null, '桥西区', '130104');
INSERT INTO `kl_area` VALUES ('489', '105', null, '永济市', '140881');
INSERT INTO `kl_area` VALUES ('490', '74', null, '黄骅市', '130983');
INSERT INTO `kl_area` VALUES ('491', '105', null, '河津市', '140882');
INSERT INTO `kl_area` VALUES ('492', '58', null, '新华区', '130105');
INSERT INTO `kl_area` VALUES ('493', '74', null, '河间市', '130984');
INSERT INTO `kl_area` VALUES ('494', '58', null, '井陉矿区', '130107');
INSERT INTO `kl_area` VALUES ('495', '58', null, '裕华区', '130108');
INSERT INTO `kl_area` VALUES ('496', '58', null, '井陉县', '130121');
INSERT INTO `kl_area` VALUES ('497', '58', null, '正定县', '130123');
INSERT INTO `kl_area` VALUES ('498', '58', null, '栾城县', '130124');
INSERT INTO `kl_area` VALUES ('499', '58', null, '行唐县', '130125');
INSERT INTO `kl_area` VALUES ('500', '58', null, '灵寿县', '130126');
INSERT INTO `kl_area` VALUES ('501', '58', null, '高邑县', '130127');
INSERT INTO `kl_area` VALUES ('502', '58', null, '深泽县', '130128');
INSERT INTO `kl_area` VALUES ('503', '58', null, '赞皇县', '130129');
INSERT INTO `kl_area` VALUES ('504', '58', null, '无极县', '130130');
INSERT INTO `kl_area` VALUES ('505', '58', null, '平山县', '130131');
INSERT INTO `kl_area` VALUES ('506', '58', null, '元氏县', '130132');
INSERT INTO `kl_area` VALUES ('507', '58', null, '赵县', '130133');
INSERT INTO `kl_area` VALUES ('508', '58', null, '辛集市', '130181');
INSERT INTO `kl_area` VALUES ('509', '107', null, '市辖区', '140901');
INSERT INTO `kl_area` VALUES ('510', '58', null, '藁城市', '130182');
INSERT INTO `kl_area` VALUES ('511', '77', null, '市辖区', '131001');
INSERT INTO `kl_area` VALUES ('512', '107', null, '忻府区', '140902');
INSERT INTO `kl_area` VALUES ('513', '58', null, '晋州市', '130183');
INSERT INTO `kl_area` VALUES ('514', '77', null, '安次区', '131002');
INSERT INTO `kl_area` VALUES ('515', '107', null, '定襄县', '140921');
INSERT INTO `kl_area` VALUES ('516', '58', null, '新乐市', '130184');
INSERT INTO `kl_area` VALUES ('517', '77', null, '广阳区', '131003');
INSERT INTO `kl_area` VALUES ('518', '107', null, '五台县', '140922');
INSERT INTO `kl_area` VALUES ('519', '58', null, '鹿泉市', '130185');
INSERT INTO `kl_area` VALUES ('520', '77', null, '固安县', '131022');
INSERT INTO `kl_area` VALUES ('521', '107', null, '代县', '140923');
INSERT INTO `kl_area` VALUES ('522', '77', null, '永清县', '131023');
INSERT INTO `kl_area` VALUES ('523', '107', null, '繁峙县', '140924');
INSERT INTO `kl_area` VALUES ('524', '77', null, '香河县', '131024');
INSERT INTO `kl_area` VALUES ('525', '107', null, '宁武县', '140925');
INSERT INTO `kl_area` VALUES ('526', '77', null, '大城县', '131025');
INSERT INTO `kl_area` VALUES ('527', '107', null, '静乐县', '140926');
INSERT INTO `kl_area` VALUES ('528', '77', null, '文安县', '131026');
INSERT INTO `kl_area` VALUES ('529', '107', null, '神池县', '140927');
INSERT INTO `kl_area` VALUES ('530', '77', null, '大厂回族自治县', '131028');
INSERT INTO `kl_area` VALUES ('531', '107', null, '五寨县', '140928');
INSERT INTO `kl_area` VALUES ('532', '77', null, '霸州市', '131081');
INSERT INTO `kl_area` VALUES ('533', '107', null, '岢岚县', '140929');
INSERT INTO `kl_area` VALUES ('534', '77', null, '三河市', '131082');
INSERT INTO `kl_area` VALUES ('535', '107', null, '河曲县', '140930');
INSERT INTO `kl_area` VALUES ('536', '107', null, '保德县', '140931');
INSERT INTO `kl_area` VALUES ('537', '107', null, '偏关县', '140932');
INSERT INTO `kl_area` VALUES ('538', '107', null, '原平市', '140981');
INSERT INTO `kl_area` VALUES ('539', '60', null, '市辖区', '130201');
INSERT INTO `kl_area` VALUES ('540', '60', null, '路南区', '130202');
INSERT INTO `kl_area` VALUES ('541', '60', null, '路北区', '130203');
INSERT INTO `kl_area` VALUES ('542', '60', null, '古冶区', '130204');
INSERT INTO `kl_area` VALUES ('543', '60', null, '开平区', '130205');
INSERT INTO `kl_area` VALUES ('544', '60', null, '丰南区', '130207');
INSERT INTO `kl_area` VALUES ('545', '60', null, '丰润区', '130208');
INSERT INTO `kl_area` VALUES ('546', '60', null, '曹妃甸区', '130209');
INSERT INTO `kl_area` VALUES ('547', '60', null, '滦县', '130223');
INSERT INTO `kl_area` VALUES ('548', '60', null, '滦南县', '130224');
INSERT INTO `kl_area` VALUES ('549', '60', null, '乐亭县', '130225');
INSERT INTO `kl_area` VALUES ('550', '60', null, '迁西县', '130227');
INSERT INTO `kl_area` VALUES ('551', '60', null, '玉田县', '130229');
INSERT INTO `kl_area` VALUES ('552', '79', null, '市辖区', '131101');
INSERT INTO `kl_area` VALUES ('553', '60', null, '遵化市', '130281');
INSERT INTO `kl_area` VALUES ('554', '60', null, '迁安市', '130283');
INSERT INTO `kl_area` VALUES ('555', '79', null, '桃城区', '131102');
INSERT INTO `kl_area` VALUES ('556', '109', null, '市辖区', '141001');
INSERT INTO `kl_area` VALUES ('557', '79', null, '枣强县', '131121');
INSERT INTO `kl_area` VALUES ('558', '109', null, '尧都区', '141002');
INSERT INTO `kl_area` VALUES ('559', '79', null, '武邑县', '131122');
INSERT INTO `kl_area` VALUES ('560', '109', null, '曲沃县', '141021');
INSERT INTO `kl_area` VALUES ('561', '79', null, '武强县', '131123');
INSERT INTO `kl_area` VALUES ('562', '109', null, '翼城县', '141022');
INSERT INTO `kl_area` VALUES ('563', '79', null, '饶阳县', '131124');
INSERT INTO `kl_area` VALUES ('564', '109', null, '襄汾县', '141023');
INSERT INTO `kl_area` VALUES ('565', '79', null, '安平县', '131125');
INSERT INTO `kl_area` VALUES ('566', '109', null, '洪洞县', '141024');
INSERT INTO `kl_area` VALUES ('567', '79', null, '故城县', '131126');
INSERT INTO `kl_area` VALUES ('568', '109', null, '古县', '141025');
INSERT INTO `kl_area` VALUES ('569', '79', null, '景县', '131127');
INSERT INTO `kl_area` VALUES ('570', '109', null, '安泽县', '141026');
INSERT INTO `kl_area` VALUES ('571', '79', null, '阜城县', '131128');
INSERT INTO `kl_area` VALUES ('572', '109', null, '浮山县', '141027');
INSERT INTO `kl_area` VALUES ('573', '79', null, '冀州市', '131181');
INSERT INTO `kl_area` VALUES ('574', '109', null, '吉县', '141028');
INSERT INTO `kl_area` VALUES ('575', '79', null, '深州市', '131182');
INSERT INTO `kl_area` VALUES ('576', '109', null, '乡宁县', '141029');
INSERT INTO `kl_area` VALUES ('577', '109', null, '大宁县', '141030');
INSERT INTO `kl_area` VALUES ('578', '109', null, '隰县', '141031');
INSERT INTO `kl_area` VALUES ('579', '109', null, '永和县', '141032');
INSERT INTO `kl_area` VALUES ('580', '62', null, '市辖区', '130301');
INSERT INTO `kl_area` VALUES ('581', '109', null, '蒲县', '141033');
INSERT INTO `kl_area` VALUES ('582', '62', null, '海港区', '130302');
INSERT INTO `kl_area` VALUES ('583', '109', null, '汾西县', '141034');
INSERT INTO `kl_area` VALUES ('584', '62', null, '山海关区', '130303');
INSERT INTO `kl_area` VALUES ('585', '109', null, '侯马市', '141081');
INSERT INTO `kl_area` VALUES ('586', '62', null, '北戴河区', '130304');
INSERT INTO `kl_area` VALUES ('587', '109', null, '霍州市', '141082');
INSERT INTO `kl_area` VALUES ('588', '62', null, '青龙满族自治县', '130321');
INSERT INTO `kl_area` VALUES ('589', '62', null, '昌黎县', '130322');
INSERT INTO `kl_area` VALUES ('590', '62', null, '抚宁县', '130323');
INSERT INTO `kl_area` VALUES ('591', '62', null, '卢龙县', '130324');
INSERT INTO `kl_area` VALUES ('592', '84', null, '市辖区', '140101');
INSERT INTO `kl_area` VALUES ('593', '84', null, '小店区', '140105');
INSERT INTO `kl_area` VALUES ('594', '84', null, '迎泽区', '140106');
INSERT INTO `kl_area` VALUES ('595', '84', null, '杏花岭区', '140107');
INSERT INTO `kl_area` VALUES ('596', '84', null, '尖草坪区', '140108');
INSERT INTO `kl_area` VALUES ('597', '84', null, '万柏林区', '140109');
INSERT INTO `kl_area` VALUES ('598', '84', null, '晋源区', '140110');
INSERT INTO `kl_area` VALUES ('599', '84', null, '清徐县', '140121');
INSERT INTO `kl_area` VALUES ('600', '84', null, '阳曲县', '140122');
INSERT INTO `kl_area` VALUES ('601', '84', null, '娄烦县', '140123');
INSERT INTO `kl_area` VALUES ('602', '84', null, '古交市', '140181');
INSERT INTO `kl_area` VALUES ('603', '111', null, '市辖区', '141101');
INSERT INTO `kl_area` VALUES ('604', '111', null, '离石区', '141102');
INSERT INTO `kl_area` VALUES ('605', '111', null, '文水县', '141121');
INSERT INTO `kl_area` VALUES ('606', '64', null, '市辖区', '130401');
INSERT INTO `kl_area` VALUES ('607', '111', null, '交城县', '141122');
INSERT INTO `kl_area` VALUES ('608', '64', null, '邯山区', '130402');
INSERT INTO `kl_area` VALUES ('609', '111', null, '兴县', '141123');
INSERT INTO `kl_area` VALUES ('610', '64', null, '丛台区', '130403');
INSERT INTO `kl_area` VALUES ('611', '111', null, '临县', '141124');
INSERT INTO `kl_area` VALUES ('612', '64', null, '复兴区', '130404');
INSERT INTO `kl_area` VALUES ('613', '111', null, '柳林县', '141125');
INSERT INTO `kl_area` VALUES ('614', '64', null, '峰峰矿区', '130406');
INSERT INTO `kl_area` VALUES ('615', '111', null, '石楼县', '141126');
INSERT INTO `kl_area` VALUES ('616', '64', null, '邯郸县', '130421');
INSERT INTO `kl_area` VALUES ('617', '111', null, '岚县', '141127');
INSERT INTO `kl_area` VALUES ('618', '64', null, '临漳县', '130423');
INSERT INTO `kl_area` VALUES ('619', '111', null, '方山县', '141128');
INSERT INTO `kl_area` VALUES ('620', '64', null, '成安县', '130424');
INSERT INTO `kl_area` VALUES ('621', '111', null, '中阳县', '141129');
INSERT INTO `kl_area` VALUES ('622', '64', null, '大名县', '130425');
INSERT INTO `kl_area` VALUES ('623', '111', null, '交口县', '141130');
INSERT INTO `kl_area` VALUES ('624', '64', null, '涉县', '130426');
INSERT INTO `kl_area` VALUES ('625', '111', null, '孝义市', '141181');
INSERT INTO `kl_area` VALUES ('626', '88', null, '市辖区', '140201');
INSERT INTO `kl_area` VALUES ('627', '64', null, '磁县', '130427');
INSERT INTO `kl_area` VALUES ('628', '111', null, '汾阳市', '141182');
INSERT INTO `kl_area` VALUES ('629', '88', null, '城区', '140202');
INSERT INTO `kl_area` VALUES ('630', '64', null, '肥乡县', '130428');
INSERT INTO `kl_area` VALUES ('631', '64', null, '永年县', '130429');
INSERT INTO `kl_area` VALUES ('632', '88', null, '矿区', '140203');
INSERT INTO `kl_area` VALUES ('633', '64', null, '邱县', '130430');
INSERT INTO `kl_area` VALUES ('634', '88', null, '南郊区', '140211');
INSERT INTO `kl_area` VALUES ('635', '64', null, '鸡泽县', '130431');
INSERT INTO `kl_area` VALUES ('636', '88', null, '新荣区', '140212');
INSERT INTO `kl_area` VALUES ('637', '64', null, '广平县', '130432');
INSERT INTO `kl_area` VALUES ('638', '88', null, '阳高县', '140221');
INSERT INTO `kl_area` VALUES ('639', '64', null, '馆陶县', '130433');
INSERT INTO `kl_area` VALUES ('640', '88', null, '天镇县', '140222');
INSERT INTO `kl_area` VALUES ('641', '64', null, '魏县', '130434');
INSERT INTO `kl_area` VALUES ('642', '88', null, '广灵县', '140223');
INSERT INTO `kl_area` VALUES ('643', '64', null, '曲周县', '130435');
INSERT INTO `kl_area` VALUES ('644', '88', null, '灵丘县', '140224');
INSERT INTO `kl_area` VALUES ('645', '64', null, '武安市', '130481');
INSERT INTO `kl_area` VALUES ('646', '88', null, '浑源县', '140225');
INSERT INTO `kl_area` VALUES ('647', '88', null, '左云县', '140226');
INSERT INTO `kl_area` VALUES ('648', '88', null, '大同县', '140227');
INSERT INTO `kl_area` VALUES ('649', '130', null, '市辖区', '150101');
INSERT INTO `kl_area` VALUES ('650', '130', null, '新城区', '150102');
INSERT INTO `kl_area` VALUES ('651', '130', null, '回民区', '150103');
INSERT INTO `kl_area` VALUES ('652', '130', null, '玉泉区', '150104');
INSERT INTO `kl_area` VALUES ('653', '130', null, '赛罕区', '150105');
INSERT INTO `kl_area` VALUES ('654', '130', null, '土默特左旗', '150121');
INSERT INTO `kl_area` VALUES ('655', '130', null, '托克托县', '150122');
INSERT INTO `kl_area` VALUES ('656', '130', null, '和林格尔县', '150123');
INSERT INTO `kl_area` VALUES ('657', '130', null, '清水河县', '150124');
INSERT INTO `kl_area` VALUES ('658', '130', null, '武川县', '150125');
INSERT INTO `kl_area` VALUES ('659', '66', null, '市辖区', '130501');
INSERT INTO `kl_area` VALUES ('660', '66', null, '桥东区', '130502');
INSERT INTO `kl_area` VALUES ('661', '66', null, '桥西区', '130503');
INSERT INTO `kl_area` VALUES ('662', '91', null, '市辖区', '140301');
INSERT INTO `kl_area` VALUES ('663', '66', null, '邢台县', '130521');
INSERT INTO `kl_area` VALUES ('664', '91', null, '城区', '140302');
INSERT INTO `kl_area` VALUES ('665', '66', null, '临城县', '130522');
INSERT INTO `kl_area` VALUES ('666', '91', null, '矿区', '140303');
INSERT INTO `kl_area` VALUES ('667', '66', null, '内丘县', '130523');
INSERT INTO `kl_area` VALUES ('668', '91', null, '郊区', '140311');
INSERT INTO `kl_area` VALUES ('669', '66', null, '柏乡县', '130524');
INSERT INTO `kl_area` VALUES ('670', '132', null, '市辖区', '150201');
INSERT INTO `kl_area` VALUES ('671', '91', null, '平定县', '140321');
INSERT INTO `kl_area` VALUES ('672', '66', null, '隆尧县', '130525');
INSERT INTO `kl_area` VALUES ('673', '132', null, '东河区', '150202');
INSERT INTO `kl_area` VALUES ('674', '66', null, '任县', '130526');
INSERT INTO `kl_area` VALUES ('675', '91', null, '盂县', '140322');
INSERT INTO `kl_area` VALUES ('676', '132', null, '昆都仑区', '150203');
INSERT INTO `kl_area` VALUES ('677', '66', null, '南和县', '130527');
INSERT INTO `kl_area` VALUES ('678', '132', null, '青山区', '150204');
INSERT INTO `kl_area` VALUES ('679', '66', null, '宁晋县', '130528');
INSERT INTO `kl_area` VALUES ('680', '132', null, '石拐区', '150205');
INSERT INTO `kl_area` VALUES ('681', '66', null, '巨鹿县', '130529');
INSERT INTO `kl_area` VALUES ('682', '132', null, '白云鄂博矿区', '150206');
INSERT INTO `kl_area` VALUES ('683', '66', null, '新河县', '130530');
INSERT INTO `kl_area` VALUES ('684', '132', null, '九原区', '150207');
INSERT INTO `kl_area` VALUES ('685', '66', null, '广宗县', '130531');
INSERT INTO `kl_area` VALUES ('686', '132', null, '土默特右旗', '150221');
INSERT INTO `kl_area` VALUES ('687', '66', null, '平乡县', '130532');
INSERT INTO `kl_area` VALUES ('688', '132', null, '固阳县', '150222');
INSERT INTO `kl_area` VALUES ('689', '66', null, '威县', '130533');
INSERT INTO `kl_area` VALUES ('690', '132', null, '达尔罕茂明安联合旗', '150223');
INSERT INTO `kl_area` VALUES ('691', '66', null, '清河县', '130534');
INSERT INTO `kl_area` VALUES ('692', '66', null, '临西县', '130535');
INSERT INTO `kl_area` VALUES ('693', '66', null, '南宫市', '130581');
INSERT INTO `kl_area` VALUES ('694', '66', null, '沙河市', '130582');
INSERT INTO `kl_area` VALUES ('695', '94', null, '市辖区', '140401');
INSERT INTO `kl_area` VALUES ('696', '94', null, '城区', '140402');
INSERT INTO `kl_area` VALUES ('697', '94', null, '郊区', '140411');
INSERT INTO `kl_area` VALUES ('698', '94', null, '长治县', '140421');
INSERT INTO `kl_area` VALUES ('699', '94', null, '襄垣县', '140423');
INSERT INTO `kl_area` VALUES ('700', '94', null, '屯留县', '140424');
INSERT INTO `kl_area` VALUES ('701', '94', null, '平顺县', '140425');
INSERT INTO `kl_area` VALUES ('702', '94', null, '黎城县', '140426');
INSERT INTO `kl_area` VALUES ('703', '94', null, '壶关县', '140427');
INSERT INTO `kl_area` VALUES ('704', '94', null, '长子县', '140428');
INSERT INTO `kl_area` VALUES ('705', '94', null, '武乡县', '140429');
INSERT INTO `kl_area` VALUES ('706', '94', null, '沁县', '140430');
INSERT INTO `kl_area` VALUES ('707', '94', null, '沁源县', '140431');
INSERT INTO `kl_area` VALUES ('708', '94', null, '潞城市', '140481');
INSERT INTO `kl_area` VALUES ('709', '134', null, '市辖区', '150301');
INSERT INTO `kl_area` VALUES ('710', '134', null, '海勃湾区', '150302');
INSERT INTO `kl_area` VALUES ('711', '134', null, '海南区', '150303');
INSERT INTO `kl_area` VALUES ('712', '134', null, '乌达区', '150304');
INSERT INTO `kl_area` VALUES ('713', '68', null, '市辖区', '130601');
INSERT INTO `kl_area` VALUES ('714', '68', null, '新市区', '130602');
INSERT INTO `kl_area` VALUES ('715', '68', null, '北市区', '130603');
INSERT INTO `kl_area` VALUES ('716', '68', null, '南市区', '130604');
INSERT INTO `kl_area` VALUES ('717', '68', null, '满城县', '130621');
INSERT INTO `kl_area` VALUES ('718', '68', null, '清苑县', '130622');
INSERT INTO `kl_area` VALUES ('719', '68', null, '涞水县', '130623');
INSERT INTO `kl_area` VALUES ('720', '68', null, '阜平县', '130624');
INSERT INTO `kl_area` VALUES ('721', '68', null, '徐水县', '130625');
INSERT INTO `kl_area` VALUES ('722', '68', null, '定兴县', '130626');
INSERT INTO `kl_area` VALUES ('723', '68', null, '唐县', '130627');
INSERT INTO `kl_area` VALUES ('724', '68', null, '高阳县', '130628');
INSERT INTO `kl_area` VALUES ('725', '68', null, '容城县', '130629');
INSERT INTO `kl_area` VALUES ('726', '68', null, '涞源县', '130630');
INSERT INTO `kl_area` VALUES ('727', '68', null, '望都县', '130631');
INSERT INTO `kl_area` VALUES ('728', '68', null, '安新县', '130632');
INSERT INTO `kl_area` VALUES ('729', '68', null, '易县', '130633');
INSERT INTO `kl_area` VALUES ('730', '68', null, '曲阳县', '130634');
INSERT INTO `kl_area` VALUES ('731', '68', null, '蠡县', '130635');
INSERT INTO `kl_area` VALUES ('732', '97', null, '市辖区', '140501');
INSERT INTO `kl_area` VALUES ('733', '68', null, '顺平县', '130636');
INSERT INTO `kl_area` VALUES ('734', '97', null, '城区', '140502');
INSERT INTO `kl_area` VALUES ('735', '68', null, '博野县', '130637');
INSERT INTO `kl_area` VALUES ('736', '97', null, '沁水县', '140521');
INSERT INTO `kl_area` VALUES ('737', '68', null, '雄县', '130638');
INSERT INTO `kl_area` VALUES ('738', '135', null, '市辖区', '150401');
INSERT INTO `kl_area` VALUES ('739', '97', null, '阳城县', '140522');
INSERT INTO `kl_area` VALUES ('740', '68', null, '涿州市', '130681');
INSERT INTO `kl_area` VALUES ('741', '135', null, '红山区', '150402');
INSERT INTO `kl_area` VALUES ('742', '97', null, '陵川县', '140524');
INSERT INTO `kl_area` VALUES ('743', '135', null, '元宝山区', '150403');
INSERT INTO `kl_area` VALUES ('744', '68', null, '定州市', '130682');
INSERT INTO `kl_area` VALUES ('745', '97', null, '泽州县', '140525');
INSERT INTO `kl_area` VALUES ('746', '68', null, '安国市', '130683');
INSERT INTO `kl_area` VALUES ('747', '135', null, '松山区', '150404');
INSERT INTO `kl_area` VALUES ('748', '97', null, '高平市', '140581');
INSERT INTO `kl_area` VALUES ('749', '135', null, '阿鲁科尔沁旗', '150421');
INSERT INTO `kl_area` VALUES ('750', '68', null, '高碑店市', '130684');
INSERT INTO `kl_area` VALUES ('751', '135', null, '巴林左旗', '150422');
INSERT INTO `kl_area` VALUES ('752', '135', null, '巴林右旗', '150423');
INSERT INTO `kl_area` VALUES ('753', '135', null, '林西县', '150424');
INSERT INTO `kl_area` VALUES ('754', '135', null, '克什克腾旗', '150425');
INSERT INTO `kl_area` VALUES ('755', '135', null, '翁牛特旗', '150426');
INSERT INTO `kl_area` VALUES ('756', '135', null, '喀喇沁旗', '150428');
INSERT INTO `kl_area` VALUES ('757', '135', null, '宁城县', '150429');
INSERT INTO `kl_area` VALUES ('758', '135', null, '敖汉旗', '150430');
INSERT INTO `kl_area` VALUES ('759', '136', null, '市辖区', '150501');
INSERT INTO `kl_area` VALUES ('760', '136', null, '科尔沁区', '150502');
INSERT INTO `kl_area` VALUES ('761', '136', null, '科尔沁左翼中旗', '150521');
INSERT INTO `kl_area` VALUES ('762', '136', null, '科尔沁左翼后旗', '150522');
INSERT INTO `kl_area` VALUES ('763', '136', null, '开鲁县', '150523');
INSERT INTO `kl_area` VALUES ('764', '136', null, '库伦旗', '150524');
INSERT INTO `kl_area` VALUES ('765', '136', null, '奈曼旗', '150525');
INSERT INTO `kl_area` VALUES ('766', '136', null, '扎鲁特旗', '150526');
INSERT INTO `kl_area` VALUES ('767', '136', null, '霍林郭勒市', '150581');
INSERT INTO `kl_area` VALUES ('768', '173', null, '市辖区', '210301');
INSERT INTO `kl_area` VALUES ('769', '173', null, '铁东区', '210302');
INSERT INTO `kl_area` VALUES ('770', '173', null, '铁西区', '210303');
INSERT INTO `kl_area` VALUES ('771', '173', null, '立山区', '210304');
INSERT INTO `kl_area` VALUES ('772', '173', null, '千山区', '210311');
INSERT INTO `kl_area` VALUES ('773', '173', null, '台安县', '210321');
INSERT INTO `kl_area` VALUES ('774', '173', null, '岫岩满族自治县', '210323');
INSERT INTO `kl_area` VALUES ('775', '173', null, '海城市', '210381');
INSERT INTO `kl_area` VALUES ('776', '137', null, '市辖区', '150601');
INSERT INTO `kl_area` VALUES ('777', '137', null, '东胜区', '150602');
INSERT INTO `kl_area` VALUES ('778', '137', null, '达拉特旗', '150621');
INSERT INTO `kl_area` VALUES ('779', '137', null, '准格尔旗', '150622');
INSERT INTO `kl_area` VALUES ('780', '137', null, '鄂托克前旗', '150623');
INSERT INTO `kl_area` VALUES ('781', '137', null, '鄂托克旗', '150624');
INSERT INTO `kl_area` VALUES ('782', '137', null, '杭锦旗', '150625');
INSERT INTO `kl_area` VALUES ('783', '137', null, '乌审旗', '150626');
INSERT INTO `kl_area` VALUES ('784', '137', null, '伊金霍洛旗', '150627');
INSERT INTO `kl_area` VALUES ('785', '175', null, '市辖区', '210401');
INSERT INTO `kl_area` VALUES ('786', '175', null, '新抚区', '210402');
INSERT INTO `kl_area` VALUES ('787', '175', null, '东洲区', '210403');
INSERT INTO `kl_area` VALUES ('788', '175', null, '望花区', '210404');
INSERT INTO `kl_area` VALUES ('789', '175', null, '顺城区', '210411');
INSERT INTO `kl_area` VALUES ('790', '175', null, '抚顺县', '210421');
INSERT INTO `kl_area` VALUES ('791', '175', null, '新宾满族自治县', '210422');
INSERT INTO `kl_area` VALUES ('792', '175', null, '清原满族自治县', '210423');
INSERT INTO `kl_area` VALUES ('793', '138', null, '市辖区', '150701');
INSERT INTO `kl_area` VALUES ('794', '138', null, '海拉尔区', '150702');
INSERT INTO `kl_area` VALUES ('795', '138', null, '扎赉诺尔区', '150703');
INSERT INTO `kl_area` VALUES ('796', '138', null, '阿荣旗', '150721');
INSERT INTO `kl_area` VALUES ('797', '138', null, '莫力达瓦达斡尔族自治旗', '150722');
INSERT INTO `kl_area` VALUES ('798', '138', null, '鄂伦春自治旗', '150723');
INSERT INTO `kl_area` VALUES ('799', '138', null, '鄂温克族自治旗', '150724');
INSERT INTO `kl_area` VALUES ('800', '138', null, '陈巴尔虎旗', '150725');
INSERT INTO `kl_area` VALUES ('801', '138', null, '新巴尔虎左旗', '150726');
INSERT INTO `kl_area` VALUES ('802', '138', null, '新巴尔虎右旗', '150727');
INSERT INTO `kl_area` VALUES ('803', '138', null, '满洲里市', '150781');
INSERT INTO `kl_area` VALUES ('804', '138', null, '牙克石市', '150782');
INSERT INTO `kl_area` VALUES ('805', '138', null, '扎兰屯市', '150783');
INSERT INTO `kl_area` VALUES ('806', '138', null, '额尔古纳市', '150784');
INSERT INTO `kl_area` VALUES ('807', '138', null, '根河市', '150785');
INSERT INTO `kl_area` VALUES ('808', '177', null, '市辖区', '210501');
INSERT INTO `kl_area` VALUES ('809', '177', null, '平山区', '210502');
INSERT INTO `kl_area` VALUES ('810', '177', null, '溪湖区', '210503');
INSERT INTO `kl_area` VALUES ('811', '177', null, '明山区', '210504');
INSERT INTO `kl_area` VALUES ('812', '177', null, '南芬区', '210505');
INSERT INTO `kl_area` VALUES ('813', '177', null, '本溪满族自治县', '210521');
INSERT INTO `kl_area` VALUES ('814', '177', null, '桓仁满族自治县', '210522');
INSERT INTO `kl_area` VALUES ('815', '140', null, '市辖区', '150801');
INSERT INTO `kl_area` VALUES ('816', '140', null, '临河区', '150802');
INSERT INTO `kl_area` VALUES ('817', '140', null, '五原县', '150821');
INSERT INTO `kl_area` VALUES ('818', '140', null, '磴口县', '150822');
INSERT INTO `kl_area` VALUES ('819', '140', null, '乌拉特前旗', '150823');
INSERT INTO `kl_area` VALUES ('820', '140', null, '乌拉特中旗', '150824');
INSERT INTO `kl_area` VALUES ('821', '140', null, '乌拉特后旗', '150825');
INSERT INTO `kl_area` VALUES ('822', '140', null, '杭锦后旗', '150826');
INSERT INTO `kl_area` VALUES ('823', '179', null, '市辖区', '210601');
INSERT INTO `kl_area` VALUES ('824', '179', null, '元宝区', '210602');
INSERT INTO `kl_area` VALUES ('825', '179', null, '振兴区', '210603');
INSERT INTO `kl_area` VALUES ('826', '179', null, '振安区', '210604');
INSERT INTO `kl_area` VALUES ('827', '179', null, '宽甸满族自治县', '210624');
INSERT INTO `kl_area` VALUES ('828', '179', null, '东港市', '210681');
INSERT INTO `kl_area` VALUES ('829', '179', null, '凤城市', '210682');
INSERT INTO `kl_area` VALUES ('830', '142', null, '市辖区', '150901');
INSERT INTO `kl_area` VALUES ('831', '142', null, '集宁区', '150902');
INSERT INTO `kl_area` VALUES ('832', '142', null, '卓资县', '150921');
INSERT INTO `kl_area` VALUES ('833', '142', null, '化德县', '150922');
INSERT INTO `kl_area` VALUES ('834', '142', null, '商都县', '150923');
INSERT INTO `kl_area` VALUES ('835', '142', null, '兴和县', '150924');
INSERT INTO `kl_area` VALUES ('836', '142', null, '凉城县', '150925');
INSERT INTO `kl_area` VALUES ('837', '142', null, '察哈尔右翼前旗', '150926');
INSERT INTO `kl_area` VALUES ('838', '142', null, '察哈尔右翼中旗', '150927');
INSERT INTO `kl_area` VALUES ('839', '142', null, '察哈尔右翼后旗', '150928');
INSERT INTO `kl_area` VALUES ('840', '142', null, '四子王旗', '150929');
INSERT INTO `kl_area` VALUES ('841', '142', null, '丰镇市', '150981');
INSERT INTO `kl_area` VALUES ('842', '181', null, '市辖区', '210701');
INSERT INTO `kl_area` VALUES ('843', '181', null, '古塔区', '210702');
INSERT INTO `kl_area` VALUES ('844', '181', null, '凌河区', '210703');
INSERT INTO `kl_area` VALUES ('845', '181', null, '太和区', '210711');
INSERT INTO `kl_area` VALUES ('846', '181', null, '黑山县', '210726');
INSERT INTO `kl_area` VALUES ('847', '181', null, '义县', '210727');
INSERT INTO `kl_area` VALUES ('848', '181', null, '凌海市', '210781');
INSERT INTO `kl_area` VALUES ('849', '181', null, '北镇市', '210782');
INSERT INTO `kl_area` VALUES ('850', '144', null, '乌兰浩特市', '152201');
INSERT INTO `kl_area` VALUES ('851', '144', null, '阿尔山市', '152202');
INSERT INTO `kl_area` VALUES ('852', '144', null, '科尔沁右翼前旗', '152221');
INSERT INTO `kl_area` VALUES ('853', '144', null, '科尔沁右翼中旗', '152222');
INSERT INTO `kl_area` VALUES ('854', '144', null, '扎赉特旗', '152223');
INSERT INTO `kl_area` VALUES ('855', '144', null, '突泉县', '152224');
INSERT INTO `kl_area` VALUES ('856', '183', null, '市辖区', '210801');
INSERT INTO `kl_area` VALUES ('857', '183', null, '站前区', '210802');
INSERT INTO `kl_area` VALUES ('858', '183', null, '西市区', '210803');
INSERT INTO `kl_area` VALUES ('859', '183', null, '鲅鱼圈区', '210804');
INSERT INTO `kl_area` VALUES ('860', '183', null, '老边区', '210811');
INSERT INTO `kl_area` VALUES ('861', '183', null, '盖州市', '210881');
INSERT INTO `kl_area` VALUES ('862', '183', null, '大石桥市', '210882');
INSERT INTO `kl_area` VALUES ('863', '146', null, '二连浩特市', '152501');
INSERT INTO `kl_area` VALUES ('864', '146', null, '锡林浩特市', '152502');
INSERT INTO `kl_area` VALUES ('865', '146', null, '阿巴嘎旗', '152522');
INSERT INTO `kl_area` VALUES ('866', '146', null, '苏尼特左旗', '152523');
INSERT INTO `kl_area` VALUES ('867', '146', null, '苏尼特右旗', '152524');
INSERT INTO `kl_area` VALUES ('868', '146', null, '东乌珠穆沁旗', '152525');
INSERT INTO `kl_area` VALUES ('869', '146', null, '西乌珠穆沁旗', '152526');
INSERT INTO `kl_area` VALUES ('870', '146', null, '太仆寺旗', '152527');
INSERT INTO `kl_area` VALUES ('871', '146', null, '镶黄旗', '152528');
INSERT INTO `kl_area` VALUES ('872', '146', null, '正镶白旗', '152529');
INSERT INTO `kl_area` VALUES ('873', '185', null, '市辖区', '210901');
INSERT INTO `kl_area` VALUES ('874', '146', null, '正蓝旗', '152530');
INSERT INTO `kl_area` VALUES ('875', '185', null, '海州区', '210902');
INSERT INTO `kl_area` VALUES ('876', '146', null, '多伦县', '152531');
INSERT INTO `kl_area` VALUES ('877', '185', null, '新邱区', '210903');
INSERT INTO `kl_area` VALUES ('878', '185', null, '太平区', '210904');
INSERT INTO `kl_area` VALUES ('879', '185', null, '清河门区', '210905');
INSERT INTO `kl_area` VALUES ('880', '185', null, '细河区', '210911');
INSERT INTO `kl_area` VALUES ('881', '185', null, '阜新蒙古族自治县', '210921');
INSERT INTO `kl_area` VALUES ('882', '185', null, '彰武县', '210922');
INSERT INTO `kl_area` VALUES ('883', '148', null, '阿拉善左旗', '152921');
INSERT INTO `kl_area` VALUES ('884', '148', null, '阿拉善右旗', '152922');
INSERT INTO `kl_area` VALUES ('885', '148', null, '额济纳旗', '152923');
INSERT INTO `kl_area` VALUES ('886', '187', null, '市辖区', '211001');
INSERT INTO `kl_area` VALUES ('887', '187', null, '白塔区', '211002');
INSERT INTO `kl_area` VALUES ('888', '187', null, '文圣区', '211003');
INSERT INTO `kl_area` VALUES ('889', '187', null, '宏伟区', '211004');
INSERT INTO `kl_area` VALUES ('890', '187', null, '弓长岭区', '211005');
INSERT INTO `kl_area` VALUES ('891', '187', null, '太子河区', '211011');
INSERT INTO `kl_area` VALUES ('892', '187', null, '辽阳县', '211021');
INSERT INTO `kl_area` VALUES ('893', '187', null, '灯塔市', '211081');
INSERT INTO `kl_area` VALUES ('894', '168', null, '市辖区', '210101');
INSERT INTO `kl_area` VALUES ('895', '168', null, '和平区', '210102');
INSERT INTO `kl_area` VALUES ('896', '168', null, '沈河区', '210103');
INSERT INTO `kl_area` VALUES ('897', '168', null, '大东区', '210104');
INSERT INTO `kl_area` VALUES ('898', '168', null, '皇姑区', '210105');
INSERT INTO `kl_area` VALUES ('899', '168', null, '铁西区', '210106');
INSERT INTO `kl_area` VALUES ('900', '168', null, '苏家屯区', '210111');
INSERT INTO `kl_area` VALUES ('901', '168', null, '东陵区', '210112');
INSERT INTO `kl_area` VALUES ('902', '168', null, '沈北新区', '210113');
INSERT INTO `kl_area` VALUES ('903', '168', null, '于洪区', '210114');
INSERT INTO `kl_area` VALUES ('904', '168', null, '辽中县', '210122');
INSERT INTO `kl_area` VALUES ('905', '168', null, '康平县', '210123');
INSERT INTO `kl_area` VALUES ('906', '189', null, '市辖区', '211101');
INSERT INTO `kl_area` VALUES ('907', '168', null, '法库县', '210124');
INSERT INTO `kl_area` VALUES ('908', '189', null, '双台子区', '211102');
INSERT INTO `kl_area` VALUES ('909', '168', null, '新民市', '210181');
INSERT INTO `kl_area` VALUES ('910', '189', null, '兴隆台区', '211103');
INSERT INTO `kl_area` VALUES ('911', '189', null, '大洼县', '211121');
INSERT INTO `kl_area` VALUES ('912', '189', null, '盘山县', '211122');
INSERT INTO `kl_area` VALUES ('913', '170', null, '市辖区', '210201');
INSERT INTO `kl_area` VALUES ('914', '191', null, '市辖区', '211201');
INSERT INTO `kl_area` VALUES ('915', '170', null, '中山区', '210202');
INSERT INTO `kl_area` VALUES ('916', '191', null, '银州区', '211202');
INSERT INTO `kl_area` VALUES ('917', '170', null, '西岗区', '210203');
INSERT INTO `kl_area` VALUES ('918', '170', null, '沙河口区', '210204');
INSERT INTO `kl_area` VALUES ('919', '191', null, '清河区', '211204');
INSERT INTO `kl_area` VALUES ('920', '170', null, '甘井子区', '210211');
INSERT INTO `kl_area` VALUES ('921', '170', null, '旅顺口区', '210212');
INSERT INTO `kl_area` VALUES ('922', '191', null, '铁岭县', '211221');
INSERT INTO `kl_area` VALUES ('923', '170', null, '金州区', '210213');
INSERT INTO `kl_area` VALUES ('924', '191', null, '西丰县', '211223');
INSERT INTO `kl_area` VALUES ('925', '170', null, '长海县', '210224');
INSERT INTO `kl_area` VALUES ('926', '191', null, '昌图县', '211224');
INSERT INTO `kl_area` VALUES ('927', '170', null, '瓦房店市', '210281');
INSERT INTO `kl_area` VALUES ('928', '191', null, '调兵山市', '211281');
INSERT INTO `kl_area` VALUES ('929', '170', null, '普兰店市', '210282');
INSERT INTO `kl_area` VALUES ('930', '191', null, '开原市', '211282');
INSERT INTO `kl_area` VALUES ('931', '170', null, '庄河市', '210283');
INSERT INTO `kl_area` VALUES ('932', '193', null, '市辖区', '211301');
INSERT INTO `kl_area` VALUES ('933', '193', null, '双塔区', '211302');
INSERT INTO `kl_area` VALUES ('934', '193', null, '龙城区', '211303');
INSERT INTO `kl_area` VALUES ('935', '193', null, '朝阳县', '211321');
INSERT INTO `kl_area` VALUES ('936', '193', null, '建平县', '211322');
INSERT INTO `kl_area` VALUES ('937', '193', null, '喀喇沁左翼蒙古族自治县', '211324');
INSERT INTO `kl_area` VALUES ('938', '193', null, '北票市', '211381');
INSERT INTO `kl_area` VALUES ('939', '193', null, '凌源市', '211382');
INSERT INTO `kl_area` VALUES ('940', '229', null, '延吉市', '222401');
INSERT INTO `kl_area` VALUES ('941', '229', null, '图们市', '222402');
INSERT INTO `kl_area` VALUES ('942', '229', null, '敦化市', '222403');
INSERT INTO `kl_area` VALUES ('943', '229', null, '珲春市', '222404');
INSERT INTO `kl_area` VALUES ('944', '229', null, '龙井市', '222405');
INSERT INTO `kl_area` VALUES ('945', '229', null, '和龙市', '222406');
INSERT INTO `kl_area` VALUES ('946', '229', null, '汪清县', '222424');
INSERT INTO `kl_area` VALUES ('947', '229', null, '安图县', '222426');
INSERT INTO `kl_area` VALUES ('948', '195', null, '市辖区', '211401');
INSERT INTO `kl_area` VALUES ('949', '195', null, '连山区', '211402');
INSERT INTO `kl_area` VALUES ('950', '195', null, '龙港区', '211403');
INSERT INTO `kl_area` VALUES ('951', '195', null, '南票区', '211404');
INSERT INTO `kl_area` VALUES ('952', '195', null, '绥中县', '211421');
INSERT INTO `kl_area` VALUES ('953', '195', null, '建昌县', '211422');
INSERT INTO `kl_area` VALUES ('954', '195', null, '兴城市', '211481');
INSERT INTO `kl_area` VALUES ('955', '264', null, '市辖区', '231001');
INSERT INTO `kl_area` VALUES ('956', '264', null, '东安区', '231002');
INSERT INTO `kl_area` VALUES ('957', '264', null, '阳明区', '231003');
INSERT INTO `kl_area` VALUES ('958', '264', null, '爱民区', '231004');
INSERT INTO `kl_area` VALUES ('959', '264', null, '西安区', '231005');
INSERT INTO `kl_area` VALUES ('960', '264', null, '东宁县', '231024');
INSERT INTO `kl_area` VALUES ('961', '264', null, '林口县', '231025');
INSERT INTO `kl_area` VALUES ('962', '264', null, '绥芬河市', '231081');
INSERT INTO `kl_area` VALUES ('963', '241', null, '市辖区', '230101');
INSERT INTO `kl_area` VALUES ('964', '264', null, '海林市', '231083');
INSERT INTO `kl_area` VALUES ('965', '241', null, '道里区', '230102');
INSERT INTO `kl_area` VALUES ('966', '264', null, '宁安市', '231084');
INSERT INTO `kl_area` VALUES ('967', '241', null, '南岗区', '230103');
INSERT INTO `kl_area` VALUES ('968', '264', null, '穆棱市', '231085');
INSERT INTO `kl_area` VALUES ('969', '241', null, '道外区', '230104');
INSERT INTO `kl_area` VALUES ('970', '241', null, '平房区', '230108');
INSERT INTO `kl_area` VALUES ('971', '241', null, '松北区', '230109');
INSERT INTO `kl_area` VALUES ('972', '213', null, '市辖区', '220101');
INSERT INTO `kl_area` VALUES ('973', '241', null, '香坊区', '230110');
INSERT INTO `kl_area` VALUES ('974', '213', null, '南关区', '220102');
INSERT INTO `kl_area` VALUES ('975', '241', null, '呼兰区', '230111');
INSERT INTO `kl_area` VALUES ('976', '213', null, '宽城区', '220103');
INSERT INTO `kl_area` VALUES ('977', '241', null, '阿城区', '230112');
INSERT INTO `kl_area` VALUES ('978', '213', null, '朝阳区', '220104');
INSERT INTO `kl_area` VALUES ('979', '241', null, '依兰县', '230123');
INSERT INTO `kl_area` VALUES ('980', '213', null, '二道区', '220105');
INSERT INTO `kl_area` VALUES ('981', '241', null, '方正县', '230124');
INSERT INTO `kl_area` VALUES ('982', '213', null, '绿园区', '220106');
INSERT INTO `kl_area` VALUES ('983', '241', null, '宾县', '230125');
INSERT INTO `kl_area` VALUES ('984', '213', null, '双阳区', '220112');
INSERT INTO `kl_area` VALUES ('985', '241', null, '巴彦县', '230126');
INSERT INTO `kl_area` VALUES ('986', '213', null, '农安县', '220122');
INSERT INTO `kl_area` VALUES ('987', '241', null, '木兰县', '230127');
INSERT INTO `kl_area` VALUES ('988', '213', null, '九台市', '220181');
INSERT INTO `kl_area` VALUES ('989', '241', null, '通河县', '230128');
INSERT INTO `kl_area` VALUES ('990', '213', null, '榆树市', '220182');
INSERT INTO `kl_area` VALUES ('991', '241', null, '延寿县', '230129');
INSERT INTO `kl_area` VALUES ('992', '213', null, '德惠市', '220183');
INSERT INTO `kl_area` VALUES ('993', '241', null, '双城市', '230182');
INSERT INTO `kl_area` VALUES ('994', '266', null, '市辖区', '231101');
INSERT INTO `kl_area` VALUES ('995', '241', null, '尚志市', '230183');
INSERT INTO `kl_area` VALUES ('996', '266', null, '爱辉区', '231102');
INSERT INTO `kl_area` VALUES ('997', '241', null, '五常市', '230184');
INSERT INTO `kl_area` VALUES ('998', '266', null, '嫩江县', '231121');
INSERT INTO `kl_area` VALUES ('999', '266', null, '逊克县', '231123');
INSERT INTO `kl_area` VALUES ('1000', '266', null, '孙吴县', '231124');
INSERT INTO `kl_area` VALUES ('1001', '266', null, '北安市', '231181');
INSERT INTO `kl_area` VALUES ('1002', '266', null, '五大连池市', '231182');
INSERT INTO `kl_area` VALUES ('1003', '215', null, '市辖区', '220201');
INSERT INTO `kl_area` VALUES ('1004', '215', null, '昌邑区', '220202');
INSERT INTO `kl_area` VALUES ('1005', '215', null, '龙潭区', '220203');
INSERT INTO `kl_area` VALUES ('1006', '215', null, '船营区', '220204');
INSERT INTO `kl_area` VALUES ('1007', '215', null, '丰满区', '220211');
INSERT INTO `kl_area` VALUES ('1008', '215', null, '永吉县', '220221');
INSERT INTO `kl_area` VALUES ('1009', '243', null, '市辖区', '230201');
INSERT INTO `kl_area` VALUES ('1010', '215', null, '蛟河市', '220281');
INSERT INTO `kl_area` VALUES ('1011', '243', null, '龙沙区', '230202');
INSERT INTO `kl_area` VALUES ('1012', '215', null, '桦甸市', '220282');
INSERT INTO `kl_area` VALUES ('1013', '243', null, '建华区', '230203');
INSERT INTO `kl_area` VALUES ('1014', '243', null, '铁锋区', '230204');
INSERT INTO `kl_area` VALUES ('1015', '215', null, '舒兰市', '220283');
INSERT INTO `kl_area` VALUES ('1016', '268', null, '市辖区', '231201');
INSERT INTO `kl_area` VALUES ('1017', '243', null, '昂昂溪区', '230205');
INSERT INTO `kl_area` VALUES ('1018', '268', null, '北林区', '231202');
INSERT INTO `kl_area` VALUES ('1019', '215', null, '磐石市', '220284');
INSERT INTO `kl_area` VALUES ('1020', '243', null, '富拉尔基区', '230206');
INSERT INTO `kl_area` VALUES ('1021', '243', null, '碾子山区', '230207');
INSERT INTO `kl_area` VALUES ('1022', '268', null, '望奎县', '231221');
INSERT INTO `kl_area` VALUES ('1023', '243', null, '梅里斯达斡尔族区', '230208');
INSERT INTO `kl_area` VALUES ('1024', '243', null, '龙江县', '230221');
INSERT INTO `kl_area` VALUES ('1025', '268', null, '兰西县', '231222');
INSERT INTO `kl_area` VALUES ('1026', '243', null, '依安县', '230223');
INSERT INTO `kl_area` VALUES ('1027', '268', null, '青冈县', '231223');
INSERT INTO `kl_area` VALUES ('1028', '243', null, '泰来县', '230224');
INSERT INTO `kl_area` VALUES ('1029', '243', null, '甘南县', '230225');
INSERT INTO `kl_area` VALUES ('1030', '268', null, '庆安县', '231224');
INSERT INTO `kl_area` VALUES ('1031', '243', null, '富裕县', '230227');
INSERT INTO `kl_area` VALUES ('1032', '268', null, '明水县', '231225');
INSERT INTO `kl_area` VALUES ('1033', '243', null, '克山县', '230229');
INSERT INTO `kl_area` VALUES ('1034', '268', null, '绥棱县', '231226');
INSERT INTO `kl_area` VALUES ('1035', '243', null, '克东县', '230230');
INSERT INTO `kl_area` VALUES ('1036', '268', null, '安达市', '231281');
INSERT INTO `kl_area` VALUES ('1037', '243', null, '拜泉县', '230231');
INSERT INTO `kl_area` VALUES ('1038', '268', null, '肇东市', '231282');
INSERT INTO `kl_area` VALUES ('1039', '243', null, '讷河市', '230281');
INSERT INTO `kl_area` VALUES ('1040', '268', null, '海伦市', '231283');
INSERT INTO `kl_area` VALUES ('1041', '217', null, '市辖区', '220301');
INSERT INTO `kl_area` VALUES ('1042', '217', null, '铁西区', '220302');
INSERT INTO `kl_area` VALUES ('1043', '217', null, '铁东区', '220303');
INSERT INTO `kl_area` VALUES ('1044', '217', null, '梨树县', '220322');
INSERT INTO `kl_area` VALUES ('1045', '217', null, '伊通满族自治县', '220323');
INSERT INTO `kl_area` VALUES ('1046', '217', null, '公主岭市', '220381');
INSERT INTO `kl_area` VALUES ('1047', '217', null, '双辽市', '220382');
INSERT INTO `kl_area` VALUES ('1048', '245', null, '市辖区', '230301');
INSERT INTO `kl_area` VALUES ('1049', '245', null, '鸡冠区', '230302');
INSERT INTO `kl_area` VALUES ('1050', '270', null, '呼玛县', '232721');
INSERT INTO `kl_area` VALUES ('1051', '245', null, '恒山区', '230303');
INSERT INTO `kl_area` VALUES ('1052', '270', null, '塔河县', '232722');
INSERT INTO `kl_area` VALUES ('1053', '245', null, '滴道区', '230304');
INSERT INTO `kl_area` VALUES ('1054', '270', null, '漠河县', '232723');
INSERT INTO `kl_area` VALUES ('1055', '245', null, '梨树区', '230305');
INSERT INTO `kl_area` VALUES ('1056', '245', null, '城子河区', '230306');
INSERT INTO `kl_area` VALUES ('1057', '245', null, '麻山区', '230307');
INSERT INTO `kl_area` VALUES ('1058', '245', null, '鸡东县', '230321');
INSERT INTO `kl_area` VALUES ('1059', '219', null, '市辖区', '220401');
INSERT INTO `kl_area` VALUES ('1060', '245', null, '虎林市', '230381');
INSERT INTO `kl_area` VALUES ('1061', '219', null, '龙山区', '220402');
INSERT INTO `kl_area` VALUES ('1062', '245', null, '密山市', '230382');
INSERT INTO `kl_area` VALUES ('1063', '219', null, '西安区', '220403');
INSERT INTO `kl_area` VALUES ('1064', '219', null, '东丰县', '220421');
INSERT INTO `kl_area` VALUES ('1065', '219', null, '东辽县', '220422');
INSERT INTO `kl_area` VALUES ('1066', '284', null, '黄浦区', '310101');
INSERT INTO `kl_area` VALUES ('1067', '284', null, '徐汇区', '310104');
INSERT INTO `kl_area` VALUES ('1068', '284', null, '长宁区', '310105');
INSERT INTO `kl_area` VALUES ('1069', '284', null, '静安区', '310106');
INSERT INTO `kl_area` VALUES ('1070', '284', null, '普陀区', '310107');
INSERT INTO `kl_area` VALUES ('1071', '284', null, '闸北区', '310108');
INSERT INTO `kl_area` VALUES ('1072', '284', null, '虹口区', '310109');
INSERT INTO `kl_area` VALUES ('1073', '284', null, '杨浦区', '310110');
INSERT INTO `kl_area` VALUES ('1074', '284', null, '闵行区', '310112');
INSERT INTO `kl_area` VALUES ('1075', '248', null, '市辖区', '230401');
INSERT INTO `kl_area` VALUES ('1076', '284', null, '宝山区', '310113');
INSERT INTO `kl_area` VALUES ('1077', '221', null, '市辖区', '220501');
INSERT INTO `kl_area` VALUES ('1078', '248', null, '向阳区', '230402');
INSERT INTO `kl_area` VALUES ('1079', '221', null, '东昌区', '220502');
INSERT INTO `kl_area` VALUES ('1080', '284', null, '嘉定区', '310114');
INSERT INTO `kl_area` VALUES ('1081', '248', null, '工农区', '230403');
INSERT INTO `kl_area` VALUES ('1082', '221', null, '二道江区', '220503');
INSERT INTO `kl_area` VALUES ('1083', '284', null, '浦东新区', '310115');
INSERT INTO `kl_area` VALUES ('1084', '248', null, '南山区', '230404');
INSERT INTO `kl_area` VALUES ('1085', '284', null, '金山区', '310116');
INSERT INTO `kl_area` VALUES ('1086', '221', null, '通化县', '220521');
INSERT INTO `kl_area` VALUES ('1087', '248', null, '兴安区', '230405');
INSERT INTO `kl_area` VALUES ('1088', '221', null, '辉南县', '220523');
INSERT INTO `kl_area` VALUES ('1089', '284', null, '松江区', '310117');
INSERT INTO `kl_area` VALUES ('1090', '248', null, '东山区', '230406');
INSERT INTO `kl_area` VALUES ('1091', '284', null, '青浦区', '310118');
INSERT INTO `kl_area` VALUES ('1092', '221', null, '柳河县', '220524');
INSERT INTO `kl_area` VALUES ('1093', '248', null, '兴山区', '230407');
INSERT INTO `kl_area` VALUES ('1094', '221', null, '梅河口市', '220581');
INSERT INTO `kl_area` VALUES ('1095', '284', null, '奉贤区', '310120');
INSERT INTO `kl_area` VALUES ('1096', '248', null, '萝北县', '230421');
INSERT INTO `kl_area` VALUES ('1097', '221', null, '集安市', '220582');
INSERT INTO `kl_area` VALUES ('1098', '248', null, '绥滨县', '230422');
INSERT INTO `kl_area` VALUES ('1099', '287', null, '崇明县', '310230');
INSERT INTO `kl_area` VALUES ('1100', '223', null, '市辖区', '220601');
INSERT INTO `kl_area` VALUES ('1101', '251', null, '市辖区', '230501');
INSERT INTO `kl_area` VALUES ('1102', '223', null, '浑江区', '220602');
INSERT INTO `kl_area` VALUES ('1103', '251', null, '尖山区', '230502');
INSERT INTO `kl_area` VALUES ('1104', '223', null, '江源区', '220605');
INSERT INTO `kl_area` VALUES ('1105', '251', null, '岭东区', '230503');
INSERT INTO `kl_area` VALUES ('1106', '223', null, '抚松县', '220621');
INSERT INTO `kl_area` VALUES ('1107', '251', null, '四方台区', '230505');
INSERT INTO `kl_area` VALUES ('1108', '223', null, '靖宇县', '220622');
INSERT INTO `kl_area` VALUES ('1109', '251', null, '宝山区', '230506');
INSERT INTO `kl_area` VALUES ('1110', '223', null, '长白朝鲜族自治县', '220623');
INSERT INTO `kl_area` VALUES ('1111', '251', null, '集贤县', '230521');
INSERT INTO `kl_area` VALUES ('1112', '223', null, '临江市', '220681');
INSERT INTO `kl_area` VALUES ('1113', '251', null, '友谊县', '230522');
INSERT INTO `kl_area` VALUES ('1114', '251', null, '宝清县', '230523');
INSERT INTO `kl_area` VALUES ('1115', '251', null, '饶河县', '230524');
INSERT INTO `kl_area` VALUES ('1116', '301', null, '市辖区', '320101');
INSERT INTO `kl_area` VALUES ('1117', '301', null, '玄武区', '320102');
INSERT INTO `kl_area` VALUES ('1118', '301', null, '秦淮区', '320104');
INSERT INTO `kl_area` VALUES ('1119', '301', null, '建邺区', '320105');
INSERT INTO `kl_area` VALUES ('1120', '301', null, '鼓楼区', '320106');
INSERT INTO `kl_area` VALUES ('1121', '301', null, '浦口区', '320111');
INSERT INTO `kl_area` VALUES ('1122', '301', null, '栖霞区', '320113');
INSERT INTO `kl_area` VALUES ('1123', '301', null, '雨花台区', '320114');
INSERT INTO `kl_area` VALUES ('1124', '301', null, '江宁区', '320115');
INSERT INTO `kl_area` VALUES ('1125', '301', null, '六合区', '320116');
INSERT INTO `kl_area` VALUES ('1126', '301', null, '溧水区', '320117');
INSERT INTO `kl_area` VALUES ('1127', '301', null, '高淳区', '320118');
INSERT INTO `kl_area` VALUES ('1128', '225', null, '市辖区', '220701');
INSERT INTO `kl_area` VALUES ('1129', '225', null, '宁江区', '220702');
INSERT INTO `kl_area` VALUES ('1130', '225', null, '前郭尔罗斯蒙古族自治县', '220721');
INSERT INTO `kl_area` VALUES ('1131', '254', null, '市辖区', '230601');
INSERT INTO `kl_area` VALUES ('1132', '225', null, '长岭县', '220722');
INSERT INTO `kl_area` VALUES ('1133', '254', null, '萨尔图区', '230602');
INSERT INTO `kl_area` VALUES ('1134', '225', null, '乾安县', '220723');
INSERT INTO `kl_area` VALUES ('1135', '254', null, '龙凤区', '230603');
INSERT INTO `kl_area` VALUES ('1136', '225', null, '扶余市', '220781');
INSERT INTO `kl_area` VALUES ('1137', '254', null, '让胡路区', '230604');
INSERT INTO `kl_area` VALUES ('1138', '254', null, '红岗区', '230605');
INSERT INTO `kl_area` VALUES ('1139', '254', null, '大同区', '230606');
INSERT INTO `kl_area` VALUES ('1140', '254', null, '肇州县', '230621');
INSERT INTO `kl_area` VALUES ('1141', '254', null, '肇源县', '230622');
INSERT INTO `kl_area` VALUES ('1142', '254', null, '林甸县', '230623');
INSERT INTO `kl_area` VALUES ('1143', '254', null, '杜尔伯特蒙古族自治县', '230624');
INSERT INTO `kl_area` VALUES ('1144', '303', null, '市辖区', '320201');
INSERT INTO `kl_area` VALUES ('1145', '303', null, '崇安区', '320202');
INSERT INTO `kl_area` VALUES ('1146', '303', null, '南长区', '320203');
INSERT INTO `kl_area` VALUES ('1147', '303', null, '北塘区', '320204');
INSERT INTO `kl_area` VALUES ('1148', '303', null, '锡山区', '320205');
INSERT INTO `kl_area` VALUES ('1149', '303', null, '惠山区', '320206');
INSERT INTO `kl_area` VALUES ('1150', '303', null, '滨湖区', '320211');
INSERT INTO `kl_area` VALUES ('1151', '303', null, '江阴市', '320281');
INSERT INTO `kl_area` VALUES ('1152', '303', null, '宜兴市', '320282');
INSERT INTO `kl_area` VALUES ('1153', '227', null, '市辖区', '220801');
INSERT INTO `kl_area` VALUES ('1154', '227', null, '洮北区', '220802');
INSERT INTO `kl_area` VALUES ('1155', '227', null, '镇赉县', '220821');
INSERT INTO `kl_area` VALUES ('1156', '227', null, '通榆县', '220822');
INSERT INTO `kl_area` VALUES ('1157', '227', null, '洮南市', '220881');
INSERT INTO `kl_area` VALUES ('1158', '227', null, '大安市', '220882');
INSERT INTO `kl_area` VALUES ('1159', '257', null, '市辖区', '230701');
INSERT INTO `kl_area` VALUES ('1160', '257', null, '伊春区', '230702');
INSERT INTO `kl_area` VALUES ('1161', '257', null, '南岔区', '230703');
INSERT INTO `kl_area` VALUES ('1162', '257', null, '友好区', '230704');
INSERT INTO `kl_area` VALUES ('1163', '257', null, '西林区', '230705');
INSERT INTO `kl_area` VALUES ('1164', '257', null, '翠峦区', '230706');
INSERT INTO `kl_area` VALUES ('1165', '257', null, '新青区', '230707');
INSERT INTO `kl_area` VALUES ('1166', '257', null, '美溪区', '230708');
INSERT INTO `kl_area` VALUES ('1167', '257', null, '金山屯区', '230709');
INSERT INTO `kl_area` VALUES ('1168', '257', null, '五营区', '230710');
INSERT INTO `kl_area` VALUES ('1169', '257', null, '乌马河区', '230711');
INSERT INTO `kl_area` VALUES ('1170', '257', null, '汤旺河区', '230712');
INSERT INTO `kl_area` VALUES ('1171', '257', null, '带岭区', '230713');
INSERT INTO `kl_area` VALUES ('1172', '257', null, '乌伊岭区', '230714');
INSERT INTO `kl_area` VALUES ('1173', '305', null, '市辖区', '320301');
INSERT INTO `kl_area` VALUES ('1174', '257', null, '红星区', '230715');
INSERT INTO `kl_area` VALUES ('1175', '305', null, '鼓楼区', '320302');
INSERT INTO `kl_area` VALUES ('1176', '257', null, '上甘岭区', '230716');
INSERT INTO `kl_area` VALUES ('1177', '305', null, '云龙区', '320303');
INSERT INTO `kl_area` VALUES ('1178', '257', null, '嘉荫县', '230722');
INSERT INTO `kl_area` VALUES ('1179', '305', null, '贾汪区', '320305');
INSERT INTO `kl_area` VALUES ('1180', '257', null, '铁力市', '230781');
INSERT INTO `kl_area` VALUES ('1181', '305', null, '泉山区', '320311');
INSERT INTO `kl_area` VALUES ('1182', '305', null, '铜山区', '320312');
INSERT INTO `kl_area` VALUES ('1183', '305', null, '丰县', '320321');
INSERT INTO `kl_area` VALUES ('1184', '305', null, '沛县', '320322');
INSERT INTO `kl_area` VALUES ('1185', '305', null, '睢宁县', '320324');
INSERT INTO `kl_area` VALUES ('1186', '305', null, '新沂市', '320381');
INSERT INTO `kl_area` VALUES ('1187', '305', null, '邳州市', '320382');
INSERT INTO `kl_area` VALUES ('1188', '309', null, '市辖区', '320501');
INSERT INTO `kl_area` VALUES ('1189', '309', null, '虎丘区', '320505');
INSERT INTO `kl_area` VALUES ('1190', '309', null, '吴中区', '320506');
INSERT INTO `kl_area` VALUES ('1191', '309', null, '相城区', '320507');
INSERT INTO `kl_area` VALUES ('1192', '260', null, '市辖区', '230801');
INSERT INTO `kl_area` VALUES ('1193', '309', null, '姑苏区', '320508');
INSERT INTO `kl_area` VALUES ('1194', '260', null, '向阳区', '230803');
INSERT INTO `kl_area` VALUES ('1195', '309', null, '吴江区', '320509');
INSERT INTO `kl_area` VALUES ('1196', '260', null, '前进区', '230804');
INSERT INTO `kl_area` VALUES ('1197', '309', null, '常熟市', '320581');
INSERT INTO `kl_area` VALUES ('1198', '260', null, '东风区', '230805');
INSERT INTO `kl_area` VALUES ('1199', '309', null, '张家港市', '320582');
INSERT INTO `kl_area` VALUES ('1200', '260', null, '郊区', '230811');
INSERT INTO `kl_area` VALUES ('1201', '307', null, '市辖区', '320401');
INSERT INTO `kl_area` VALUES ('1202', '309', null, '昆山市', '320583');
INSERT INTO `kl_area` VALUES ('1203', '260', null, '桦南县', '230822');
INSERT INTO `kl_area` VALUES ('1204', '307', null, '天宁区', '320402');
INSERT INTO `kl_area` VALUES ('1205', '260', null, '桦川县', '230826');
INSERT INTO `kl_area` VALUES ('1206', '309', null, '太仓市', '320585');
INSERT INTO `kl_area` VALUES ('1207', '260', null, '汤原县', '230828');
INSERT INTO `kl_area` VALUES ('1208', '307', null, '钟楼区', '320404');
INSERT INTO `kl_area` VALUES ('1209', '260', null, '抚远县', '230833');
INSERT INTO `kl_area` VALUES ('1210', '307', null, '戚墅堰区', '320405');
INSERT INTO `kl_area` VALUES ('1211', '260', null, '同江市', '230881');
INSERT INTO `kl_area` VALUES ('1212', '307', null, '新北区', '320411');
INSERT INTO `kl_area` VALUES ('1213', '260', null, '富锦市', '230882');
INSERT INTO `kl_area` VALUES ('1214', '307', null, '武进区', '320412');
INSERT INTO `kl_area` VALUES ('1215', '307', null, '溧阳市', '320481');
INSERT INTO `kl_area` VALUES ('1216', '307', null, '金坛市', '320482');
INSERT INTO `kl_area` VALUES ('1217', '311', null, '市辖区', '320601');
INSERT INTO `kl_area` VALUES ('1218', '311', null, '崇川区', '320602');
INSERT INTO `kl_area` VALUES ('1219', '311', null, '港闸区', '320611');
INSERT INTO `kl_area` VALUES ('1220', '311', null, '通州区', '320612');
INSERT INTO `kl_area` VALUES ('1221', '311', null, '海安县', '320621');
INSERT INTO `kl_area` VALUES ('1222', '311', null, '如东县', '320623');
INSERT INTO `kl_area` VALUES ('1223', '262', null, '市辖区', '230901');
INSERT INTO `kl_area` VALUES ('1224', '311', null, '启东市', '320681');
INSERT INTO `kl_area` VALUES ('1225', '262', null, '新兴区', '230902');
INSERT INTO `kl_area` VALUES ('1226', '311', null, '如皋市', '320682');
INSERT INTO `kl_area` VALUES ('1227', '262', null, '桃山区', '230903');
INSERT INTO `kl_area` VALUES ('1228', '311', null, '海门市', '320684');
INSERT INTO `kl_area` VALUES ('1229', '262', null, '茄子河区', '230904');
INSERT INTO `kl_area` VALUES ('1230', '262', null, '勃利县', '230921');
INSERT INTO `kl_area` VALUES ('1231', '35', null, '市辖区', '330201');
INSERT INTO `kl_area` VALUES ('1232', '35', null, '海曙区', '330203');
INSERT INTO `kl_area` VALUES ('1233', '35', null, '江东区', '330204');
INSERT INTO `kl_area` VALUES ('1234', '35', null, '江北区', '330205');
INSERT INTO `kl_area` VALUES ('1235', '35', null, '北仑区', '330206');
INSERT INTO `kl_area` VALUES ('1236', '35', null, '镇海区', '330211');
INSERT INTO `kl_area` VALUES ('1237', '35', null, '鄞州区', '330212');
INSERT INTO `kl_area` VALUES ('1238', '35', null, '象山县', '330225');
INSERT INTO `kl_area` VALUES ('1239', '35', null, '宁海县', '330226');
INSERT INTO `kl_area` VALUES ('1240', '313', null, '市辖区', '320701');
INSERT INTO `kl_area` VALUES ('1241', '35', null, '余姚市', '330281');
INSERT INTO `kl_area` VALUES ('1242', '313', null, '连云区', '320703');
INSERT INTO `kl_area` VALUES ('1243', '35', null, '慈溪市', '330282');
INSERT INTO `kl_area` VALUES ('1244', '313', null, '新浦区', '320705');
INSERT INTO `kl_area` VALUES ('1245', '35', null, '奉化市', '330283');
INSERT INTO `kl_area` VALUES ('1246', '313', null, '海州区', '320706');
INSERT INTO `kl_area` VALUES ('1247', '313', null, '赣榆县', '320721');
INSERT INTO `kl_area` VALUES ('1248', '313', null, '东海县', '320722');
INSERT INTO `kl_area` VALUES ('1249', '313', null, '灌云县', '320723');
INSERT INTO `kl_area` VALUES ('1250', '313', null, '灌南县', '320724');
INSERT INTO `kl_area` VALUES ('1251', '36', null, '市辖区', '330301');
INSERT INTO `kl_area` VALUES ('1252', '36', null, '鹿城区', '330302');
INSERT INTO `kl_area` VALUES ('1253', '36', null, '龙湾区', '330303');
INSERT INTO `kl_area` VALUES ('1254', '36', null, '瓯海区', '330304');
INSERT INTO `kl_area` VALUES ('1255', '36', null, '洞头县', '330322');
INSERT INTO `kl_area` VALUES ('1256', '315', null, '市辖区', '320801');
INSERT INTO `kl_area` VALUES ('1257', '36', null, '永嘉县', '330324');
INSERT INTO `kl_area` VALUES ('1258', '315', null, '清河区', '320802');
INSERT INTO `kl_area` VALUES ('1259', '36', null, '平阳县', '330326');
INSERT INTO `kl_area` VALUES ('1260', '315', null, '淮安区', '320803');
INSERT INTO `kl_area` VALUES ('1261', '36', null, '苍南县', '330327');
INSERT INTO `kl_area` VALUES ('1262', '315', null, '淮阴区', '320804');
INSERT INTO `kl_area` VALUES ('1263', '36', null, '文成县', '330328');
INSERT INTO `kl_area` VALUES ('1264', '315', null, '清浦区', '320811');
INSERT INTO `kl_area` VALUES ('1265', '36', null, '泰顺县', '330329');
INSERT INTO `kl_area` VALUES ('1266', '315', null, '涟水县', '320826');
INSERT INTO `kl_area` VALUES ('1267', '36', null, '瑞安市', '330381');
INSERT INTO `kl_area` VALUES ('1268', '315', null, '洪泽县', '320829');
INSERT INTO `kl_area` VALUES ('1269', '36', null, '乐清市', '330382');
INSERT INTO `kl_area` VALUES ('1270', '315', null, '盱眙县', '320830');
INSERT INTO `kl_area` VALUES ('1271', '315', null, '金湖县', '320831');
INSERT INTO `kl_area` VALUES ('1272', '37', null, '市辖区', '330401');
INSERT INTO `kl_area` VALUES ('1273', '37', null, '南湖区', '330402');
INSERT INTO `kl_area` VALUES ('1274', '37', null, '秀洲区', '330411');
INSERT INTO `kl_area` VALUES ('1275', '319', null, '市辖区', '320901');
INSERT INTO `kl_area` VALUES ('1276', '37', null, '嘉善县', '330421');
INSERT INTO `kl_area` VALUES ('1277', '319', null, '亭湖区', '320902');
INSERT INTO `kl_area` VALUES ('1278', '37', null, '海盐县', '330424');
INSERT INTO `kl_area` VALUES ('1279', '319', null, '盐都区', '320903');
INSERT INTO `kl_area` VALUES ('1280', '37', null, '海宁市', '330481');
INSERT INTO `kl_area` VALUES ('1281', '319', null, '响水县', '320921');
INSERT INTO `kl_area` VALUES ('1282', '37', null, '平湖市', '330482');
INSERT INTO `kl_area` VALUES ('1283', '319', null, '滨海县', '320922');
INSERT INTO `kl_area` VALUES ('1284', '37', null, '桐乡市', '330483');
INSERT INTO `kl_area` VALUES ('1285', '319', null, '阜宁县', '320923');
INSERT INTO `kl_area` VALUES ('1286', '319', null, '射阳县', '320924');
INSERT INTO `kl_area` VALUES ('1287', '319', null, '建湖县', '320925');
INSERT INTO `kl_area` VALUES ('1288', '319', null, '东台市', '320981');
INSERT INTO `kl_area` VALUES ('1289', '319', null, '大丰市', '320982');
INSERT INTO `kl_area` VALUES ('1290', '38', null, '市辖区', '330501');
INSERT INTO `kl_area` VALUES ('1291', '38', null, '吴兴区', '330502');
INSERT INTO `kl_area` VALUES ('1292', '38', null, '南浔区', '330503');
INSERT INTO `kl_area` VALUES ('1293', '38', null, '德清县', '330521');
INSERT INTO `kl_area` VALUES ('1294', '322', null, '市辖区', '321001');
INSERT INTO `kl_area` VALUES ('1295', '38', null, '长兴县', '330522');
INSERT INTO `kl_area` VALUES ('1296', '322', null, '广陵区', '321002');
INSERT INTO `kl_area` VALUES ('1297', '38', null, '安吉县', '330523');
INSERT INTO `kl_area` VALUES ('1298', '322', null, '邗江区', '321003');
INSERT INTO `kl_area` VALUES ('1299', '322', null, '江都区', '321012');
INSERT INTO `kl_area` VALUES ('1300', '322', null, '宝应县', '321023');
INSERT INTO `kl_area` VALUES ('1301', '322', null, '仪征市', '321081');
INSERT INTO `kl_area` VALUES ('1302', '322', null, '高邮市', '321084');
INSERT INTO `kl_area` VALUES ('1303', '39', null, '市辖区', '330601');
INSERT INTO `kl_area` VALUES ('1304', '39', null, '越城区', '330602');
INSERT INTO `kl_area` VALUES ('1305', '39', null, '绍兴县', '330621');
INSERT INTO `kl_area` VALUES ('1306', '39', null, '新昌县', '330624');
INSERT INTO `kl_area` VALUES ('1307', '39', null, '诸暨市', '330681');
INSERT INTO `kl_area` VALUES ('1308', '324', null, '市辖区', '321101');
INSERT INTO `kl_area` VALUES ('1309', '39', null, '上虞市', '330682');
INSERT INTO `kl_area` VALUES ('1310', '324', null, '京口区', '321102');
INSERT INTO `kl_area` VALUES ('1311', '39', null, '嵊州市', '330683');
INSERT INTO `kl_area` VALUES ('1312', '324', null, '润州区', '321111');
INSERT INTO `kl_area` VALUES ('1313', '324', null, '丹徒区', '321112');
INSERT INTO `kl_area` VALUES ('1314', '324', null, '丹阳市', '321181');
INSERT INTO `kl_area` VALUES ('1315', '324', null, '扬中市', '321182');
INSERT INTO `kl_area` VALUES ('1316', '324', null, '句容市', '321183');
INSERT INTO `kl_area` VALUES ('1317', '40', null, '市辖区', '330701');
INSERT INTO `kl_area` VALUES ('1318', '40', null, '婺城区', '330702');
INSERT INTO `kl_area` VALUES ('1319', '40', null, '金东区', '330703');
INSERT INTO `kl_area` VALUES ('1320', '40', null, '武义县', '330723');
INSERT INTO `kl_area` VALUES ('1321', '40', null, '浦江县', '330726');
INSERT INTO `kl_area` VALUES ('1322', '328', null, '市辖区', '321201');
INSERT INTO `kl_area` VALUES ('1323', '40', null, '磐安县', '330727');
INSERT INTO `kl_area` VALUES ('1324', '328', null, '海陵区', '321202');
INSERT INTO `kl_area` VALUES ('1325', '40', null, '兰溪市', '330781');
INSERT INTO `kl_area` VALUES ('1326', '328', null, '高港区', '321203');
INSERT INTO `kl_area` VALUES ('1327', '40', null, '义乌市', '330782');
INSERT INTO `kl_area` VALUES ('1328', '328', null, '姜堰区', '321204');
INSERT INTO `kl_area` VALUES ('1329', '40', null, '东阳市', '330783');
INSERT INTO `kl_area` VALUES ('1330', '328', null, '兴化市', '321281');
INSERT INTO `kl_area` VALUES ('1331', '40', null, '永康市', '330784');
INSERT INTO `kl_area` VALUES ('1332', '328', null, '靖江市', '321282');
INSERT INTO `kl_area` VALUES ('1333', '328', null, '泰兴市', '321283');
INSERT INTO `kl_area` VALUES ('1334', '41', null, '市辖区', '330801');
INSERT INTO `kl_area` VALUES ('1335', '41', null, '柯城区', '330802');
INSERT INTO `kl_area` VALUES ('1336', '330', null, '市辖区', '321301');
INSERT INTO `kl_area` VALUES ('1337', '41', null, '衢江区', '330803');
INSERT INTO `kl_area` VALUES ('1338', '330', null, '宿城区', '321302');
INSERT INTO `kl_area` VALUES ('1339', '41', null, '常山县', '330822');
INSERT INTO `kl_area` VALUES ('1340', '330', null, '宿豫区', '321311');
INSERT INTO `kl_area` VALUES ('1341', '41', null, '开化县', '330824');
INSERT INTO `kl_area` VALUES ('1342', '330', null, '沭阳县', '321322');
INSERT INTO `kl_area` VALUES ('1343', '41', null, '龙游县', '330825');
INSERT INTO `kl_area` VALUES ('1344', '330', null, '泗阳县', '321323');
INSERT INTO `kl_area` VALUES ('1345', '41', null, '江山市', '330881');
INSERT INTO `kl_area` VALUES ('1346', '330', null, '泗洪县', '321324');
INSERT INTO `kl_area` VALUES ('1347', '42', null, '市辖区', '330901');
INSERT INTO `kl_area` VALUES ('1348', '34', null, '市辖区', '330101');
INSERT INTO `kl_area` VALUES ('1349', '42', null, '定海区', '330902');
INSERT INTO `kl_area` VALUES ('1350', '34', null, '上城区', '330102');
INSERT INTO `kl_area` VALUES ('1351', '42', null, '普陀区', '330903');
INSERT INTO `kl_area` VALUES ('1352', '34', null, '下城区', '330103');
INSERT INTO `kl_area` VALUES ('1353', '42', null, '岱山县', '330921');
INSERT INTO `kl_area` VALUES ('1354', '34', null, '江干区', '330104');
INSERT INTO `kl_area` VALUES ('1355', '42', null, '嵊泗县', '330922');
INSERT INTO `kl_area` VALUES ('1356', '34', null, '拱墅区', '330105');
INSERT INTO `kl_area` VALUES ('1357', '34', null, '西湖区', '330106');
INSERT INTO `kl_area` VALUES ('1358', '34', null, '滨江区', '330108');
INSERT INTO `kl_area` VALUES ('1359', '34', null, '萧山区', '330109');
INSERT INTO `kl_area` VALUES ('1360', '34', null, '余杭区', '330110');
INSERT INTO `kl_area` VALUES ('1361', '34', null, '桐庐县', '330122');
INSERT INTO `kl_area` VALUES ('1362', '34', null, '淳安县', '330127');
INSERT INTO `kl_area` VALUES ('1363', '34', null, '建德市', '330182');
INSERT INTO `kl_area` VALUES ('1364', '34', null, '富阳市', '330183');
INSERT INTO `kl_area` VALUES ('1365', '34', null, '临安市', '330185');
INSERT INTO `kl_area` VALUES ('1366', '43', null, '市辖区', '331001');
INSERT INTO `kl_area` VALUES ('1367', '43', null, '椒江区', '331002');
INSERT INTO `kl_area` VALUES ('1368', '43', null, '黄岩区', '331003');
INSERT INTO `kl_area` VALUES ('1369', '43', null, '路桥区', '331004');
INSERT INTO `kl_area` VALUES ('1370', '43', null, '玉环县', '331021');
INSERT INTO `kl_area` VALUES ('1371', '43', null, '三门县', '331022');
INSERT INTO `kl_area` VALUES ('1372', '43', null, '天台县', '331023');
INSERT INTO `kl_area` VALUES ('1373', '43', null, '仙居县', '331024');
INSERT INTO `kl_area` VALUES ('1374', '43', null, '温岭市', '331081');
INSERT INTO `kl_area` VALUES ('1375', '43', null, '临海市', '331082');
INSERT INTO `kl_area` VALUES ('1376', '44', null, '市辖区', '331101');
INSERT INTO `kl_area` VALUES ('1377', '44', null, '莲都区', '331102');
INSERT INTO `kl_area` VALUES ('1378', '44', null, '青田县', '331121');
INSERT INTO `kl_area` VALUES ('1379', '44', null, '缙云县', '331122');
INSERT INTO `kl_area` VALUES ('1380', '44', null, '遂昌县', '331123');
INSERT INTO `kl_area` VALUES ('1381', '44', null, '松阳县', '331124');
INSERT INTO `kl_area` VALUES ('1382', '44', null, '云和县', '331125');
INSERT INTO `kl_area` VALUES ('1383', '44', null, '庆元县', '331126');
INSERT INTO `kl_area` VALUES ('1384', '44', null, '景宁畲族自治县', '331127');
INSERT INTO `kl_area` VALUES ('1385', '44', null, '龙泉市', '331181');
INSERT INTO `kl_area` VALUES ('1386', '51', null, '市辖区', '340101');
INSERT INTO `kl_area` VALUES ('1387', '51', null, '瑶海区', '340102');
INSERT INTO `kl_area` VALUES ('1388', '51', null, '庐阳区', '340103');
INSERT INTO `kl_area` VALUES ('1389', '51', null, '蜀山区', '340104');
INSERT INTO `kl_area` VALUES ('1390', '51', null, '包河区', '340111');
INSERT INTO `kl_area` VALUES ('1391', '51', null, '长丰县', '340121');
INSERT INTO `kl_area` VALUES ('1392', '51', null, '肥东县', '340122');
INSERT INTO `kl_area` VALUES ('1393', '51', null, '肥西县', '340123');
INSERT INTO `kl_area` VALUES ('1394', '51', null, '庐江县', '340124');
INSERT INTO `kl_area` VALUES ('1395', '51', null, '巢湖市', '340181');
INSERT INTO `kl_area` VALUES ('1396', '65', null, '市辖区', '341201');
INSERT INTO `kl_area` VALUES ('1397', '65', null, '颍州区', '341202');
INSERT INTO `kl_area` VALUES ('1398', '65', null, '颍东区', '341203');
INSERT INTO `kl_area` VALUES ('1399', '65', null, '颍泉区', '341204');
INSERT INTO `kl_area` VALUES ('1400', '65', null, '临泉县', '341221');
INSERT INTO `kl_area` VALUES ('1401', '65', null, '太和县', '341222');
INSERT INTO `kl_area` VALUES ('1402', '65', null, '阜南县', '341225');
INSERT INTO `kl_area` VALUES ('1403', '65', null, '颍上县', '341226');
INSERT INTO `kl_area` VALUES ('1404', '52', null, '市辖区', '340201');
INSERT INTO `kl_area` VALUES ('1405', '65', null, '界首市', '341282');
INSERT INTO `kl_area` VALUES ('1406', '52', null, '镜湖区', '340202');
INSERT INTO `kl_area` VALUES ('1407', '52', null, '弋江区', '340203');
INSERT INTO `kl_area` VALUES ('1408', '52', null, '鸠江区', '340207');
INSERT INTO `kl_area` VALUES ('1409', '52', null, '三山区', '340208');
INSERT INTO `kl_area` VALUES ('1410', '52', null, '芜湖县', '340221');
INSERT INTO `kl_area` VALUES ('1411', '52', null, '繁昌县', '340222');
INSERT INTO `kl_area` VALUES ('1412', '52', null, '南陵县', '340223');
INSERT INTO `kl_area` VALUES ('1413', '52', null, '无为县', '340225');
INSERT INTO `kl_area` VALUES ('1414', '89', null, '市辖区', '350501');
INSERT INTO `kl_area` VALUES ('1415', '89', null, '鲤城区', '350502');
INSERT INTO `kl_area` VALUES ('1416', '89', null, '丰泽区', '350503');
INSERT INTO `kl_area` VALUES ('1417', '89', null, '洛江区', '350504');
INSERT INTO `kl_area` VALUES ('1418', '89', null, '泉港区', '350505');
INSERT INTO `kl_area` VALUES ('1419', '89', null, '惠安县', '350521');
INSERT INTO `kl_area` VALUES ('1420', '89', null, '安溪县', '350524');
INSERT INTO `kl_area` VALUES ('1421', '89', null, '永春县', '350525');
INSERT INTO `kl_area` VALUES ('1422', '89', null, '德化县', '350526');
INSERT INTO `kl_area` VALUES ('1423', '89', null, '金门县', '350527');
INSERT INTO `kl_area` VALUES ('1424', '89', null, '石狮市', '350581');
INSERT INTO `kl_area` VALUES ('1425', '89', null, '晋江市', '350582');
INSERT INTO `kl_area` VALUES ('1426', '89', null, '南安市', '350583');
INSERT INTO `kl_area` VALUES ('1427', '67', null, '市辖区', '341301');
INSERT INTO `kl_area` VALUES ('1428', '67', null, '埇桥区', '341302');
INSERT INTO `kl_area` VALUES ('1429', '67', null, '砀山县', '341321');
INSERT INTO `kl_area` VALUES ('1430', '67', null, '萧县', '341322');
INSERT INTO `kl_area` VALUES ('1431', '67', null, '灵璧县', '341323');
INSERT INTO `kl_area` VALUES ('1432', '67', null, '泗县', '341324');
INSERT INTO `kl_area` VALUES ('1433', '53', null, '市辖区', '340301');
INSERT INTO `kl_area` VALUES ('1434', '53', null, '龙子湖区', '340302');
INSERT INTO `kl_area` VALUES ('1435', '53', null, '蚌山区', '340303');
INSERT INTO `kl_area` VALUES ('1436', '53', null, '禹会区', '340304');
INSERT INTO `kl_area` VALUES ('1437', '53', null, '淮上区', '340311');
INSERT INTO `kl_area` VALUES ('1438', '53', null, '怀远县', '340321');
INSERT INTO `kl_area` VALUES ('1439', '53', null, '五河县', '340322');
INSERT INTO `kl_area` VALUES ('1440', '53', null, '固镇县', '340323');
INSERT INTO `kl_area` VALUES ('1441', '92', null, '市辖区', '350601');
INSERT INTO `kl_area` VALUES ('1442', '92', null, '芗城区', '350602');
INSERT INTO `kl_area` VALUES ('1443', '92', null, '龙文区', '350603');
INSERT INTO `kl_area` VALUES ('1444', '92', null, '云霄县', '350622');
INSERT INTO `kl_area` VALUES ('1445', '92', null, '漳浦县', '350623');
INSERT INTO `kl_area` VALUES ('1446', '92', null, '诏安县', '350624');
INSERT INTO `kl_area` VALUES ('1447', '92', null, '长泰县', '350625');
INSERT INTO `kl_area` VALUES ('1448', '92', null, '东山县', '350626');
INSERT INTO `kl_area` VALUES ('1449', '69', null, '市辖区', '341501');
INSERT INTO `kl_area` VALUES ('1450', '92', null, '南靖县', '350627');
INSERT INTO `kl_area` VALUES ('1451', '69', null, '金安区', '341502');
INSERT INTO `kl_area` VALUES ('1452', '92', null, '平和县', '350628');
INSERT INTO `kl_area` VALUES ('1453', '69', null, '裕安区', '341503');
INSERT INTO `kl_area` VALUES ('1454', '92', null, '华安县', '350629');
INSERT INTO `kl_area` VALUES ('1455', '69', null, '寿县', '341521');
INSERT INTO `kl_area` VALUES ('1456', '92', null, '龙海市', '350681');
INSERT INTO `kl_area` VALUES ('1457', '69', null, '霍邱县', '341522');
INSERT INTO `kl_area` VALUES ('1458', '69', null, '舒城县', '341523');
INSERT INTO `kl_area` VALUES ('1459', '69', null, '金寨县', '341524');
INSERT INTO `kl_area` VALUES ('1460', '54', null, '市辖区', '340401');
INSERT INTO `kl_area` VALUES ('1461', '69', null, '霍山县', '341525');
INSERT INTO `kl_area` VALUES ('1462', '54', null, '大通区', '340402');
INSERT INTO `kl_area` VALUES ('1463', '54', null, '田家庵区', '340403');
INSERT INTO `kl_area` VALUES ('1464', '54', null, '谢家集区', '340404');
INSERT INTO `kl_area` VALUES ('1465', '54', null, '八公山区', '340405');
INSERT INTO `kl_area` VALUES ('1466', '54', null, '潘集区', '340406');
INSERT INTO `kl_area` VALUES ('1467', '54', null, '凤台县', '340421');
INSERT INTO `kl_area` VALUES ('1468', '95', null, '市辖区', '350701');
INSERT INTO `kl_area` VALUES ('1469', '95', null, '延平区', '350702');
INSERT INTO `kl_area` VALUES ('1470', '95', null, '顺昌县', '350721');
INSERT INTO `kl_area` VALUES ('1471', '95', null, '浦城县', '350722');
INSERT INTO `kl_area` VALUES ('1472', '71', null, '市辖区', '341601');
INSERT INTO `kl_area` VALUES ('1473', '95', null, '光泽县', '350723');
INSERT INTO `kl_area` VALUES ('1474', '71', null, '谯城区', '341602');
INSERT INTO `kl_area` VALUES ('1475', '95', null, '松溪县', '350724');
INSERT INTO `kl_area` VALUES ('1476', '71', null, '涡阳县', '341621');
INSERT INTO `kl_area` VALUES ('1477', '95', null, '政和县', '350725');
INSERT INTO `kl_area` VALUES ('1478', '71', null, '蒙城县', '341622');
INSERT INTO `kl_area` VALUES ('1479', '95', null, '邵武市', '350781');
INSERT INTO `kl_area` VALUES ('1480', '71', null, '利辛县', '341623');
INSERT INTO `kl_area` VALUES ('1481', '95', null, '武夷山市', '350782');
INSERT INTO `kl_area` VALUES ('1482', '95', null, '建瓯市', '350783');
INSERT INTO `kl_area` VALUES ('1483', '55', null, '市辖区', '340501');
INSERT INTO `kl_area` VALUES ('1484', '95', null, '建阳市', '350784');
INSERT INTO `kl_area` VALUES ('1485', '55', null, '花山区', '340503');
INSERT INTO `kl_area` VALUES ('1486', '55', null, '雨山区', '340504');
INSERT INTO `kl_area` VALUES ('1487', '55', null, '博望区', '340506');
INSERT INTO `kl_area` VALUES ('1488', '55', null, '当涂县', '340521');
INSERT INTO `kl_area` VALUES ('1489', '55', null, '含山县', '340522');
INSERT INTO `kl_area` VALUES ('1490', '55', null, '和县', '340523');
INSERT INTO `kl_area` VALUES ('1491', '73', null, '市辖区', '341701');
INSERT INTO `kl_area` VALUES ('1492', '73', null, '贵池区', '341702');
INSERT INTO `kl_area` VALUES ('1493', '73', null, '东至县', '341721');
INSERT INTO `kl_area` VALUES ('1494', '73', null, '石台县', '341722');
INSERT INTO `kl_area` VALUES ('1495', '98', null, '市辖区', '350801');
INSERT INTO `kl_area` VALUES ('1496', '73', null, '青阳县', '341723');
INSERT INTO `kl_area` VALUES ('1497', '98', null, '新罗区', '350802');
INSERT INTO `kl_area` VALUES ('1498', '98', null, '长汀县', '350821');
INSERT INTO `kl_area` VALUES ('1499', '98', null, '永定县', '350822');
INSERT INTO `kl_area` VALUES ('1500', '98', null, '上杭县', '350823');
INSERT INTO `kl_area` VALUES ('1501', '56', null, '市辖区', '340601');
INSERT INTO `kl_area` VALUES ('1502', '98', null, '武平县', '350824');
INSERT INTO `kl_area` VALUES ('1503', '56', null, '杜集区', '340602');
INSERT INTO `kl_area` VALUES ('1504', '98', null, '连城县', '350825');
INSERT INTO `kl_area` VALUES ('1505', '56', null, '相山区', '340603');
INSERT INTO `kl_area` VALUES ('1506', '98', null, '漳平市', '350881');
INSERT INTO `kl_area` VALUES ('1507', '56', null, '烈山区', '340604');
INSERT INTO `kl_area` VALUES ('1508', '56', null, '濉溪县', '340621');
INSERT INTO `kl_area` VALUES ('1509', '75', null, '市辖区', '341801');
INSERT INTO `kl_area` VALUES ('1510', '75', null, '宣州区', '341802');
INSERT INTO `kl_area` VALUES ('1511', '75', null, '郎溪县', '341821');
INSERT INTO `kl_area` VALUES ('1512', '75', null, '广德县', '341822');
INSERT INTO `kl_area` VALUES ('1513', '75', null, '泾县', '341823');
INSERT INTO `kl_area` VALUES ('1514', '75', null, '绩溪县', '341824');
INSERT INTO `kl_area` VALUES ('1515', '75', null, '旌德县', '341825');
INSERT INTO `kl_area` VALUES ('1516', '75', null, '宁国市', '341881');
INSERT INTO `kl_area` VALUES ('1517', '101', null, '市辖区', '350901');
INSERT INTO `kl_area` VALUES ('1518', '101', null, '蕉城区', '350902');
INSERT INTO `kl_area` VALUES ('1519', '57', null, '市辖区', '340701');
INSERT INTO `kl_area` VALUES ('1520', '101', null, '霞浦县', '350921');
INSERT INTO `kl_area` VALUES ('1521', '57', null, '铜官山区', '340702');
INSERT INTO `kl_area` VALUES ('1522', '101', null, '古田县', '350922');
INSERT INTO `kl_area` VALUES ('1523', '57', null, '狮子山区', '340703');
INSERT INTO `kl_area` VALUES ('1524', '101', null, '屏南县', '350923');
INSERT INTO `kl_area` VALUES ('1525', '57', null, '郊区', '340711');
INSERT INTO `kl_area` VALUES ('1526', '101', null, '寿宁县', '350924');
INSERT INTO `kl_area` VALUES ('1527', '57', null, '铜陵县', '340721');
INSERT INTO `kl_area` VALUES ('1528', '101', null, '周宁县', '350925');
INSERT INTO `kl_area` VALUES ('1529', '101', null, '柘荣县', '350926');
INSERT INTO `kl_area` VALUES ('1530', '101', null, '福安市', '350981');
INSERT INTO `kl_area` VALUES ('1531', '101', null, '福鼎市', '350982');
INSERT INTO `kl_area` VALUES ('1532', '80', null, '市辖区', '350101');
INSERT INTO `kl_area` VALUES ('1533', '80', null, '鼓楼区', '350102');
INSERT INTO `kl_area` VALUES ('1534', '80', null, '台江区', '350103');
INSERT INTO `kl_area` VALUES ('1535', '80', null, '仓山区', '350104');
INSERT INTO `kl_area` VALUES ('1536', '80', null, '马尾区', '350105');
INSERT INTO `kl_area` VALUES ('1537', '80', null, '晋安区', '350111');
INSERT INTO `kl_area` VALUES ('1538', '80', null, '闽侯县', '350121');
INSERT INTO `kl_area` VALUES ('1539', '80', null, '连江县', '350122');
INSERT INTO `kl_area` VALUES ('1540', '80', null, '罗源县', '350123');
INSERT INTO `kl_area` VALUES ('1541', '80', null, '闽清县', '350124');
INSERT INTO `kl_area` VALUES ('1542', '80', null, '永泰县', '350125');
INSERT INTO `kl_area` VALUES ('1543', '80', null, '平潭县', '350128');
INSERT INTO `kl_area` VALUES ('1544', '59', null, '市辖区', '340801');
INSERT INTO `kl_area` VALUES ('1545', '80', null, '福清市', '350181');
INSERT INTO `kl_area` VALUES ('1546', '59', null, '迎江区', '340802');
INSERT INTO `kl_area` VALUES ('1547', '80', null, '长乐市', '350182');
INSERT INTO `kl_area` VALUES ('1548', '59', null, '大观区', '340803');
INSERT INTO `kl_area` VALUES ('1549', '121', null, '市辖区', '360101');
INSERT INTO `kl_area` VALUES ('1550', '121', null, '东湖区', '360102');
INSERT INTO `kl_area` VALUES ('1551', '59', null, '宜秀区', '340811');
INSERT INTO `kl_area` VALUES ('1552', '121', null, '西湖区', '360103');
INSERT INTO `kl_area` VALUES ('1553', '59', null, '怀宁县', '340822');
INSERT INTO `kl_area` VALUES ('1554', '121', null, '青云谱区', '360104');
INSERT INTO `kl_area` VALUES ('1555', '59', null, '枞阳县', '340823');
INSERT INTO `kl_area` VALUES ('1556', '121', null, '湾里区', '360105');
INSERT INTO `kl_area` VALUES ('1557', '59', null, '潜山县', '340824');
INSERT INTO `kl_area` VALUES ('1558', '121', null, '青山湖区', '360111');
INSERT INTO `kl_area` VALUES ('1559', '59', null, '太湖县', '340825');
INSERT INTO `kl_area` VALUES ('1560', '121', null, '南昌县', '360121');
INSERT INTO `kl_area` VALUES ('1561', '59', null, '宿松县', '340826');
INSERT INTO `kl_area` VALUES ('1562', '121', null, '新建县', '360122');
INSERT INTO `kl_area` VALUES ('1563', '59', null, '望江县', '340827');
INSERT INTO `kl_area` VALUES ('1564', '121', null, '安义县', '360123');
INSERT INTO `kl_area` VALUES ('1565', '59', null, '岳西县', '340828');
INSERT INTO `kl_area` VALUES ('1566', '121', null, '进贤县', '360124');
INSERT INTO `kl_area` VALUES ('1567', '59', null, '桐城市', '340881');
INSERT INTO `kl_area` VALUES ('1568', '81', null, '市辖区', '350201');
INSERT INTO `kl_area` VALUES ('1569', '81', null, '思明区', '350203');
INSERT INTO `kl_area` VALUES ('1570', '81', null, '海沧区', '350205');
INSERT INTO `kl_area` VALUES ('1571', '81', null, '湖里区', '350206');
INSERT INTO `kl_area` VALUES ('1572', '81', null, '集美区', '350211');
INSERT INTO `kl_area` VALUES ('1573', '81', null, '同安区', '350212');
INSERT INTO `kl_area` VALUES ('1574', '81', null, '翔安区', '350213');
INSERT INTO `kl_area` VALUES ('1575', '122', null, '市辖区', '360201');
INSERT INTO `kl_area` VALUES ('1576', '61', null, '市辖区', '341001');
INSERT INTO `kl_area` VALUES ('1577', '122', null, '昌江区', '360202');
INSERT INTO `kl_area` VALUES ('1578', '61', null, '屯溪区', '341002');
INSERT INTO `kl_area` VALUES ('1579', '122', null, '珠山区', '360203');
INSERT INTO `kl_area` VALUES ('1580', '61', null, '黄山区', '341003');
INSERT INTO `kl_area` VALUES ('1581', '122', null, '浮梁县', '360222');
INSERT INTO `kl_area` VALUES ('1582', '61', null, '徽州区', '341004');
INSERT INTO `kl_area` VALUES ('1583', '122', null, '乐平市', '360281');
INSERT INTO `kl_area` VALUES ('1584', '61', null, '歙县', '341021');
INSERT INTO `kl_area` VALUES ('1585', '61', null, '休宁县', '341022');
INSERT INTO `kl_area` VALUES ('1586', '83', null, '市辖区', '350301');
INSERT INTO `kl_area` VALUES ('1587', '61', null, '黟县', '341023');
INSERT INTO `kl_area` VALUES ('1588', '83', null, '城厢区', '350302');
INSERT INTO `kl_area` VALUES ('1589', '61', null, '祁门县', '341024');
INSERT INTO `kl_area` VALUES ('1590', '83', null, '涵江区', '350303');
INSERT INTO `kl_area` VALUES ('1591', '83', null, '荔城区', '350304');
INSERT INTO `kl_area` VALUES ('1592', '83', null, '秀屿区', '350305');
INSERT INTO `kl_area` VALUES ('1593', '83', null, '仙游县', '350322');
INSERT INTO `kl_area` VALUES ('1594', '123', null, '市辖区', '360301');
INSERT INTO `kl_area` VALUES ('1595', '123', null, '安源区', '360302');
INSERT INTO `kl_area` VALUES ('1596', '123', null, '湘东区', '360313');
INSERT INTO `kl_area` VALUES ('1597', '123', null, '莲花县', '360321');
INSERT INTO `kl_area` VALUES ('1598', '123', null, '上栗县', '360322');
INSERT INTO `kl_area` VALUES ('1599', '123', null, '芦溪县', '360323');
INSERT INTO `kl_area` VALUES ('1600', '63', null, '市辖区', '341101');
INSERT INTO `kl_area` VALUES ('1601', '63', null, '琅琊区', '341102');
INSERT INTO `kl_area` VALUES ('1602', '63', null, '南谯区', '341103');
INSERT INTO `kl_area` VALUES ('1603', '63', null, '来安县', '341122');
INSERT INTO `kl_area` VALUES ('1604', '86', null, '市辖区', '350401');
INSERT INTO `kl_area` VALUES ('1605', '63', null, '全椒县', '341124');
INSERT INTO `kl_area` VALUES ('1606', '86', null, '梅列区', '350402');
INSERT INTO `kl_area` VALUES ('1607', '63', null, '定远县', '341125');
INSERT INTO `kl_area` VALUES ('1608', '86', null, '三元区', '350403');
INSERT INTO `kl_area` VALUES ('1609', '63', null, '凤阳县', '341126');
INSERT INTO `kl_area` VALUES ('1610', '86', null, '明溪县', '350421');
INSERT INTO `kl_area` VALUES ('1611', '63', null, '天长市', '341181');
INSERT INTO `kl_area` VALUES ('1612', '86', null, '清流县', '350423');
INSERT INTO `kl_area` VALUES ('1613', '63', null, '明光市', '341182');
INSERT INTO `kl_area` VALUES ('1614', '86', null, '宁化县', '350424');
INSERT INTO `kl_area` VALUES ('1615', '86', null, '大田县', '350425');
INSERT INTO `kl_area` VALUES ('1616', '86', null, '尤溪县', '350426');
INSERT INTO `kl_area` VALUES ('1617', '86', null, '沙县', '350427');
INSERT INTO `kl_area` VALUES ('1618', '86', null, '将乐县', '350428');
INSERT INTO `kl_area` VALUES ('1619', '86', null, '泰宁县', '350429');
INSERT INTO `kl_area` VALUES ('1620', '124', null, '市辖区', '360401');
INSERT INTO `kl_area` VALUES ('1621', '86', null, '建宁县', '350430');
INSERT INTO `kl_area` VALUES ('1622', '124', null, '庐山区', '360402');
INSERT INTO `kl_area` VALUES ('1623', '86', null, '永安市', '350481');
INSERT INTO `kl_area` VALUES ('1624', '124', null, '浔阳区', '360403');
INSERT INTO `kl_area` VALUES ('1625', '124', null, '九江县', '360421');
INSERT INTO `kl_area` VALUES ('1626', '124', null, '武宁县', '360423');
INSERT INTO `kl_area` VALUES ('1627', '124', null, '修水县', '360424');
INSERT INTO `kl_area` VALUES ('1628', '124', null, '永修县', '360425');
INSERT INTO `kl_area` VALUES ('1629', '124', null, '德安县', '360426');
INSERT INTO `kl_area` VALUES ('1630', '124', null, '星子县', '360427');
INSERT INTO `kl_area` VALUES ('1631', '124', null, '都昌县', '360428');
INSERT INTO `kl_area` VALUES ('1632', '124', null, '湖口县', '360429');
INSERT INTO `kl_area` VALUES ('1633', '124', null, '彭泽县', '360430');
INSERT INTO `kl_area` VALUES ('1634', '124', null, '瑞昌市', '360481');
INSERT INTO `kl_area` VALUES ('1635', '124', null, '共青城市', '360482');
INSERT INTO `kl_area` VALUES ('1636', '126', null, '市辖区', '360601');
INSERT INTO `kl_area` VALUES ('1637', '126', null, '月湖区', '360602');
INSERT INTO `kl_area` VALUES ('1638', '126', null, '余江县', '360622');
INSERT INTO `kl_area` VALUES ('1639', '126', null, '贵溪市', '360681');
INSERT INTO `kl_area` VALUES ('1640', '125', null, '市辖区', '360501');
INSERT INTO `kl_area` VALUES ('1641', '157', null, '市辖区', '370501');
INSERT INTO `kl_area` VALUES ('1642', '125', null, '渝水区', '360502');
INSERT INTO `kl_area` VALUES ('1643', '157', null, '东营区', '370502');
INSERT INTO `kl_area` VALUES ('1644', '127', null, '市辖区', '360701');
INSERT INTO `kl_area` VALUES ('1645', '125', null, '分宜县', '360521');
INSERT INTO `kl_area` VALUES ('1646', '127', null, '章贡区', '360702');
INSERT INTO `kl_area` VALUES ('1647', '157', null, '河口区', '370503');
INSERT INTO `kl_area` VALUES ('1648', '157', null, '垦利县', '370521');
INSERT INTO `kl_area` VALUES ('1649', '127', null, '赣县', '360721');
INSERT INTO `kl_area` VALUES ('1650', '157', null, '利津县', '370522');
INSERT INTO `kl_area` VALUES ('1651', '127', null, '信丰县', '360722');
INSERT INTO `kl_area` VALUES ('1652', '157', null, '广饶县', '370523');
INSERT INTO `kl_area` VALUES ('1653', '127', null, '大余县', '360723');
INSERT INTO `kl_area` VALUES ('1654', '127', null, '上犹县', '360724');
INSERT INTO `kl_area` VALUES ('1655', '127', null, '崇义县', '360725');
INSERT INTO `kl_area` VALUES ('1656', '127', null, '安远县', '360726');
INSERT INTO `kl_area` VALUES ('1657', '127', null, '龙南县', '360727');
INSERT INTO `kl_area` VALUES ('1658', '127', null, '定南县', '360728');
INSERT INTO `kl_area` VALUES ('1659', '127', null, '全南县', '360729');
INSERT INTO `kl_area` VALUES ('1660', '127', null, '宁都县', '360730');
INSERT INTO `kl_area` VALUES ('1661', '127', null, '于都县', '360731');
INSERT INTO `kl_area` VALUES ('1662', '127', null, '兴国县', '360732');
INSERT INTO `kl_area` VALUES ('1663', '127', null, '会昌县', '360733');
INSERT INTO `kl_area` VALUES ('1664', '127', null, '寻乌县', '360734');
INSERT INTO `kl_area` VALUES ('1665', '127', null, '石城县', '360735');
INSERT INTO `kl_area` VALUES ('1666', '127', null, '瑞金市', '360781');
INSERT INTO `kl_area` VALUES ('1667', '127', null, '南康市', '360782');
INSERT INTO `kl_area` VALUES ('1668', '158', null, '市辖区', '370601');
INSERT INTO `kl_area` VALUES ('1669', '158', null, '芝罘区', '370602');
INSERT INTO `kl_area` VALUES ('1670', '158', null, '福山区', '370611');
INSERT INTO `kl_area` VALUES ('1671', '158', null, '牟平区', '370612');
INSERT INTO `kl_area` VALUES ('1672', '158', null, '莱山区', '370613');
INSERT INTO `kl_area` VALUES ('1673', '158', null, '长岛县', '370634');
INSERT INTO `kl_area` VALUES ('1674', '158', null, '龙口市', '370681');
INSERT INTO `kl_area` VALUES ('1675', '158', null, '莱阳市', '370682');
INSERT INTO `kl_area` VALUES ('1676', '158', null, '莱州市', '370683');
INSERT INTO `kl_area` VALUES ('1677', '158', null, '蓬莱市', '370684');
INSERT INTO `kl_area` VALUES ('1678', '158', null, '招远市', '370685');
INSERT INTO `kl_area` VALUES ('1679', '158', null, '栖霞市', '370686');
INSERT INTO `kl_area` VALUES ('1680', '158', null, '海阳市', '370687');
INSERT INTO `kl_area` VALUES ('1681', '128', null, '市辖区', '360801');
INSERT INTO `kl_area` VALUES ('1682', '128', null, '吉州区', '360802');
INSERT INTO `kl_area` VALUES ('1683', '128', null, '青原区', '360803');
INSERT INTO `kl_area` VALUES ('1684', '128', null, '吉安县', '360821');
INSERT INTO `kl_area` VALUES ('1685', '128', null, '吉水县', '360822');
INSERT INTO `kl_area` VALUES ('1686', '128', null, '峡江县', '360823');
INSERT INTO `kl_area` VALUES ('1687', '128', null, '新干县', '360824');
INSERT INTO `kl_area` VALUES ('1688', '128', null, '永丰县', '360825');
INSERT INTO `kl_area` VALUES ('1689', '128', null, '泰和县', '360826');
INSERT INTO `kl_area` VALUES ('1690', '128', null, '遂川县', '360827');
INSERT INTO `kl_area` VALUES ('1691', '128', null, '万安县', '360828');
INSERT INTO `kl_area` VALUES ('1692', '128', null, '安福县', '360829');
INSERT INTO `kl_area` VALUES ('1693', '128', null, '永新县', '360830');
INSERT INTO `kl_area` VALUES ('1694', '128', null, '井冈山市', '360881');
INSERT INTO `kl_area` VALUES ('1695', '159', null, '市辖区', '370701');
INSERT INTO `kl_area` VALUES ('1696', '159', null, '潍城区', '370702');
INSERT INTO `kl_area` VALUES ('1697', '159', null, '寒亭区', '370703');
INSERT INTO `kl_area` VALUES ('1698', '159', null, '坊子区', '370704');
INSERT INTO `kl_area` VALUES ('1699', '159', null, '奎文区', '370705');
INSERT INTO `kl_area` VALUES ('1700', '159', null, '临朐县', '370724');
INSERT INTO `kl_area` VALUES ('1701', '159', null, '昌乐县', '370725');
INSERT INTO `kl_area` VALUES ('1702', '159', null, '青州市', '370781');
INSERT INTO `kl_area` VALUES ('1703', '159', null, '诸城市', '370782');
INSERT INTO `kl_area` VALUES ('1704', '159', null, '寿光市', '370783');
INSERT INTO `kl_area` VALUES ('1705', '159', null, '安丘市', '370784');
INSERT INTO `kl_area` VALUES ('1706', '159', null, '高密市', '370785');
INSERT INTO `kl_area` VALUES ('1707', '159', null, '昌邑市', '370786');
INSERT INTO `kl_area` VALUES ('1708', '129', null, '市辖区', '360901');
INSERT INTO `kl_area` VALUES ('1709', '129', null, '袁州区', '360902');
INSERT INTO `kl_area` VALUES ('1710', '129', null, '奉新县', '360921');
INSERT INTO `kl_area` VALUES ('1711', '129', null, '万载县', '360922');
INSERT INTO `kl_area` VALUES ('1712', '129', null, '上高县', '360923');
INSERT INTO `kl_area` VALUES ('1713', '129', null, '宜丰县', '360924');
INSERT INTO `kl_area` VALUES ('1714', '129', null, '靖安县', '360925');
INSERT INTO `kl_area` VALUES ('1715', '129', null, '铜鼓县', '360926');
INSERT INTO `kl_area` VALUES ('1716', '129', null, '丰城市', '360981');
INSERT INTO `kl_area` VALUES ('1717', '129', null, '樟树市', '360982');
INSERT INTO `kl_area` VALUES ('1718', '129', null, '高安市', '360983');
INSERT INTO `kl_area` VALUES ('1719', '160', null, '市辖区', '370801');
INSERT INTO `kl_area` VALUES ('1720', '160', null, '市中区', '370802');
INSERT INTO `kl_area` VALUES ('1721', '160', null, '任城区', '370811');
INSERT INTO `kl_area` VALUES ('1722', '160', null, '微山县', '370826');
INSERT INTO `kl_area` VALUES ('1723', '160', null, '鱼台县', '370827');
INSERT INTO `kl_area` VALUES ('1724', '160', null, '金乡县', '370828');
INSERT INTO `kl_area` VALUES ('1725', '160', null, '嘉祥县', '370829');
INSERT INTO `kl_area` VALUES ('1726', '160', null, '汶上县', '370830');
INSERT INTO `kl_area` VALUES ('1727', '160', null, '泗水县', '370831');
INSERT INTO `kl_area` VALUES ('1728', '160', null, '梁山县', '370832');
INSERT INTO `kl_area` VALUES ('1729', '160', null, '曲阜市', '370881');
INSERT INTO `kl_area` VALUES ('1730', '131', null, '市辖区', '361001');
INSERT INTO `kl_area` VALUES ('1731', '160', null, '兖州市', '370882');
INSERT INTO `kl_area` VALUES ('1732', '131', null, '临川区', '361002');
INSERT INTO `kl_area` VALUES ('1733', '160', null, '邹城市', '370883');
INSERT INTO `kl_area` VALUES ('1734', '131', null, '南城县', '361021');
INSERT INTO `kl_area` VALUES ('1735', '131', null, '黎川县', '361022');
INSERT INTO `kl_area` VALUES ('1736', '131', null, '南丰县', '361023');
INSERT INTO `kl_area` VALUES ('1737', '131', null, '崇仁县', '361024');
INSERT INTO `kl_area` VALUES ('1738', '131', null, '乐安县', '361025');
INSERT INTO `kl_area` VALUES ('1739', '131', null, '宜黄县', '361026');
INSERT INTO `kl_area` VALUES ('1740', '131', null, '金溪县', '361027');
INSERT INTO `kl_area` VALUES ('1741', '131', null, '资溪县', '361028');
INSERT INTO `kl_area` VALUES ('1742', '131', null, '东乡县', '361029');
INSERT INTO `kl_area` VALUES ('1743', '131', null, '广昌县', '361030');
INSERT INTO `kl_area` VALUES ('1744', '161', null, '市辖区', '370901');
INSERT INTO `kl_area` VALUES ('1745', '161', null, '泰山区', '370902');
INSERT INTO `kl_area` VALUES ('1746', '161', null, '岱岳区', '370911');
INSERT INTO `kl_area` VALUES ('1747', '161', null, '宁阳县', '370921');
INSERT INTO `kl_area` VALUES ('1748', '161', null, '东平县', '370923');
INSERT INTO `kl_area` VALUES ('1749', '161', null, '新泰市', '370982');
INSERT INTO `kl_area` VALUES ('1750', '161', null, '肥城市', '370983');
INSERT INTO `kl_area` VALUES ('1751', '133', null, '市辖区', '361101');
INSERT INTO `kl_area` VALUES ('1752', '133', null, '信州区', '361102');
INSERT INTO `kl_area` VALUES ('1753', '133', null, '上饶县', '361121');
INSERT INTO `kl_area` VALUES ('1754', '133', null, '广丰县', '361122');
INSERT INTO `kl_area` VALUES ('1755', '133', null, '玉山县', '361123');
INSERT INTO `kl_area` VALUES ('1756', '133', null, '铅山县', '361124');
INSERT INTO `kl_area` VALUES ('1757', '133', null, '横峰县', '361125');
INSERT INTO `kl_area` VALUES ('1758', '133', null, '弋阳县', '361126');
INSERT INTO `kl_area` VALUES ('1759', '133', null, '余干县', '361127');
INSERT INTO `kl_area` VALUES ('1760', '133', null, '鄱阳县', '361128');
INSERT INTO `kl_area` VALUES ('1761', '133', null, '万年县', '361129');
INSERT INTO `kl_area` VALUES ('1762', '133', null, '婺源县', '361130');
INSERT INTO `kl_area` VALUES ('1763', '133', null, '德兴市', '361181');
INSERT INTO `kl_area` VALUES ('1764', '162', null, '市辖区', '371001');
INSERT INTO `kl_area` VALUES ('1765', '162', null, '环翠区', '371002');
INSERT INTO `kl_area` VALUES ('1766', '162', null, '文登市', '371081');
INSERT INTO `kl_area` VALUES ('1767', '162', null, '荣成市', '371082');
INSERT INTO `kl_area` VALUES ('1768', '162', null, '乳山市', '371083');
INSERT INTO `kl_area` VALUES ('1769', '153', null, '市辖区', '370101');
INSERT INTO `kl_area` VALUES ('1770', '153', null, '历下区', '370102');
INSERT INTO `kl_area` VALUES ('1771', '153', null, '市中区', '370103');
INSERT INTO `kl_area` VALUES ('1772', '153', null, '槐荫区', '370104');
INSERT INTO `kl_area` VALUES ('1773', '153', null, '天桥区', '370105');
INSERT INTO `kl_area` VALUES ('1774', '153', null, '历城区', '370112');
INSERT INTO `kl_area` VALUES ('1775', '153', null, '长清区', '370113');
INSERT INTO `kl_area` VALUES ('1776', '153', null, '平阴县', '370124');
INSERT INTO `kl_area` VALUES ('1777', '153', null, '济阳县', '370125');
INSERT INTO `kl_area` VALUES ('1778', '153', null, '商河县', '370126');
INSERT INTO `kl_area` VALUES ('1779', '153', null, '章丘市', '370181');
INSERT INTO `kl_area` VALUES ('1780', '163', null, '市辖区', '371101');
INSERT INTO `kl_area` VALUES ('1781', '163', null, '东港区', '371102');
INSERT INTO `kl_area` VALUES ('1782', '163', null, '岚山区', '371103');
INSERT INTO `kl_area` VALUES ('1783', '163', null, '五莲县', '371121');
INSERT INTO `kl_area` VALUES ('1784', '163', null, '莒县', '371122');
INSERT INTO `kl_area` VALUES ('1785', '154', null, '市辖区', '370201');
INSERT INTO `kl_area` VALUES ('1786', '154', null, '市南区', '370202');
INSERT INTO `kl_area` VALUES ('1787', '154', null, '市北区', '370203');
INSERT INTO `kl_area` VALUES ('1788', '154', null, '黄岛区', '370211');
INSERT INTO `kl_area` VALUES ('1789', '154', null, '崂山区', '370212');
INSERT INTO `kl_area` VALUES ('1790', '154', null, '李沧区', '370213');
INSERT INTO `kl_area` VALUES ('1791', '164', null, '市辖区', '371201');
INSERT INTO `kl_area` VALUES ('1792', '154', null, '城阳区', '370214');
INSERT INTO `kl_area` VALUES ('1793', '164', null, '莱城区', '371202');
INSERT INTO `kl_area` VALUES ('1794', '154', null, '胶州市', '370281');
INSERT INTO `kl_area` VALUES ('1795', '164', null, '钢城区', '371203');
INSERT INTO `kl_area` VALUES ('1796', '154', null, '即墨市', '370282');
INSERT INTO `kl_area` VALUES ('1797', '154', null, '平度市', '370283');
INSERT INTO `kl_area` VALUES ('1798', '154', null, '莱西市', '370285');
INSERT INTO `kl_area` VALUES ('1799', '165', null, '市辖区', '371301');
INSERT INTO `kl_area` VALUES ('1800', '165', null, '兰山区', '371302');
INSERT INTO `kl_area` VALUES ('1801', '165', null, '罗庄区', '371311');
INSERT INTO `kl_area` VALUES ('1802', '155', null, '市辖区', '370301');
INSERT INTO `kl_area` VALUES ('1803', '165', null, '河东区', '371312');
INSERT INTO `kl_area` VALUES ('1804', '155', null, '淄川区', '370302');
INSERT INTO `kl_area` VALUES ('1805', '165', null, '沂南县', '371321');
INSERT INTO `kl_area` VALUES ('1806', '155', null, '张店区', '370303');
INSERT INTO `kl_area` VALUES ('1807', '165', null, '郯城县', '371322');
INSERT INTO `kl_area` VALUES ('1808', '155', null, '博山区', '370304');
INSERT INTO `kl_area` VALUES ('1809', '165', null, '沂水县', '371323');
INSERT INTO `kl_area` VALUES ('1810', '155', null, '临淄区', '370305');
INSERT INTO `kl_area` VALUES ('1811', '165', null, '苍山县', '371324');
INSERT INTO `kl_area` VALUES ('1812', '155', null, '周村区', '370306');
INSERT INTO `kl_area` VALUES ('1813', '165', null, '费县', '371325');
INSERT INTO `kl_area` VALUES ('1814', '155', null, '桓台县', '370321');
INSERT INTO `kl_area` VALUES ('1815', '165', null, '平邑县', '371326');
INSERT INTO `kl_area` VALUES ('1816', '155', null, '高青县', '370322');
INSERT INTO `kl_area` VALUES ('1817', '165', null, '莒南县', '371327');
INSERT INTO `kl_area` VALUES ('1818', '155', null, '沂源县', '370323');
INSERT INTO `kl_area` VALUES ('1819', '165', null, '蒙阴县', '371328');
INSERT INTO `kl_area` VALUES ('1820', '165', null, '临沭县', '371329');
INSERT INTO `kl_area` VALUES ('1821', '156', null, '市辖区', '370401');
INSERT INTO `kl_area` VALUES ('1822', '166', null, '市辖区', '371401');
INSERT INTO `kl_area` VALUES ('1823', '156', null, '市中区', '370402');
INSERT INTO `kl_area` VALUES ('1824', '166', null, '德城区', '371402');
INSERT INTO `kl_area` VALUES ('1825', '156', null, '薛城区', '370403');
INSERT INTO `kl_area` VALUES ('1826', '166', null, '陵县', '371421');
INSERT INTO `kl_area` VALUES ('1827', '156', null, '峄城区', '370404');
INSERT INTO `kl_area` VALUES ('1828', '166', null, '宁津县', '371422');
INSERT INTO `kl_area` VALUES ('1829', '156', null, '台儿庄区', '370405');
INSERT INTO `kl_area` VALUES ('1830', '166', null, '庆云县', '371423');
INSERT INTO `kl_area` VALUES ('1831', '156', null, '山亭区', '370406');
INSERT INTO `kl_area` VALUES ('1832', '166', null, '临邑县', '371424');
INSERT INTO `kl_area` VALUES ('1833', '156', null, '滕州市', '370481');
INSERT INTO `kl_area` VALUES ('1834', '166', null, '齐河县', '371425');
INSERT INTO `kl_area` VALUES ('1835', '166', null, '平原县', '371426');
INSERT INTO `kl_area` VALUES ('1836', '166', null, '夏津县', '371427');
INSERT INTO `kl_area` VALUES ('1837', '166', null, '武城县', '371428');
INSERT INTO `kl_area` VALUES ('1838', '166', null, '乐陵市', '371481');
INSERT INTO `kl_area` VALUES ('1839', '166', null, '禹城市', '371482');
INSERT INTO `kl_area` VALUES ('1840', '167', null, '市辖区', '371501');
INSERT INTO `kl_area` VALUES ('1841', '167', null, '东昌府区', '371502');
INSERT INTO `kl_area` VALUES ('1842', '167', null, '阳谷县', '371521');
INSERT INTO `kl_area` VALUES ('1843', '167', null, '莘县', '371522');
INSERT INTO `kl_area` VALUES ('1844', '167', null, '茌平县', '371523');
INSERT INTO `kl_area` VALUES ('1845', '167', null, '东阿县', '371524');
INSERT INTO `kl_area` VALUES ('1846', '167', null, '冠县', '371525');
INSERT INTO `kl_area` VALUES ('1847', '167', null, '高唐县', '371526');
INSERT INTO `kl_area` VALUES ('1848', '167', null, '临清市', '371581');
INSERT INTO `kl_area` VALUES ('1849', '207', null, '市辖区', '410801');
INSERT INTO `kl_area` VALUES ('1850', '207', null, '解放区', '410802');
INSERT INTO `kl_area` VALUES ('1851', '207', null, '中站区', '410803');
INSERT INTO `kl_area` VALUES ('1852', '207', null, '马村区', '410804');
INSERT INTO `kl_area` VALUES ('1853', '207', null, '山阳区', '410811');
INSERT INTO `kl_area` VALUES ('1854', '207', null, '修武县', '410821');
INSERT INTO `kl_area` VALUES ('1855', '207', null, '博爱县', '410822');
INSERT INTO `kl_area` VALUES ('1856', '207', null, '武陟县', '410823');
INSERT INTO `kl_area` VALUES ('1857', '207', null, '温县', '410825');
INSERT INTO `kl_area` VALUES ('1858', '207', null, '沁阳市', '410882');
INSERT INTO `kl_area` VALUES ('1859', '207', null, '孟州市', '410883');
INSERT INTO `kl_area` VALUES ('1860', '169', null, '市辖区', '371601');
INSERT INTO `kl_area` VALUES ('1861', '169', null, '滨城区', '371602');
INSERT INTO `kl_area` VALUES ('1862', '169', null, '惠民县', '371621');
INSERT INTO `kl_area` VALUES ('1863', '169', null, '阳信县', '371622');
INSERT INTO `kl_area` VALUES ('1864', '169', null, '无棣县', '371623');
INSERT INTO `kl_area` VALUES ('1865', '169', null, '沾化县', '371624');
INSERT INTO `kl_area` VALUES ('1866', '169', null, '博兴县', '371625');
INSERT INTO `kl_area` VALUES ('1867', '169', null, '邹平县', '371626');
INSERT INTO `kl_area` VALUES ('1868', '222', null, '济源市', '419001');
INSERT INTO `kl_area` VALUES ('1869', '208', null, '市辖区', '410901');
INSERT INTO `kl_area` VALUES ('1870', '208', null, '华龙区', '410902');
INSERT INTO `kl_area` VALUES ('1871', '208', null, '清丰县', '410922');
INSERT INTO `kl_area` VALUES ('1872', '208', null, '南乐县', '410923');
INSERT INTO `kl_area` VALUES ('1873', '208', null, '范县', '410926');
INSERT INTO `kl_area` VALUES ('1874', '208', null, '台前县', '410927');
INSERT INTO `kl_area` VALUES ('1875', '208', null, '濮阳县', '410928');
INSERT INTO `kl_area` VALUES ('1876', '172', null, '市辖区', '371701');
INSERT INTO `kl_area` VALUES ('1877', '172', null, '牡丹区', '371702');
INSERT INTO `kl_area` VALUES ('1878', '234', null, '市辖区', '420101');
INSERT INTO `kl_area` VALUES ('1879', '172', null, '曹县', '371721');
INSERT INTO `kl_area` VALUES ('1880', '234', null, '江岸区', '420102');
INSERT INTO `kl_area` VALUES ('1881', '172', null, '单县', '371722');
INSERT INTO `kl_area` VALUES ('1882', '234', null, '江汉区', '420103');
INSERT INTO `kl_area` VALUES ('1883', '172', null, '成武县', '371723');
INSERT INTO `kl_area` VALUES ('1884', '234', null, '硚口区', '420104');
INSERT INTO `kl_area` VALUES ('1885', '172', null, '巨野县', '371724');
INSERT INTO `kl_area` VALUES ('1886', '234', null, '汉阳区', '420105');
INSERT INTO `kl_area` VALUES ('1887', '172', null, '郓城县', '371725');
INSERT INTO `kl_area` VALUES ('1888', '234', null, '武昌区', '420106');
INSERT INTO `kl_area` VALUES ('1889', '172', null, '鄄城县', '371726');
INSERT INTO `kl_area` VALUES ('1890', '234', null, '青山区', '420107');
INSERT INTO `kl_area` VALUES ('1891', '172', null, '定陶县', '371727');
INSERT INTO `kl_area` VALUES ('1892', '234', null, '洪山区', '420111');
INSERT INTO `kl_area` VALUES ('1893', '172', null, '东明县', '371728');
INSERT INTO `kl_area` VALUES ('1894', '234', null, '东西湖区', '420112');
INSERT INTO `kl_area` VALUES ('1895', '234', null, '汉南区', '420113');
INSERT INTO `kl_area` VALUES ('1896', '234', null, '蔡甸区', '420114');
INSERT INTO `kl_area` VALUES ('1897', '234', null, '江夏区', '420115');
INSERT INTO `kl_area` VALUES ('1898', '234', null, '黄陂区', '420116');
INSERT INTO `kl_area` VALUES ('1899', '209', null, '市辖区', '411001');
INSERT INTO `kl_area` VALUES ('1900', '234', null, '新洲区', '420117');
INSERT INTO `kl_area` VALUES ('1901', '209', null, '魏都区', '411002');
INSERT INTO `kl_area` VALUES ('1902', '209', null, '许昌县', '411023');
INSERT INTO `kl_area` VALUES ('1903', '209', null, '鄢陵县', '411024');
INSERT INTO `kl_area` VALUES ('1904', '209', null, '襄城县', '411025');
INSERT INTO `kl_area` VALUES ('1905', '209', null, '禹州市', '411081');
INSERT INTO `kl_area` VALUES ('1906', '209', null, '长葛市', '411082');
INSERT INTO `kl_area` VALUES ('1907', '198', null, '市辖区', '410101');
INSERT INTO `kl_area` VALUES ('1908', '198', null, '中原区', '410102');
INSERT INTO `kl_area` VALUES ('1909', '198', null, '二七区', '410103');
INSERT INTO `kl_area` VALUES ('1910', '198', null, '管城回族区', '410104');
INSERT INTO `kl_area` VALUES ('1911', '198', null, '金水区', '410105');
INSERT INTO `kl_area` VALUES ('1912', '198', null, '上街区', '410106');
INSERT INTO `kl_area` VALUES ('1913', '198', null, '惠济区', '410108');
INSERT INTO `kl_area` VALUES ('1914', '235', null, '市辖区', '420201');
INSERT INTO `kl_area` VALUES ('1915', '198', null, '中牟县', '410122');
INSERT INTO `kl_area` VALUES ('1916', '235', null, '黄石港区', '420202');
INSERT INTO `kl_area` VALUES ('1917', '198', null, '巩义市', '410181');
INSERT INTO `kl_area` VALUES ('1918', '235', null, '西塞山区', '420203');
INSERT INTO `kl_area` VALUES ('1919', '198', null, '荥阳市', '410182');
INSERT INTO `kl_area` VALUES ('1920', '235', null, '下陆区', '420204');
INSERT INTO `kl_area` VALUES ('1921', '198', null, '新密市', '410183');
INSERT INTO `kl_area` VALUES ('1922', '235', null, '铁山区', '420205');
INSERT INTO `kl_area` VALUES ('1923', '198', null, '新郑市', '410184');
INSERT INTO `kl_area` VALUES ('1924', '210', null, '市辖区', '411101');
INSERT INTO `kl_area` VALUES ('1925', '235', null, '阳新县', '420222');
INSERT INTO `kl_area` VALUES ('1926', '210', null, '源汇区', '411102');
INSERT INTO `kl_area` VALUES ('1927', '198', null, '登封市', '410185');
INSERT INTO `kl_area` VALUES ('1928', '235', null, '大冶市', '420281');
INSERT INTO `kl_area` VALUES ('1929', '210', null, '郾城区', '411103');
INSERT INTO `kl_area` VALUES ('1930', '210', null, '召陵区', '411104');
INSERT INTO `kl_area` VALUES ('1931', '210', null, '舞阳县', '411121');
INSERT INTO `kl_area` VALUES ('1932', '210', null, '临颍县', '411122');
INSERT INTO `kl_area` VALUES ('1933', '200', null, '市辖区', '410201');
INSERT INTO `kl_area` VALUES ('1934', '236', null, '市辖区', '420301');
INSERT INTO `kl_area` VALUES ('1935', '200', null, '龙亭区', '410202');
INSERT INTO `kl_area` VALUES ('1936', '236', null, '茅箭区', '420302');
INSERT INTO `kl_area` VALUES ('1937', '200', null, '顺河回族区', '410203');
INSERT INTO `kl_area` VALUES ('1938', '236', null, '张湾区', '420303');
INSERT INTO `kl_area` VALUES ('1939', '211', null, '市辖区', '411201');
INSERT INTO `kl_area` VALUES ('1940', '200', null, '鼓楼区', '410204');
INSERT INTO `kl_area` VALUES ('1941', '236', null, '郧县', '420321');
INSERT INTO `kl_area` VALUES ('1942', '211', null, '湖滨区', '411202');
INSERT INTO `kl_area` VALUES ('1943', '200', null, '禹王台区', '410205');
INSERT INTO `kl_area` VALUES ('1944', '211', null, '渑池县', '411221');
INSERT INTO `kl_area` VALUES ('1945', '236', null, '郧西县', '420322');
INSERT INTO `kl_area` VALUES ('1946', '200', null, '金明区', '410211');
INSERT INTO `kl_area` VALUES ('1947', '236', null, '竹山县', '420323');
INSERT INTO `kl_area` VALUES ('1948', '211', null, '陕县', '411222');
INSERT INTO `kl_area` VALUES ('1949', '200', null, '杞县', '410221');
INSERT INTO `kl_area` VALUES ('1950', '236', null, '竹溪县', '420324');
INSERT INTO `kl_area` VALUES ('1951', '211', null, '卢氏县', '411224');
INSERT INTO `kl_area` VALUES ('1952', '200', null, '通许县', '410222');
INSERT INTO `kl_area` VALUES ('1953', '211', null, '义马市', '411281');
INSERT INTO `kl_area` VALUES ('1954', '200', null, '尉氏县', '410223');
INSERT INTO `kl_area` VALUES ('1955', '236', null, '房县', '420325');
INSERT INTO `kl_area` VALUES ('1956', '211', null, '灵宝市', '411282');
INSERT INTO `kl_area` VALUES ('1957', '200', null, '开封县', '410224');
INSERT INTO `kl_area` VALUES ('1958', '236', null, '丹江口市', '420381');
INSERT INTO `kl_area` VALUES ('1959', '200', null, '兰考县', '410225');
INSERT INTO `kl_area` VALUES ('1960', '212', null, '市辖区', '411301');
INSERT INTO `kl_area` VALUES ('1961', '237', null, '市辖区', '420501');
INSERT INTO `kl_area` VALUES ('1962', '212', null, '宛城区', '411302');
INSERT INTO `kl_area` VALUES ('1963', '237', null, '西陵区', '420502');
INSERT INTO `kl_area` VALUES ('1964', '202', null, '市辖区', '410301');
INSERT INTO `kl_area` VALUES ('1965', '212', null, '卧龙区', '411303');
INSERT INTO `kl_area` VALUES ('1966', '237', null, '伍家岗区', '420503');
INSERT INTO `kl_area` VALUES ('1967', '202', null, '老城区', '410302');
INSERT INTO `kl_area` VALUES ('1968', '212', null, '南召县', '411321');
INSERT INTO `kl_area` VALUES ('1969', '237', null, '点军区', '420504');
INSERT INTO `kl_area` VALUES ('1970', '202', null, '西工区', '410303');
INSERT INTO `kl_area` VALUES ('1971', '212', null, '方城县', '411322');
INSERT INTO `kl_area` VALUES ('1972', '237', null, '猇亭区', '420505');
INSERT INTO `kl_area` VALUES ('1973', '202', null, '瀍河回族区', '410304');
INSERT INTO `kl_area` VALUES ('1974', '212', null, '西峡县', '411323');
INSERT INTO `kl_area` VALUES ('1975', '237', null, '夷陵区', '420506');
INSERT INTO `kl_area` VALUES ('1976', '202', null, '涧西区', '410305');
INSERT INTO `kl_area` VALUES ('1977', '212', null, '镇平县', '411324');
INSERT INTO `kl_area` VALUES ('1978', '237', null, '远安县', '420525');
INSERT INTO `kl_area` VALUES ('1979', '202', null, '吉利区', '410306');
INSERT INTO `kl_area` VALUES ('1980', '212', null, '内乡县', '411325');
INSERT INTO `kl_area` VALUES ('1981', '237', null, '兴山县', '420526');
INSERT INTO `kl_area` VALUES ('1982', '202', null, '洛龙区', '410311');
INSERT INTO `kl_area` VALUES ('1983', '212', null, '淅川县', '411326');
INSERT INTO `kl_area` VALUES ('1984', '237', null, '秭归县', '420527');
INSERT INTO `kl_area` VALUES ('1985', '202', null, '孟津县', '410322');
INSERT INTO `kl_area` VALUES ('1986', '212', null, '社旗县', '411327');
INSERT INTO `kl_area` VALUES ('1987', '237', null, '长阳土家族自治县', '420528');
INSERT INTO `kl_area` VALUES ('1988', '202', null, '新安县', '410323');
INSERT INTO `kl_area` VALUES ('1989', '212', null, '唐河县', '411328');
INSERT INTO `kl_area` VALUES ('1990', '202', null, '栾川县', '410324');
INSERT INTO `kl_area` VALUES ('1991', '237', null, '五峰土家族自治县', '420529');
INSERT INTO `kl_area` VALUES ('1992', '212', null, '新野县', '411329');
INSERT INTO `kl_area` VALUES ('1993', '237', null, '宜都市', '420581');
INSERT INTO `kl_area` VALUES ('1994', '202', null, '嵩县', '410325');
INSERT INTO `kl_area` VALUES ('1995', '212', null, '桐柏县', '411330');
INSERT INTO `kl_area` VALUES ('1996', '237', null, '当阳市', '420582');
INSERT INTO `kl_area` VALUES ('1997', '202', null, '汝阳县', '410326');
INSERT INTO `kl_area` VALUES ('1998', '212', null, '邓州市', '411381');
INSERT INTO `kl_area` VALUES ('1999', '202', null, '宜阳县', '410327');
INSERT INTO `kl_area` VALUES ('2000', '237', null, '枝江市', '420583');
INSERT INTO `kl_area` VALUES ('2001', '202', null, '洛宁县', '410328');
INSERT INTO `kl_area` VALUES ('2002', '202', null, '伊川县', '410329');
INSERT INTO `kl_area` VALUES ('2003', '202', null, '偃师市', '410381');
INSERT INTO `kl_area` VALUES ('2004', '214', null, '市辖区', '411401');
INSERT INTO `kl_area` VALUES ('2005', '238', null, '市辖区', '420601');
INSERT INTO `kl_area` VALUES ('2006', '214', null, '梁园区', '411402');
INSERT INTO `kl_area` VALUES ('2007', '238', null, '襄城区', '420602');
INSERT INTO `kl_area` VALUES ('2008', '203', null, '市辖区', '410401');
INSERT INTO `kl_area` VALUES ('2009', '214', null, '睢阳区', '411403');
INSERT INTO `kl_area` VALUES ('2010', '203', null, '新华区', '410402');
INSERT INTO `kl_area` VALUES ('2011', '238', null, '樊城区', '420606');
INSERT INTO `kl_area` VALUES ('2012', '214', null, '民权县', '411421');
INSERT INTO `kl_area` VALUES ('2013', '203', null, '卫东区', '410403');
INSERT INTO `kl_area` VALUES ('2014', '238', null, '襄州区', '420607');
INSERT INTO `kl_area` VALUES ('2015', '214', null, '睢县', '411422');
INSERT INTO `kl_area` VALUES ('2016', '203', null, '石龙区', '410404');
INSERT INTO `kl_area` VALUES ('2017', '238', null, '南漳县', '420624');
INSERT INTO `kl_area` VALUES ('2018', '214', null, '宁陵县', '411423');
INSERT INTO `kl_area` VALUES ('2019', '238', null, '谷城县', '420625');
INSERT INTO `kl_area` VALUES ('2020', '203', null, '湛河区', '410411');
INSERT INTO `kl_area` VALUES ('2021', '214', null, '柘城县', '411424');
INSERT INTO `kl_area` VALUES ('2022', '238', null, '保康县', '420626');
INSERT INTO `kl_area` VALUES ('2023', '203', null, '宝丰县', '410421');
INSERT INTO `kl_area` VALUES ('2024', '214', null, '虞城县', '411425');
INSERT INTO `kl_area` VALUES ('2025', '203', null, '叶县', '410422');
INSERT INTO `kl_area` VALUES ('2026', '238', null, '老河口市', '420682');
INSERT INTO `kl_area` VALUES ('2027', '214', null, '夏邑县', '411426');
INSERT INTO `kl_area` VALUES ('2028', '238', null, '枣阳市', '420683');
INSERT INTO `kl_area` VALUES ('2029', '203', null, '鲁山县', '410423');
INSERT INTO `kl_area` VALUES ('2030', '214', null, '永城市', '411481');
INSERT INTO `kl_area` VALUES ('2031', '238', null, '宜城市', '420684');
INSERT INTO `kl_area` VALUES ('2032', '203', null, '郏县', '410425');
INSERT INTO `kl_area` VALUES ('2033', '203', null, '舞钢市', '410481');
INSERT INTO `kl_area` VALUES ('2034', '203', null, '汝州市', '410482');
INSERT INTO `kl_area` VALUES ('2035', '216', null, '市辖区', '411501');
INSERT INTO `kl_area` VALUES ('2036', '239', null, '市辖区', '420701');
INSERT INTO `kl_area` VALUES ('2037', '216', null, '浉河区', '411502');
INSERT INTO `kl_area` VALUES ('2038', '239', null, '梁子湖区', '420702');
INSERT INTO `kl_area` VALUES ('2039', '216', null, '平桥区', '411503');
INSERT INTO `kl_area` VALUES ('2040', '204', null, '市辖区', '410501');
INSERT INTO `kl_area` VALUES ('2041', '239', null, '华容区', '420703');
INSERT INTO `kl_area` VALUES ('2042', '204', null, '文峰区', '410502');
INSERT INTO `kl_area` VALUES ('2043', '216', null, '罗山县', '411521');
INSERT INTO `kl_area` VALUES ('2044', '239', null, '鄂城区', '420704');
INSERT INTO `kl_area` VALUES ('2045', '216', null, '光山县', '411522');
INSERT INTO `kl_area` VALUES ('2046', '204', null, '北关区', '410503');
INSERT INTO `kl_area` VALUES ('2047', '216', null, '新县', '411523');
INSERT INTO `kl_area` VALUES ('2048', '204', null, '殷都区', '410505');
INSERT INTO `kl_area` VALUES ('2049', '216', null, '商城县', '411524');
INSERT INTO `kl_area` VALUES ('2050', '204', null, '龙安区', '410506');
INSERT INTO `kl_area` VALUES ('2051', '216', null, '固始县', '411525');
INSERT INTO `kl_area` VALUES ('2052', '204', null, '安阳县', '410522');
INSERT INTO `kl_area` VALUES ('2053', '216', null, '潢川县', '411526');
INSERT INTO `kl_area` VALUES ('2054', '204', null, '汤阴县', '410523');
INSERT INTO `kl_area` VALUES ('2055', '216', null, '淮滨县', '411527');
INSERT INTO `kl_area` VALUES ('2056', '204', null, '滑县', '410526');
INSERT INTO `kl_area` VALUES ('2057', '216', null, '息县', '411528');
INSERT INTO `kl_area` VALUES ('2058', '204', null, '内黄县', '410527');
INSERT INTO `kl_area` VALUES ('2059', '204', null, '林州市', '410581');
INSERT INTO `kl_area` VALUES ('2060', '240', null, '市辖区', '420801');
INSERT INTO `kl_area` VALUES ('2061', '240', null, '东宝区', '420802');
INSERT INTO `kl_area` VALUES ('2062', '240', null, '掇刀区', '420804');
INSERT INTO `kl_area` VALUES ('2063', '240', null, '京山县', '420821');
INSERT INTO `kl_area` VALUES ('2064', '240', null, '沙洋县', '420822');
INSERT INTO `kl_area` VALUES ('2065', '240', null, '钟祥市', '420881');
INSERT INTO `kl_area` VALUES ('2066', '218', null, '市辖区', '411601');
INSERT INTO `kl_area` VALUES ('2067', '205', null, '市辖区', '410601');
INSERT INTO `kl_area` VALUES ('2068', '218', null, '川汇区', '411602');
INSERT INTO `kl_area` VALUES ('2069', '205', null, '鹤山区', '410602');
INSERT INTO `kl_area` VALUES ('2070', '218', null, '扶沟县', '411621');
INSERT INTO `kl_area` VALUES ('2071', '205', null, '山城区', '410603');
INSERT INTO `kl_area` VALUES ('2072', '218', null, '西华县', '411622');
INSERT INTO `kl_area` VALUES ('2073', '205', null, '淇滨区', '410611');
INSERT INTO `kl_area` VALUES ('2074', '218', null, '商水县', '411623');
INSERT INTO `kl_area` VALUES ('2075', '205', null, '浚县', '410621');
INSERT INTO `kl_area` VALUES ('2076', '218', null, '沈丘县', '411624');
INSERT INTO `kl_area` VALUES ('2077', '205', null, '淇县', '410622');
INSERT INTO `kl_area` VALUES ('2078', '218', null, '郸城县', '411625');
INSERT INTO `kl_area` VALUES ('2079', '218', null, '淮阳县', '411626');
INSERT INTO `kl_area` VALUES ('2080', '218', null, '太康县', '411627');
INSERT INTO `kl_area` VALUES ('2081', '218', null, '鹿邑县', '411628');
INSERT INTO `kl_area` VALUES ('2082', '218', null, '项城市', '411681');
INSERT INTO `kl_area` VALUES ('2083', '242', null, '市辖区', '420901');
INSERT INTO `kl_area` VALUES ('2084', '242', null, '孝南区', '420902');
INSERT INTO `kl_area` VALUES ('2085', '242', null, '孝昌县', '420921');
INSERT INTO `kl_area` VALUES ('2086', '242', null, '大悟县', '420922');
INSERT INTO `kl_area` VALUES ('2087', '242', null, '云梦县', '420923');
INSERT INTO `kl_area` VALUES ('2088', '242', null, '应城市', '420981');
INSERT INTO `kl_area` VALUES ('2089', '242', null, '安陆市', '420982');
INSERT INTO `kl_area` VALUES ('2090', '242', null, '汉川市', '420984');
INSERT INTO `kl_area` VALUES ('2091', '206', null, '市辖区', '410701');
INSERT INTO `kl_area` VALUES ('2092', '206', null, '红旗区', '410702');
INSERT INTO `kl_area` VALUES ('2093', '220', null, '市辖区', '411701');
INSERT INTO `kl_area` VALUES ('2094', '206', null, '卫滨区', '410703');
INSERT INTO `kl_area` VALUES ('2095', '220', null, '驿城区', '411702');
INSERT INTO `kl_area` VALUES ('2096', '206', null, '凤泉区', '410704');
INSERT INTO `kl_area` VALUES ('2097', '220', null, '西平县', '411721');
INSERT INTO `kl_area` VALUES ('2098', '206', null, '牧野区', '410711');
INSERT INTO `kl_area` VALUES ('2099', '220', null, '上蔡县', '411722');
INSERT INTO `kl_area` VALUES ('2100', '206', null, '新乡县', '410721');
INSERT INTO `kl_area` VALUES ('2101', '220', null, '平舆县', '411723');
INSERT INTO `kl_area` VALUES ('2102', '206', null, '获嘉县', '410724');
INSERT INTO `kl_area` VALUES ('2103', '220', null, '正阳县', '411724');
INSERT INTO `kl_area` VALUES ('2104', '244', null, '市辖区', '421001');
INSERT INTO `kl_area` VALUES ('2105', '220', null, '确山县', '411725');
INSERT INTO `kl_area` VALUES ('2106', '206', null, '原阳县', '410725');
INSERT INTO `kl_area` VALUES ('2107', '244', null, '沙市区', '421002');
INSERT INTO `kl_area` VALUES ('2108', '220', null, '泌阳县', '411726');
INSERT INTO `kl_area` VALUES ('2109', '206', null, '延津县', '410726');
INSERT INTO `kl_area` VALUES ('2110', '244', null, '荆州区', '421003');
INSERT INTO `kl_area` VALUES ('2111', '206', null, '封丘县', '410727');
INSERT INTO `kl_area` VALUES ('2112', '220', null, '汝南县', '411727');
INSERT INTO `kl_area` VALUES ('2113', '244', null, '公安县', '421022');
INSERT INTO `kl_area` VALUES ('2114', '206', null, '长垣县', '410728');
INSERT INTO `kl_area` VALUES ('2115', '220', null, '遂平县', '411728');
INSERT INTO `kl_area` VALUES ('2116', '244', null, '监利县', '421023');
INSERT INTO `kl_area` VALUES ('2117', '206', null, '卫辉市', '410781');
INSERT INTO `kl_area` VALUES ('2118', '220', null, '新蔡县', '411729');
INSERT INTO `kl_area` VALUES ('2119', '244', null, '江陵县', '421024');
INSERT INTO `kl_area` VALUES ('2120', '206', null, '辉县市', '410782');
INSERT INTO `kl_area` VALUES ('2121', '244', null, '石首市', '421081');
INSERT INTO `kl_area` VALUES ('2122', '244', null, '洪湖市', '421083');
INSERT INTO `kl_area` VALUES ('2123', '244', null, '松滋市', '421087');
INSERT INTO `kl_area` VALUES ('2124', '246', null, '市辖区', '421101');
INSERT INTO `kl_area` VALUES ('2125', '246', null, '黄州区', '421102');
INSERT INTO `kl_area` VALUES ('2126', '246', null, '团风县', '421121');
INSERT INTO `kl_area` VALUES ('2127', '246', null, '红安县', '421122');
INSERT INTO `kl_area` VALUES ('2128', '246', null, '罗田县', '421123');
INSERT INTO `kl_area` VALUES ('2129', '246', null, '英山县', '421124');
INSERT INTO `kl_area` VALUES ('2130', '246', null, '浠水县', '421125');
INSERT INTO `kl_area` VALUES ('2131', '246', null, '蕲春县', '421126');
INSERT INTO `kl_area` VALUES ('2132', '246', null, '黄梅县', '421127');
INSERT INTO `kl_area` VALUES ('2133', '246', null, '麻城市', '421181');
INSERT INTO `kl_area` VALUES ('2134', '246', null, '武穴市', '421182');
INSERT INTO `kl_area` VALUES ('2135', '276', null, '市辖区', '430601');
INSERT INTO `kl_area` VALUES ('2136', '276', null, '岳阳楼区', '430602');
INSERT INTO `kl_area` VALUES ('2137', '276', null, '云溪区', '430603');
INSERT INTO `kl_area` VALUES ('2138', '276', null, '君山区', '430611');
INSERT INTO `kl_area` VALUES ('2139', '276', null, '岳阳县', '430621');
INSERT INTO `kl_area` VALUES ('2140', '276', null, '华容县', '430623');
INSERT INTO `kl_area` VALUES ('2141', '276', null, '湘阴县', '430624');
INSERT INTO `kl_area` VALUES ('2142', '276', null, '平江县', '430626');
INSERT INTO `kl_area` VALUES ('2143', '276', null, '汨罗市', '430681');
INSERT INTO `kl_area` VALUES ('2144', '276', null, '临湘市', '430682');
INSERT INTO `kl_area` VALUES ('2145', '249', null, '市辖区', '421201');
INSERT INTO `kl_area` VALUES ('2146', '249', null, '咸安区', '421202');
INSERT INTO `kl_area` VALUES ('2147', '249', null, '嘉鱼县', '421221');
INSERT INTO `kl_area` VALUES ('2148', '249', null, '通城县', '421222');
INSERT INTO `kl_area` VALUES ('2149', '249', null, '崇阳县', '421223');
INSERT INTO `kl_area` VALUES ('2150', '249', null, '通山县', '421224');
INSERT INTO `kl_area` VALUES ('2151', '249', null, '赤壁市', '421281');
INSERT INTO `kl_area` VALUES ('2152', '277', null, '市辖区', '430701');
INSERT INTO `kl_area` VALUES ('2153', '277', null, '武陵区', '430702');
INSERT INTO `kl_area` VALUES ('2154', '277', null, '鼎城区', '430703');
INSERT INTO `kl_area` VALUES ('2155', '277', null, '安乡县', '430721');
INSERT INTO `kl_area` VALUES ('2156', '277', null, '汉寿县', '430722');
INSERT INTO `kl_area` VALUES ('2157', '277', null, '澧县', '430723');
INSERT INTO `kl_area` VALUES ('2158', '277', null, '临澧县', '430724');
INSERT INTO `kl_area` VALUES ('2159', '252', null, '市辖区', '421301');
INSERT INTO `kl_area` VALUES ('2160', '277', null, '桃源县', '430725');
INSERT INTO `kl_area` VALUES ('2161', '252', null, '曾都区', '421303');
INSERT INTO `kl_area` VALUES ('2162', '277', null, '石门县', '430726');
INSERT INTO `kl_area` VALUES ('2163', '252', null, '随县', '421321');
INSERT INTO `kl_area` VALUES ('2164', '277', null, '津市市', '430781');
INSERT INTO `kl_area` VALUES ('2165', '252', null, '广水市', '421381');
INSERT INTO `kl_area` VALUES ('2166', '278', null, '市辖区', '430801');
INSERT INTO `kl_area` VALUES ('2167', '255', null, '恩施市', '422801');
INSERT INTO `kl_area` VALUES ('2168', '278', null, '永定区', '430802');
INSERT INTO `kl_area` VALUES ('2169', '255', null, '利川市', '422802');
INSERT INTO `kl_area` VALUES ('2170', '278', null, '武陵源区', '430811');
INSERT INTO `kl_area` VALUES ('2171', '255', null, '建始县', '422822');
INSERT INTO `kl_area` VALUES ('2172', '278', null, '慈利县', '430821');
INSERT INTO `kl_area` VALUES ('2173', '255', null, '巴东县', '422823');
INSERT INTO `kl_area` VALUES ('2174', '278', null, '桑植县', '430822');
INSERT INTO `kl_area` VALUES ('2175', '255', null, '宣恩县', '422825');
INSERT INTO `kl_area` VALUES ('2176', '255', null, '咸丰县', '422826');
INSERT INTO `kl_area` VALUES ('2177', '255', null, '来凤县', '422827');
INSERT INTO `kl_area` VALUES ('2178', '255', null, '鹤峰县', '422828');
INSERT INTO `kl_area` VALUES ('2179', '279', null, '市辖区', '430901');
INSERT INTO `kl_area` VALUES ('2180', '279', null, '资阳区', '430902');
INSERT INTO `kl_area` VALUES ('2181', '279', null, '赫山区', '430903');
INSERT INTO `kl_area` VALUES ('2182', '259', null, '仙桃市', '429004');
INSERT INTO `kl_area` VALUES ('2183', '279', null, '南县', '430921');
INSERT INTO `kl_area` VALUES ('2184', '259', null, '潜江市', '429005');
INSERT INTO `kl_area` VALUES ('2185', '279', null, '桃江县', '430922');
INSERT INTO `kl_area` VALUES ('2186', '259', null, '天门市', '429006');
INSERT INTO `kl_area` VALUES ('2187', '279', null, '安化县', '430923');
INSERT INTO `kl_area` VALUES ('2188', '259', null, '神农架林区', '429021');
INSERT INTO `kl_area` VALUES ('2189', '279', null, '沅江市', '430981');
INSERT INTO `kl_area` VALUES ('2190', '271', null, '市辖区', '430101');
INSERT INTO `kl_area` VALUES ('2191', '280', null, '市辖区', '431001');
INSERT INTO `kl_area` VALUES ('2192', '271', null, '芙蓉区', '430102');
INSERT INTO `kl_area` VALUES ('2193', '280', null, '北湖区', '431002');
INSERT INTO `kl_area` VALUES ('2194', '271', null, '天心区', '430103');
INSERT INTO `kl_area` VALUES ('2195', '280', null, '苏仙区', '431003');
INSERT INTO `kl_area` VALUES ('2196', '271', null, '岳麓区', '430104');
INSERT INTO `kl_area` VALUES ('2197', '280', null, '桂阳县', '431021');
INSERT INTO `kl_area` VALUES ('2198', '271', null, '开福区', '430105');
INSERT INTO `kl_area` VALUES ('2199', '280', null, '宜章县', '431022');
INSERT INTO `kl_area` VALUES ('2200', '271', null, '雨花区', '430111');
INSERT INTO `kl_area` VALUES ('2201', '280', null, '永兴县', '431023');
INSERT INTO `kl_area` VALUES ('2202', '271', null, '望城区', '430112');
INSERT INTO `kl_area` VALUES ('2203', '280', null, '嘉禾县', '431024');
INSERT INTO `kl_area` VALUES ('2204', '271', null, '长沙县', '430121');
INSERT INTO `kl_area` VALUES ('2205', '280', null, '临武县', '431025');
INSERT INTO `kl_area` VALUES ('2206', '271', null, '宁乡县', '430124');
INSERT INTO `kl_area` VALUES ('2207', '280', null, '汝城县', '431026');
INSERT INTO `kl_area` VALUES ('2208', '271', null, '浏阳市', '430181');
INSERT INTO `kl_area` VALUES ('2209', '280', null, '桂东县', '431027');
INSERT INTO `kl_area` VALUES ('2210', '280', null, '安仁县', '431028');
INSERT INTO `kl_area` VALUES ('2211', '280', null, '资兴市', '431081');
INSERT INTO `kl_area` VALUES ('2212', '272', null, '市辖区', '430201');
INSERT INTO `kl_area` VALUES ('2213', '272', null, '荷塘区', '430202');
INSERT INTO `kl_area` VALUES ('2214', '272', null, '芦淞区', '430203');
INSERT INTO `kl_area` VALUES ('2215', '281', null, '市辖区', '431101');
INSERT INTO `kl_area` VALUES ('2216', '272', null, '石峰区', '430204');
INSERT INTO `kl_area` VALUES ('2217', '281', null, '零陵区', '431102');
INSERT INTO `kl_area` VALUES ('2218', '272', null, '天元区', '430211');
INSERT INTO `kl_area` VALUES ('2219', '281', null, '冷水滩区', '431103');
INSERT INTO `kl_area` VALUES ('2220', '272', null, '株洲县', '430221');
INSERT INTO `kl_area` VALUES ('2221', '281', null, '祁阳县', '431121');
INSERT INTO `kl_area` VALUES ('2222', '272', null, '攸县', '430223');
INSERT INTO `kl_area` VALUES ('2223', '281', null, '东安县', '431122');
INSERT INTO `kl_area` VALUES ('2224', '272', null, '茶陵县', '430224');
INSERT INTO `kl_area` VALUES ('2225', '281', null, '双牌县', '431123');
INSERT INTO `kl_area` VALUES ('2226', '272', null, '炎陵县', '430225');
INSERT INTO `kl_area` VALUES ('2227', '281', null, '道县', '431124');
INSERT INTO `kl_area` VALUES ('2228', '272', null, '醴陵市', '430281');
INSERT INTO `kl_area` VALUES ('2229', '281', null, '江永县', '431125');
INSERT INTO `kl_area` VALUES ('2230', '281', null, '宁远县', '431126');
INSERT INTO `kl_area` VALUES ('2231', '281', null, '蓝山县', '431127');
INSERT INTO `kl_area` VALUES ('2232', '281', null, '新田县', '431128');
INSERT INTO `kl_area` VALUES ('2233', '281', null, '江华瑶族自治县', '431129');
INSERT INTO `kl_area` VALUES ('2234', '273', null, '市辖区', '430301');
INSERT INTO `kl_area` VALUES ('2235', '273', null, '雨湖区', '430302');
INSERT INTO `kl_area` VALUES ('2236', '273', null, '岳塘区', '430304');
INSERT INTO `kl_area` VALUES ('2237', '273', null, '湘潭县', '430321');
INSERT INTO `kl_area` VALUES ('2238', '273', null, '湘乡市', '430381');
INSERT INTO `kl_area` VALUES ('2239', '283', null, '市辖区', '431201');
INSERT INTO `kl_area` VALUES ('2240', '273', null, '韶山市', '430382');
INSERT INTO `kl_area` VALUES ('2241', '283', null, '鹤城区', '431202');
INSERT INTO `kl_area` VALUES ('2242', '283', null, '中方县', '431221');
INSERT INTO `kl_area` VALUES ('2243', '283', null, '沅陵县', '431222');
INSERT INTO `kl_area` VALUES ('2244', '283', null, '辰溪县', '431223');
INSERT INTO `kl_area` VALUES ('2245', '283', null, '溆浦县', '431224');
INSERT INTO `kl_area` VALUES ('2246', '283', null, '会同县', '431225');
INSERT INTO `kl_area` VALUES ('2247', '283', null, '麻阳苗族自治县', '431226');
INSERT INTO `kl_area` VALUES ('2248', '283', null, '新晃侗族自治县', '431227');
INSERT INTO `kl_area` VALUES ('2249', '283', null, '芷江侗族自治县', '431228');
INSERT INTO `kl_area` VALUES ('2250', '283', null, '靖州苗族侗族自治县', '431229');
INSERT INTO `kl_area` VALUES ('2251', '283', null, '通道侗族自治县', '431230');
INSERT INTO `kl_area` VALUES ('2252', '283', null, '洪江市', '431281');
INSERT INTO `kl_area` VALUES ('2253', '274', null, '市辖区', '430401');
INSERT INTO `kl_area` VALUES ('2254', '274', null, '珠晖区', '430405');
INSERT INTO `kl_area` VALUES ('2255', '274', null, '雁峰区', '430406');
INSERT INTO `kl_area` VALUES ('2256', '274', null, '石鼓区', '430407');
INSERT INTO `kl_area` VALUES ('2257', '274', null, '蒸湘区', '430408');
INSERT INTO `kl_area` VALUES ('2258', '274', null, '南岳区', '430412');
INSERT INTO `kl_area` VALUES ('2259', '274', null, '衡阳县', '430421');
INSERT INTO `kl_area` VALUES ('2260', '274', null, '衡南县', '430422');
INSERT INTO `kl_area` VALUES ('2261', '274', null, '衡山县', '430423');
INSERT INTO `kl_area` VALUES ('2262', '274', null, '衡东县', '430424');
INSERT INTO `kl_area` VALUES ('2263', '274', null, '祁东县', '430426');
INSERT INTO `kl_area` VALUES ('2264', '274', null, '耒阳市', '430481');
INSERT INTO `kl_area` VALUES ('2265', '274', null, '常宁市', '430482');
INSERT INTO `kl_area` VALUES ('2266', '286', null, '市辖区', '431301');
INSERT INTO `kl_area` VALUES ('2267', '286', null, '娄星区', '431302');
INSERT INTO `kl_area` VALUES ('2268', '286', null, '双峰县', '431321');
INSERT INTO `kl_area` VALUES ('2269', '286', null, '新化县', '431322');
INSERT INTO `kl_area` VALUES ('2270', '286', null, '冷水江市', '431381');
INSERT INTO `kl_area` VALUES ('2271', '286', null, '涟源市', '431382');
INSERT INTO `kl_area` VALUES ('2272', '275', null, '市辖区', '430501');
INSERT INTO `kl_area` VALUES ('2273', '275', null, '双清区', '430502');
INSERT INTO `kl_area` VALUES ('2274', '275', null, '大祥区', '430503');
INSERT INTO `kl_area` VALUES ('2275', '275', null, '北塔区', '430511');
INSERT INTO `kl_area` VALUES ('2276', '275', null, '邵东县', '430521');
INSERT INTO `kl_area` VALUES ('2277', '275', null, '新邵县', '430522');
INSERT INTO `kl_area` VALUES ('2278', '275', null, '邵阳县', '430523');
INSERT INTO `kl_area` VALUES ('2279', '289', null, '吉首市', '433101');
INSERT INTO `kl_area` VALUES ('2280', '275', null, '隆回县', '430524');
INSERT INTO `kl_area` VALUES ('2281', '289', null, '泸溪县', '433122');
INSERT INTO `kl_area` VALUES ('2282', '275', null, '洞口县', '430525');
INSERT INTO `kl_area` VALUES ('2283', '289', null, '凤凰县', '433123');
INSERT INTO `kl_area` VALUES ('2284', '275', null, '绥宁县', '430527');
INSERT INTO `kl_area` VALUES ('2285', '289', null, '花垣县', '433124');
INSERT INTO `kl_area` VALUES ('2286', '275', null, '新宁县', '430528');
INSERT INTO `kl_area` VALUES ('2287', '289', null, '保靖县', '433125');
INSERT INTO `kl_area` VALUES ('2288', '275', null, '城步苗族自治县', '430529');
INSERT INTO `kl_area` VALUES ('2289', '289', null, '古丈县', '433126');
INSERT INTO `kl_area` VALUES ('2290', '275', null, '武冈市', '430581');
INSERT INTO `kl_area` VALUES ('2291', '289', null, '永顺县', '433127');
INSERT INTO `kl_area` VALUES ('2292', '289', null, '龙山县', '433130');
INSERT INTO `kl_area` VALUES ('2293', '302', null, '市辖区', '440101');
INSERT INTO `kl_area` VALUES ('2294', '302', null, '荔湾区', '440103');
INSERT INTO `kl_area` VALUES ('2295', '302', null, '越秀区', '440104');
INSERT INTO `kl_area` VALUES ('2296', '302', null, '海珠区', '440105');
INSERT INTO `kl_area` VALUES ('2297', '302', null, '天河区', '440106');
INSERT INTO `kl_area` VALUES ('2298', '302', null, '白云区', '440111');
INSERT INTO `kl_area` VALUES ('2299', '302', null, '黄埔区', '440112');
INSERT INTO `kl_area` VALUES ('2300', '302', null, '番禺区', '440113');
INSERT INTO `kl_area` VALUES ('2301', '302', null, '花都区', '440114');
INSERT INTO `kl_area` VALUES ('2302', '302', null, '南沙区', '440115');
INSERT INTO `kl_area` VALUES ('2303', '302', null, '萝岗区', '440116');
INSERT INTO `kl_area` VALUES ('2304', '302', null, '增城市', '440183');
INSERT INTO `kl_area` VALUES ('2305', '302', null, '从化市', '440184');
INSERT INTO `kl_area` VALUES ('2306', '304', null, '市辖区', '440201');
INSERT INTO `kl_area` VALUES ('2307', '304', null, '武江区', '440203');
INSERT INTO `kl_area` VALUES ('2308', '304', null, '浈江区', '440204');
INSERT INTO `kl_area` VALUES ('2309', '304', null, '曲江区', '440205');
INSERT INTO `kl_area` VALUES ('2310', '304', null, '始兴县', '440222');
INSERT INTO `kl_area` VALUES ('2311', '304', null, '仁化县', '440224');
INSERT INTO `kl_area` VALUES ('2312', '304', null, '翁源县', '440229');
INSERT INTO `kl_area` VALUES ('2313', '304', null, '乳源瑶族自治县', '440232');
INSERT INTO `kl_area` VALUES ('2314', '304', null, '新丰县', '440233');
INSERT INTO `kl_area` VALUES ('2315', '304', null, '乐昌市', '440281');
INSERT INTO `kl_area` VALUES ('2316', '304', null, '南雄市', '440282');
INSERT INTO `kl_area` VALUES ('2317', '329', null, '市辖区', '441401');
INSERT INTO `kl_area` VALUES ('2318', '329', null, '梅江区', '441402');
INSERT INTO `kl_area` VALUES ('2319', '329', null, '梅县', '441421');
INSERT INTO `kl_area` VALUES ('2320', '329', null, '大埔县', '441422');
INSERT INTO `kl_area` VALUES ('2321', '329', null, '丰顺县', '441423');
INSERT INTO `kl_area` VALUES ('2322', '329', null, '五华县', '441424');
INSERT INTO `kl_area` VALUES ('2323', '329', null, '平远县', '441426');
INSERT INTO `kl_area` VALUES ('2324', '329', null, '蕉岭县', '441427');
INSERT INTO `kl_area` VALUES ('2325', '329', null, '兴宁市', '441481');
INSERT INTO `kl_area` VALUES ('2326', '306', null, '市辖区', '440301');
INSERT INTO `kl_area` VALUES ('2327', '306', null, '罗湖区', '440303');
INSERT INTO `kl_area` VALUES ('2328', '306', null, '福田区', '440304');
INSERT INTO `kl_area` VALUES ('2329', '306', null, '南山区', '440305');
INSERT INTO `kl_area` VALUES ('2330', '306', null, '宝安区', '440306');
INSERT INTO `kl_area` VALUES ('2331', '306', null, '龙岗区', '440307');
INSERT INTO `kl_area` VALUES ('2332', '306', null, '盐田区', '440308');
INSERT INTO `kl_area` VALUES ('2333', '347', null, '市辖区', '450101');
INSERT INTO `kl_area` VALUES ('2334', '347', null, '兴宁区', '450102');
INSERT INTO `kl_area` VALUES ('2335', '347', null, '青秀区', '450103');
INSERT INTO `kl_area` VALUES ('2336', '347', null, '江南区', '450105');
INSERT INTO `kl_area` VALUES ('2337', '347', null, '西乡塘区', '450107');
INSERT INTO `kl_area` VALUES ('2338', '347', null, '良庆区', '450108');
INSERT INTO `kl_area` VALUES ('2339', '347', null, '邕宁区', '450109');
INSERT INTO `kl_area` VALUES ('2340', '347', null, '武鸣县', '450122');
INSERT INTO `kl_area` VALUES ('2341', '347', null, '隆安县', '450123');
INSERT INTO `kl_area` VALUES ('2342', '347', null, '马山县', '450124');
INSERT INTO `kl_area` VALUES ('2343', '332', null, '市辖区', '441501');
INSERT INTO `kl_area` VALUES ('2344', '347', null, '上林县', '450125');
INSERT INTO `kl_area` VALUES ('2345', '332', null, '城区', '441502');
INSERT INTO `kl_area` VALUES ('2346', '347', null, '宾阳县', '450126');
INSERT INTO `kl_area` VALUES ('2347', '332', null, '海丰县', '441521');
INSERT INTO `kl_area` VALUES ('2348', '347', null, '横县', '450127');
INSERT INTO `kl_area` VALUES ('2349', '332', null, '陆河县', '441523');
INSERT INTO `kl_area` VALUES ('2350', '332', null, '陆丰市', '441581');
INSERT INTO `kl_area` VALUES ('2351', '308', null, '市辖区', '440401');
INSERT INTO `kl_area` VALUES ('2352', '308', null, '香洲区', '440402');
INSERT INTO `kl_area` VALUES ('2353', '308', null, '斗门区', '440403');
INSERT INTO `kl_area` VALUES ('2354', '308', null, '金湾区', '440404');
INSERT INTO `kl_area` VALUES ('2355', '349', null, '市辖区', '450201');
INSERT INTO `kl_area` VALUES ('2356', '334', null, '市辖区', '441601');
INSERT INTO `kl_area` VALUES ('2357', '349', null, '城中区', '450202');
INSERT INTO `kl_area` VALUES ('2358', '334', null, '源城区', '441602');
INSERT INTO `kl_area` VALUES ('2359', '349', null, '鱼峰区', '450203');
INSERT INTO `kl_area` VALUES ('2360', '334', null, '紫金县', '441621');
INSERT INTO `kl_area` VALUES ('2361', '349', null, '柳南区', '450204');
INSERT INTO `kl_area` VALUES ('2362', '334', null, '龙川县', '441622');
INSERT INTO `kl_area` VALUES ('2363', '349', null, '柳北区', '450205');
INSERT INTO `kl_area` VALUES ('2364', '334', null, '连平县', '441623');
INSERT INTO `kl_area` VALUES ('2365', '349', null, '柳江县', '450221');
INSERT INTO `kl_area` VALUES ('2366', '334', null, '和平县', '441624');
INSERT INTO `kl_area` VALUES ('2367', '310', null, '市辖区', '440501');
INSERT INTO `kl_area` VALUES ('2368', '349', null, '柳城县', '450222');
INSERT INTO `kl_area` VALUES ('2369', '334', null, '东源县', '441625');
INSERT INTO `kl_area` VALUES ('2370', '310', null, '龙湖区', '440507');
INSERT INTO `kl_area` VALUES ('2371', '349', null, '鹿寨县', '450223');
INSERT INTO `kl_area` VALUES ('2372', '310', null, '金平区', '440511');
INSERT INTO `kl_area` VALUES ('2373', '349', null, '融安县', '450224');
INSERT INTO `kl_area` VALUES ('2374', '310', null, '濠江区', '440512');
INSERT INTO `kl_area` VALUES ('2375', '349', null, '融水苗族自治县', '450225');
INSERT INTO `kl_area` VALUES ('2376', '310', null, '潮阳区', '440513');
INSERT INTO `kl_area` VALUES ('2377', '349', null, '三江侗族自治县', '450226');
INSERT INTO `kl_area` VALUES ('2378', '310', null, '潮南区', '440514');
INSERT INTO `kl_area` VALUES ('2379', '310', null, '澄海区', '440515');
INSERT INTO `kl_area` VALUES ('2380', '310', null, '南澳县', '440523');
INSERT INTO `kl_area` VALUES ('2381', '336', null, '市辖区', '441701');
INSERT INTO `kl_area` VALUES ('2382', '336', null, '江城区', '441702');
INSERT INTO `kl_area` VALUES ('2383', '336', null, '阳西县', '441721');
INSERT INTO `kl_area` VALUES ('2384', '336', null, '阳东县', '441723');
INSERT INTO `kl_area` VALUES ('2385', '336', null, '阳春市', '441781');
INSERT INTO `kl_area` VALUES ('2386', '350', null, '市辖区', '450301');
INSERT INTO `kl_area` VALUES ('2387', '350', null, '秀峰区', '450302');
INSERT INTO `kl_area` VALUES ('2388', '350', null, '叠彩区', '450303');
INSERT INTO `kl_area` VALUES ('2389', '312', null, '市辖区', '440601');
INSERT INTO `kl_area` VALUES ('2390', '350', null, '象山区', '450304');
INSERT INTO `kl_area` VALUES ('2391', '312', null, '禅城区', '440604');
INSERT INTO `kl_area` VALUES ('2392', '350', null, '七星区', '450305');
INSERT INTO `kl_area` VALUES ('2393', '312', null, '南海区', '440605');
INSERT INTO `kl_area` VALUES ('2394', '350', null, '雁山区', '450311');
INSERT INTO `kl_area` VALUES ('2395', '312', null, '顺德区', '440606');
INSERT INTO `kl_area` VALUES ('2396', '350', null, '临桂区', '450312');
INSERT INTO `kl_area` VALUES ('2397', '312', null, '三水区', '440607');
INSERT INTO `kl_area` VALUES ('2398', '350', null, '阳朔县', '450321');
INSERT INTO `kl_area` VALUES ('2399', '312', null, '高明区', '440608');
INSERT INTO `kl_area` VALUES ('2400', '350', null, '灵川县', '450323');
INSERT INTO `kl_area` VALUES ('2401', '350', null, '全州县', '450324');
INSERT INTO `kl_area` VALUES ('2402', '350', null, '兴安县', '450325');
INSERT INTO `kl_area` VALUES ('2403', '350', null, '永福县', '450326');
INSERT INTO `kl_area` VALUES ('2404', '350', null, '灌阳县', '450327');
INSERT INTO `kl_area` VALUES ('2405', '350', null, '龙胜各族自治县', '450328');
INSERT INTO `kl_area` VALUES ('2406', '350', null, '资源县', '450329');
INSERT INTO `kl_area` VALUES ('2407', '350', null, '平乐县', '450330');
INSERT INTO `kl_area` VALUES ('2408', '350', null, '荔浦县', '450331');
INSERT INTO `kl_area` VALUES ('2409', '337', null, '市辖区', '441801');
INSERT INTO `kl_area` VALUES ('2410', '350', null, '恭城瑶族自治县', '450332');
INSERT INTO `kl_area` VALUES ('2411', '337', null, '清城区', '441802');
INSERT INTO `kl_area` VALUES ('2412', '337', null, '清新区', '441803');
INSERT INTO `kl_area` VALUES ('2413', '337', null, '佛冈县', '441821');
INSERT INTO `kl_area` VALUES ('2414', '337', null, '阳山县', '441823');
INSERT INTO `kl_area` VALUES ('2415', '337', null, '连山壮族瑶族自治县', '441825');
INSERT INTO `kl_area` VALUES ('2416', '337', null, '连南瑶族自治县', '441826');
INSERT INTO `kl_area` VALUES ('2417', '337', null, '英德市', '441881');
INSERT INTO `kl_area` VALUES ('2418', '337', null, '连州市', '441882');
INSERT INTO `kl_area` VALUES ('2419', '314', null, '市辖区', '440701');
INSERT INTO `kl_area` VALUES ('2420', '314', null, '蓬江区', '440703');
INSERT INTO `kl_area` VALUES ('2421', '314', null, '江海区', '440704');
INSERT INTO `kl_area` VALUES ('2422', '314', null, '新会区', '440705');
INSERT INTO `kl_area` VALUES ('2423', '314', null, '台山市', '440781');
INSERT INTO `kl_area` VALUES ('2424', '314', null, '开平市', '440783');
INSERT INTO `kl_area` VALUES ('2425', '314', null, '鹤山市', '440784');
INSERT INTO `kl_area` VALUES ('2426', '314', null, '恩平市', '440785');
INSERT INTO `kl_area` VALUES ('2427', '351', null, '市辖区', '450401');
INSERT INTO `kl_area` VALUES ('2428', '351', null, '万秀区', '450403');
INSERT INTO `kl_area` VALUES ('2429', '351', null, '长洲区', '450405');
INSERT INTO `kl_area` VALUES ('2430', '351', null, '龙圩区', '450406');
INSERT INTO `kl_area` VALUES ('2431', '351', null, '苍梧县', '450421');
INSERT INTO `kl_area` VALUES ('2432', '351', null, '藤县', '450422');
INSERT INTO `kl_area` VALUES ('2433', '351', null, '蒙山县', '450423');
INSERT INTO `kl_area` VALUES ('2434', '351', null, '岑溪市', '450481');
INSERT INTO `kl_area` VALUES ('2435', '317', null, '市辖区', '440801');
INSERT INTO `kl_area` VALUES ('2436', '317', null, '赤坎区', '440802');
INSERT INTO `kl_area` VALUES ('2437', '317', null, '霞山区', '440803');
INSERT INTO `kl_area` VALUES ('2438', '317', null, '坡头区', '440804');
INSERT INTO `kl_area` VALUES ('2439', '317', null, '麻章区', '440811');
INSERT INTO `kl_area` VALUES ('2440', '317', null, '遂溪县', '440823');
INSERT INTO `kl_area` VALUES ('2441', '317', null, '徐闻县', '440825');
INSERT INTO `kl_area` VALUES ('2442', '317', null, '廉江市', '440881');
INSERT INTO `kl_area` VALUES ('2443', '317', null, '雷州市', '440882');
INSERT INTO `kl_area` VALUES ('2444', '317', null, '吴川市', '440883');
INSERT INTO `kl_area` VALUES ('2445', '352', null, '市辖区', '450501');
INSERT INTO `kl_area` VALUES ('2446', '352', null, '海城区', '450502');
INSERT INTO `kl_area` VALUES ('2447', '352', null, '银海区', '450503');
INSERT INTO `kl_area` VALUES ('2448', '352', null, '铁山港区', '450512');
INSERT INTO `kl_area` VALUES ('2449', '352', null, '合浦县', '450521');
INSERT INTO `kl_area` VALUES ('2450', '340', null, '市辖区', '445101');
INSERT INTO `kl_area` VALUES ('2451', '320', null, '市辖区', '440901');
INSERT INTO `kl_area` VALUES ('2452', '340', null, '湘桥区', '445102');
INSERT INTO `kl_area` VALUES ('2453', '320', null, '茂南区', '440902');
INSERT INTO `kl_area` VALUES ('2454', '340', null, '潮安区', '445103');
INSERT INTO `kl_area` VALUES ('2455', '320', null, '茂港区', '440903');
INSERT INTO `kl_area` VALUES ('2456', '340', null, '饶平县', '445122');
INSERT INTO `kl_area` VALUES ('2457', '353', null, '市辖区', '450601');
INSERT INTO `kl_area` VALUES ('2458', '320', null, '电白县', '440923');
INSERT INTO `kl_area` VALUES ('2459', '353', null, '港口区', '450602');
INSERT INTO `kl_area` VALUES ('2460', '320', null, '高州市', '440981');
INSERT INTO `kl_area` VALUES ('2461', '353', null, '防城区', '450603');
INSERT INTO `kl_area` VALUES ('2462', '320', null, '化州市', '440982');
INSERT INTO `kl_area` VALUES ('2463', '353', null, '上思县', '450621');
INSERT INTO `kl_area` VALUES ('2464', '320', null, '信宜市', '440983');
INSERT INTO `kl_area` VALUES ('2465', '353', null, '东兴市', '450681');
INSERT INTO `kl_area` VALUES ('2466', '341', null, '市辖区', '445201');
INSERT INTO `kl_area` VALUES ('2467', '341', null, '榕城区', '445202');
INSERT INTO `kl_area` VALUES ('2468', '341', null, '揭东区', '445203');
INSERT INTO `kl_area` VALUES ('2469', '341', null, '揭西县', '445222');
INSERT INTO `kl_area` VALUES ('2470', '341', null, '惠来县', '445224');
INSERT INTO `kl_area` VALUES ('2471', '341', null, '普宁市', '445281');
INSERT INTO `kl_area` VALUES ('2472', '323', null, '市辖区', '441201');
INSERT INTO `kl_area` VALUES ('2473', '323', null, '端州区', '441202');
INSERT INTO `kl_area` VALUES ('2474', '355', null, '市辖区', '450701');
INSERT INTO `kl_area` VALUES ('2475', '323', null, '鼎湖区', '441203');
INSERT INTO `kl_area` VALUES ('2476', '355', null, '钦南区', '450702');
INSERT INTO `kl_area` VALUES ('2477', '323', null, '广宁县', '441223');
INSERT INTO `kl_area` VALUES ('2478', '355', null, '钦北区', '450703');
INSERT INTO `kl_area` VALUES ('2479', '323', null, '怀集县', '441224');
INSERT INTO `kl_area` VALUES ('2480', '355', null, '灵山县', '450721');
INSERT INTO `kl_area` VALUES ('2481', '323', null, '封开县', '441225');
INSERT INTO `kl_area` VALUES ('2482', '355', null, '浦北县', '450722');
INSERT INTO `kl_area` VALUES ('2483', '323', null, '德庆县', '441226');
INSERT INTO `kl_area` VALUES ('2484', '323', null, '高要市', '441283');
INSERT INTO `kl_area` VALUES ('2485', '323', null, '四会市', '441284');
INSERT INTO `kl_area` VALUES ('2486', '342', null, '市辖区', '445301');
INSERT INTO `kl_area` VALUES ('2487', '342', null, '云城区', '445302');
INSERT INTO `kl_area` VALUES ('2488', '342', null, '新兴县', '445321');
INSERT INTO `kl_area` VALUES ('2489', '342', null, '郁南县', '445322');
INSERT INTO `kl_area` VALUES ('2490', '342', null, '云安县', '445323');
INSERT INTO `kl_area` VALUES ('2491', '342', null, '罗定市', '445381');
INSERT INTO `kl_area` VALUES ('2492', '357', null, '市辖区', '450801');
INSERT INTO `kl_area` VALUES ('2493', '357', null, '港北区', '450802');
INSERT INTO `kl_area` VALUES ('2494', '326', null, '市辖区', '441301');
INSERT INTO `kl_area` VALUES ('2495', '357', null, '港南区', '450803');
INSERT INTO `kl_area` VALUES ('2496', '326', null, '惠城区', '441302');
INSERT INTO `kl_area` VALUES ('2497', '357', null, '覃塘区', '450804');
INSERT INTO `kl_area` VALUES ('2498', '326', null, '惠阳区', '441303');
INSERT INTO `kl_area` VALUES ('2499', '357', null, '平南县', '450821');
INSERT INTO `kl_area` VALUES ('2500', '326', null, '博罗县', '441322');
INSERT INTO `kl_area` VALUES ('2501', '357', null, '桂平市', '450881');
INSERT INTO `kl_area` VALUES ('2502', '326', null, '惠东县', '441323');
INSERT INTO `kl_area` VALUES ('2503', '326', null, '龙门县', '441324');
INSERT INTO `kl_area` VALUES ('2504', '363', null, '市辖区', '451101');
INSERT INTO `kl_area` VALUES ('2505', '363', null, '八步区', '451102');
INSERT INTO `kl_area` VALUES ('2506', '363', null, '昭平县', '451121');
INSERT INTO `kl_area` VALUES ('2507', '363', null, '钟山县', '451122');
INSERT INTO `kl_area` VALUES ('2508', '363', null, '富川瑶族自治县', '451123');
INSERT INTO `kl_area` VALUES ('2509', '359', null, '市辖区', '450901');
INSERT INTO `kl_area` VALUES ('2510', '359', null, '玉州区', '450902');
INSERT INTO `kl_area` VALUES ('2511', '359', null, '福绵区', '450903');
INSERT INTO `kl_area` VALUES ('2512', '359', null, '容县', '450921');
INSERT INTO `kl_area` VALUES ('2513', '359', null, '陆川县', '450922');
INSERT INTO `kl_area` VALUES ('2514', '359', null, '博白县', '450923');
INSERT INTO `kl_area` VALUES ('2515', '359', null, '兴业县', '450924');
INSERT INTO `kl_area` VALUES ('2516', '359', null, '北流市', '450981');
INSERT INTO `kl_area` VALUES ('2517', '82', null, '市辖区', '510101');
INSERT INTO `kl_area` VALUES ('2518', '82', null, '锦江区', '510104');
INSERT INTO `kl_area` VALUES ('2519', '82', null, '青羊区', '510105');
INSERT INTO `kl_area` VALUES ('2520', '82', null, '金牛区', '510106');
INSERT INTO `kl_area` VALUES ('2521', '82', null, '武侯区', '510107');
INSERT INTO `kl_area` VALUES ('2522', '365', null, '市辖区', '451201');
INSERT INTO `kl_area` VALUES ('2523', '82', null, '成华区', '510108');
INSERT INTO `kl_area` VALUES ('2524', '365', null, '金城江区', '451202');
INSERT INTO `kl_area` VALUES ('2525', '82', null, '龙泉驿区', '510112');
INSERT INTO `kl_area` VALUES ('2526', '365', null, '南丹县', '451221');
INSERT INTO `kl_area` VALUES ('2527', '82', null, '青白江区', '510113');
INSERT INTO `kl_area` VALUES ('2528', '365', null, '天峨县', '451222');
INSERT INTO `kl_area` VALUES ('2529', '82', null, '新都区', '510114');
INSERT INTO `kl_area` VALUES ('2530', '365', null, '凤山县', '451223');
INSERT INTO `kl_area` VALUES ('2531', '82', null, '温江区', '510115');
INSERT INTO `kl_area` VALUES ('2532', '365', null, '东兰县', '451224');
INSERT INTO `kl_area` VALUES ('2533', '82', null, '金堂县', '510121');
INSERT INTO `kl_area` VALUES ('2534', '361', null, '市辖区', '451001');
INSERT INTO `kl_area` VALUES ('2535', '365', null, '罗城仫佬族自治县', '451225');
INSERT INTO `kl_area` VALUES ('2536', '82', null, '双流县', '510122');
INSERT INTO `kl_area` VALUES ('2537', '361', null, '右江区', '451002');
INSERT INTO `kl_area` VALUES ('2538', '365', null, '环江毛南族自治县', '451226');
INSERT INTO `kl_area` VALUES ('2539', '82', null, '郫县', '510124');
INSERT INTO `kl_area` VALUES ('2540', '361', null, '田阳县', '451021');
INSERT INTO `kl_area` VALUES ('2541', '365', null, '巴马瑶族自治县', '451227');
INSERT INTO `kl_area` VALUES ('2542', '82', null, '大邑县', '510129');
INSERT INTO `kl_area` VALUES ('2543', '361', null, '田东县', '451022');
INSERT INTO `kl_area` VALUES ('2544', '365', null, '都安瑶族自治县', '451228');
INSERT INTO `kl_area` VALUES ('2545', '82', null, '蒲江县', '510131');
INSERT INTO `kl_area` VALUES ('2546', '361', null, '平果县', '451023');
INSERT INTO `kl_area` VALUES ('2547', '365', null, '大化瑶族自治县', '451229');
INSERT INTO `kl_area` VALUES ('2548', '361', null, '德保县', '451024');
INSERT INTO `kl_area` VALUES ('2549', '82', null, '新津县', '510132');
INSERT INTO `kl_area` VALUES ('2550', '365', null, '宜州市', '451281');
INSERT INTO `kl_area` VALUES ('2551', '82', null, '都江堰市', '510181');
INSERT INTO `kl_area` VALUES ('2552', '361', null, '靖西县', '451025');
INSERT INTO `kl_area` VALUES ('2553', '82', null, '彭州市', '510182');
INSERT INTO `kl_area` VALUES ('2554', '361', null, '那坡县', '451026');
INSERT INTO `kl_area` VALUES ('2555', '82', null, '邛崃市', '510183');
INSERT INTO `kl_area` VALUES ('2556', '361', null, '凌云县', '451027');
INSERT INTO `kl_area` VALUES ('2557', '82', null, '崇州市', '510184');
INSERT INTO `kl_area` VALUES ('2558', '361', null, '乐业县', '451028');
INSERT INTO `kl_area` VALUES ('2559', '361', null, '田林县', '451029');
INSERT INTO `kl_area` VALUES ('2560', '361', null, '西林县', '451030');
INSERT INTO `kl_area` VALUES ('2561', '361', null, '隆林各族自治县', '451031');
INSERT INTO `kl_area` VALUES ('2562', '367', null, '市辖区', '451301');
INSERT INTO `kl_area` VALUES ('2563', '367', null, '兴宾区', '451302');
INSERT INTO `kl_area` VALUES ('2564', '367', null, '忻城县', '451321');
INSERT INTO `kl_area` VALUES ('2565', '367', null, '象州县', '451322');
INSERT INTO `kl_area` VALUES ('2566', '367', null, '武宣县', '451323');
INSERT INTO `kl_area` VALUES ('2567', '85', null, '市辖区', '510301');
INSERT INTO `kl_area` VALUES ('2568', '367', null, '金秀瑶族自治县', '451324');
INSERT INTO `kl_area` VALUES ('2569', '85', null, '自流井区', '510302');
INSERT INTO `kl_area` VALUES ('2570', '367', null, '合山市', '451381');
INSERT INTO `kl_area` VALUES ('2571', '85', null, '贡井区', '510303');
INSERT INTO `kl_area` VALUES ('2572', '85', null, '大安区', '510304');
INSERT INTO `kl_area` VALUES ('2573', '85', null, '沿滩区', '510311');
INSERT INTO `kl_area` VALUES ('2574', '85', null, '荣县', '510321');
INSERT INTO `kl_area` VALUES ('2575', '85', null, '富顺县', '510322');
INSERT INTO `kl_area` VALUES ('2576', '369', null, '市辖区', '451401');
INSERT INTO `kl_area` VALUES ('2577', '369', null, '江州区', '451402');
INSERT INTO `kl_area` VALUES ('2578', '369', null, '扶绥县', '451421');
INSERT INTO `kl_area` VALUES ('2579', '369', null, '宁明县', '451422');
INSERT INTO `kl_area` VALUES ('2580', '369', null, '龙州县', '451423');
INSERT INTO `kl_area` VALUES ('2581', '87', null, '市辖区', '510401');
INSERT INTO `kl_area` VALUES ('2582', '369', null, '大新县', '451424');
INSERT INTO `kl_area` VALUES ('2583', '87', null, '东区', '510402');
INSERT INTO `kl_area` VALUES ('2584', '369', null, '天等县', '451425');
INSERT INTO `kl_area` VALUES ('2585', '87', null, '西区', '510403');
INSERT INTO `kl_area` VALUES ('2586', '369', null, '凭祥市', '451481');
INSERT INTO `kl_area` VALUES ('2587', '87', null, '仁和区', '510411');
INSERT INTO `kl_area` VALUES ('2588', '87', null, '米易县', '510421');
INSERT INTO `kl_area` VALUES ('2589', '87', null, '盐边县', '510422');
INSERT INTO `kl_area` VALUES ('2590', '47', null, '市辖区', '460101');
INSERT INTO `kl_area` VALUES ('2591', '47', null, '秀英区', '460105');
INSERT INTO `kl_area` VALUES ('2592', '47', null, '龙华区', '460106');
INSERT INTO `kl_area` VALUES ('2593', '47', null, '琼山区', '460107');
INSERT INTO `kl_area` VALUES ('2594', '47', null, '美兰区', '460108');
INSERT INTO `kl_area` VALUES ('2595', '90', null, '市辖区', '510501');
INSERT INTO `kl_area` VALUES ('2596', '90', null, '江阳区', '510502');
INSERT INTO `kl_area` VALUES ('2597', '90', null, '纳溪区', '510503');
INSERT INTO `kl_area` VALUES ('2598', '90', null, '龙马潭区', '510504');
INSERT INTO `kl_area` VALUES ('2599', '90', null, '泸县', '510521');
INSERT INTO `kl_area` VALUES ('2600', '90', null, '合江县', '510522');
INSERT INTO `kl_area` VALUES ('2601', '90', null, '叙永县', '510524');
INSERT INTO `kl_area` VALUES ('2602', '90', null, '古蔺县', '510525');
INSERT INTO `kl_area` VALUES ('2603', '48', null, '市辖区', '460201');
INSERT INTO `kl_area` VALUES ('2604', '93', null, '市辖区', '510601');
INSERT INTO `kl_area` VALUES ('2605', '93', null, '旌阳区', '510603');
INSERT INTO `kl_area` VALUES ('2606', '93', null, '中江县', '510623');
INSERT INTO `kl_area` VALUES ('2607', '93', null, '罗江县', '510626');
INSERT INTO `kl_area` VALUES ('2608', '93', null, '广汉市', '510681');
INSERT INTO `kl_area` VALUES ('2609', '93', null, '什邡市', '510682');
INSERT INTO `kl_area` VALUES ('2610', '93', null, '绵竹市', '510683');
INSERT INTO `kl_area` VALUES ('2611', '49', null, '西沙群岛', '460321');
INSERT INTO `kl_area` VALUES ('2612', '49', null, '南沙群岛', '460322');
INSERT INTO `kl_area` VALUES ('2613', '49', null, '中沙群岛的岛礁及其海域', '460323');
INSERT INTO `kl_area` VALUES ('2614', '96', null, '市辖区', '510701');
INSERT INTO `kl_area` VALUES ('2615', '96', null, '涪城区', '510703');
INSERT INTO `kl_area` VALUES ('2616', '96', null, '游仙区', '510704');
INSERT INTO `kl_area` VALUES ('2617', '50', null, '五指山市', '469001');
INSERT INTO `kl_area` VALUES ('2618', '96', null, '三台县', '510722');
INSERT INTO `kl_area` VALUES ('2619', '50', null, '琼海市', '469002');
INSERT INTO `kl_area` VALUES ('2620', '96', null, '盐亭县', '510723');
INSERT INTO `kl_area` VALUES ('2621', '50', null, '儋州市', '469003');
INSERT INTO `kl_area` VALUES ('2622', '96', null, '安县', '510724');
INSERT INTO `kl_area` VALUES ('2623', '50', null, '文昌市', '469005');
INSERT INTO `kl_area` VALUES ('2624', '96', null, '梓潼县', '510725');
INSERT INTO `kl_area` VALUES ('2625', '50', null, '万宁市', '469006');
INSERT INTO `kl_area` VALUES ('2626', '96', null, '北川羌族自治县', '510726');
INSERT INTO `kl_area` VALUES ('2627', '50', null, '东方市', '469007');
INSERT INTO `kl_area` VALUES ('2628', '96', null, '平武县', '510727');
INSERT INTO `kl_area` VALUES ('2629', '50', null, '定安县', '469021');
INSERT INTO `kl_area` VALUES ('2630', '96', null, '江油市', '510781');
INSERT INTO `kl_area` VALUES ('2631', '50', null, '屯昌县', '469022');
INSERT INTO `kl_area` VALUES ('2632', '50', null, '澄迈县', '469023');
INSERT INTO `kl_area` VALUES ('2633', '50', null, '临高县', '469024');
INSERT INTO `kl_area` VALUES ('2634', '50', null, '白沙黎族自治县', '469025');
INSERT INTO `kl_area` VALUES ('2635', '50', null, '昌江黎族自治县', '469026');
INSERT INTO `kl_area` VALUES ('2636', '50', null, '乐东黎族自治县', '469027');
INSERT INTO `kl_area` VALUES ('2637', '50', null, '陵水黎族自治县', '469028');
INSERT INTO `kl_area` VALUES ('2638', '50', null, '保亭黎族苗族自治县', '469029');
INSERT INTO `kl_area` VALUES ('2639', '50', null, '琼中黎族苗族自治县', '469030');
INSERT INTO `kl_area` VALUES ('2640', '99', null, '市辖区', '510801');
INSERT INTO `kl_area` VALUES ('2641', '99', null, '利州区', '510802');
INSERT INTO `kl_area` VALUES ('2642', '99', null, '元坝区', '510811');
INSERT INTO `kl_area` VALUES ('2643', '99', null, '朝天区', '510812');
INSERT INTO `kl_area` VALUES ('2644', '99', null, '旺苍县', '510821');
INSERT INTO `kl_area` VALUES ('2645', '99', null, '青川县', '510822');
INSERT INTO `kl_area` VALUES ('2646', '99', null, '剑阁县', '510823');
INSERT INTO `kl_area` VALUES ('2647', '99', null, '苍溪县', '510824');
INSERT INTO `kl_area` VALUES ('2648', '76', null, '万州区', '500101');
INSERT INTO `kl_area` VALUES ('2649', '76', null, '涪陵区', '500102');
INSERT INTO `kl_area` VALUES ('2650', '76', null, '渝中区', '500103');
INSERT INTO `kl_area` VALUES ('2651', '76', null, '大渡口区', '500104');
INSERT INTO `kl_area` VALUES ('2652', '76', null, '江北区', '500105');
INSERT INTO `kl_area` VALUES ('2653', '76', null, '沙坪坝区', '500106');
INSERT INTO `kl_area` VALUES ('2654', '76', null, '九龙坡区', '500107');
INSERT INTO `kl_area` VALUES ('2655', '76', null, '南岸区', '500108');
INSERT INTO `kl_area` VALUES ('2656', '76', null, '北碚区', '500109');
INSERT INTO `kl_area` VALUES ('2657', '76', null, '綦江区', '500110');
INSERT INTO `kl_area` VALUES ('2658', '76', null, '大足区', '500111');
INSERT INTO `kl_area` VALUES ('2659', '76', null, '渝北区', '500112');
INSERT INTO `kl_area` VALUES ('2660', '76', null, '巴南区', '500113');
INSERT INTO `kl_area` VALUES ('2661', '76', null, '黔江区', '500114');
INSERT INTO `kl_area` VALUES ('2662', '76', null, '长寿区', '500115');
INSERT INTO `kl_area` VALUES ('2663', '76', null, '江津区', '500116');
INSERT INTO `kl_area` VALUES ('2664', '76', null, '合川区', '500117');
INSERT INTO `kl_area` VALUES ('2665', '76', null, '永川区', '500118');
INSERT INTO `kl_area` VALUES ('2666', '76', null, '南川区', '500119');
INSERT INTO `kl_area` VALUES ('2667', '103', null, '市辖区', '510901');
INSERT INTO `kl_area` VALUES ('2668', '103', null, '船山区', '510903');
INSERT INTO `kl_area` VALUES ('2669', '103', null, '安居区', '510904');
INSERT INTO `kl_area` VALUES ('2670', '103', null, '蓬溪县', '510921');
INSERT INTO `kl_area` VALUES ('2671', '103', null, '射洪县', '510922');
INSERT INTO `kl_area` VALUES ('2672', '103', null, '大英县', '510923');
INSERT INTO `kl_area` VALUES ('2673', '78', null, '潼南县', '500223');
INSERT INTO `kl_area` VALUES ('2674', '78', null, '铜梁县', '500224');
INSERT INTO `kl_area` VALUES ('2675', '78', null, '荣昌县', '500226');
INSERT INTO `kl_area` VALUES ('2676', '78', null, '璧山县', '500227');
INSERT INTO `kl_area` VALUES ('2677', '78', null, '梁平县', '500228');
INSERT INTO `kl_area` VALUES ('2678', '78', null, '城口县', '500229');
INSERT INTO `kl_area` VALUES ('2679', '104', null, '市辖区', '511001');
INSERT INTO `kl_area` VALUES ('2680', '78', null, '丰都县', '500230');
INSERT INTO `kl_area` VALUES ('2681', '104', null, '市中区', '511002');
INSERT INTO `kl_area` VALUES ('2682', '78', null, '垫江县', '500231');
INSERT INTO `kl_area` VALUES ('2683', '104', null, '东兴区', '511011');
INSERT INTO `kl_area` VALUES ('2684', '78', null, '武隆县', '500232');
INSERT INTO `kl_area` VALUES ('2685', '78', null, '忠县', '500233');
INSERT INTO `kl_area` VALUES ('2686', '104', null, '威远县', '511024');
INSERT INTO `kl_area` VALUES ('2687', '78', null, '开县', '500234');
INSERT INTO `kl_area` VALUES ('2688', '104', null, '资中县', '511025');
INSERT INTO `kl_area` VALUES ('2689', '78', null, '云阳县', '500235');
INSERT INTO `kl_area` VALUES ('2690', '104', null, '隆昌县', '511028');
INSERT INTO `kl_area` VALUES ('2691', '78', null, '奉节县', '500236');
INSERT INTO `kl_area` VALUES ('2692', '78', null, '巫山县', '500237');
INSERT INTO `kl_area` VALUES ('2693', '78', null, '巫溪县', '500238');
INSERT INTO `kl_area` VALUES ('2694', '78', null, '石柱土家族自治县', '500240');
INSERT INTO `kl_area` VALUES ('2695', '78', null, '秀山土家族苗族自治县', '500241');
INSERT INTO `kl_area` VALUES ('2696', '78', null, '酉阳土家族苗族自治县', '500242');
INSERT INTO `kl_area` VALUES ('2697', '78', null, '彭水苗族土家族自治县', '500243');
INSERT INTO `kl_area` VALUES ('2698', '106', null, '市辖区', '511101');
INSERT INTO `kl_area` VALUES ('2699', '106', null, '市中区', '511102');
INSERT INTO `kl_area` VALUES ('2700', '106', null, '沙湾区', '511111');
INSERT INTO `kl_area` VALUES ('2701', '106', null, '五通桥区', '511112');
INSERT INTO `kl_area` VALUES ('2702', '106', null, '金口河区', '511113');
INSERT INTO `kl_area` VALUES ('2703', '106', null, '犍为县', '511123');
INSERT INTO `kl_area` VALUES ('2704', '106', null, '井研县', '511124');
INSERT INTO `kl_area` VALUES ('2705', '106', null, '夹江县', '511126');
INSERT INTO `kl_area` VALUES ('2706', '106', null, '沐川县', '511129');
INSERT INTO `kl_area` VALUES ('2707', '106', null, '峨边彝族自治县', '511132');
INSERT INTO `kl_area` VALUES ('2708', '106', null, '马边彝族自治县', '511133');
INSERT INTO `kl_area` VALUES ('2709', '106', null, '峨眉山市', '511181');
INSERT INTO `kl_area` VALUES ('2710', '108', null, '市辖区', '511301');
INSERT INTO `kl_area` VALUES ('2711', '108', null, '顺庆区', '511302');
INSERT INTO `kl_area` VALUES ('2712', '108', null, '高坪区', '511303');
INSERT INTO `kl_area` VALUES ('2713', '108', null, '嘉陵区', '511304');
INSERT INTO `kl_area` VALUES ('2714', '108', null, '南部县', '511321');
INSERT INTO `kl_area` VALUES ('2715', '108', null, '营山县', '511322');
INSERT INTO `kl_area` VALUES ('2716', '108', null, '蓬安县', '511323');
INSERT INTO `kl_area` VALUES ('2717', '108', null, '仪陇县', '511324');
INSERT INTO `kl_area` VALUES ('2718', '108', null, '西充县', '511325');
INSERT INTO `kl_area` VALUES ('2719', '108', null, '阆中市', '511381');
INSERT INTO `kl_area` VALUES ('2720', '120', null, '西昌市', '513401');
INSERT INTO `kl_area` VALUES ('2721', '120', null, '木里藏族自治县', '513422');
INSERT INTO `kl_area` VALUES ('2722', '120', null, '盐源县', '513423');
INSERT INTO `kl_area` VALUES ('2723', '120', null, '德昌县', '513424');
INSERT INTO `kl_area` VALUES ('2724', '120', null, '会理县', '513425');
INSERT INTO `kl_area` VALUES ('2725', '120', null, '会东县', '513426');
INSERT INTO `kl_area` VALUES ('2726', '120', null, '宁南县', '513427');
INSERT INTO `kl_area` VALUES ('2727', '120', null, '普格县', '513428');
INSERT INTO `kl_area` VALUES ('2728', '120', null, '布拖县', '513429');
INSERT INTO `kl_area` VALUES ('2729', '120', null, '金阳县', '513430');
INSERT INTO `kl_area` VALUES ('2730', '110', null, '市辖区', '511401');
INSERT INTO `kl_area` VALUES ('2731', '120', null, '昭觉县', '513431');
INSERT INTO `kl_area` VALUES ('2732', '110', null, '东坡区', '511402');
INSERT INTO `kl_area` VALUES ('2733', '120', null, '喜德县', '513432');
INSERT INTO `kl_area` VALUES ('2734', '110', null, '仁寿县', '511421');
INSERT INTO `kl_area` VALUES ('2735', '120', null, '冕宁县', '513433');
INSERT INTO `kl_area` VALUES ('2736', '110', null, '彭山县', '511422');
INSERT INTO `kl_area` VALUES ('2737', '120', null, '越西县', '513434');
INSERT INTO `kl_area` VALUES ('2738', '110', null, '洪雅县', '511423');
INSERT INTO `kl_area` VALUES ('2739', '120', null, '甘洛县', '513435');
INSERT INTO `kl_area` VALUES ('2740', '110', null, '丹棱县', '511424');
INSERT INTO `kl_area` VALUES ('2741', '120', null, '美姑县', '513436');
INSERT INTO `kl_area` VALUES ('2742', '110', null, '青神县', '511425');
INSERT INTO `kl_area` VALUES ('2743', '120', null, '雷波县', '513437');
INSERT INTO `kl_area` VALUES ('2744', '171', null, '市辖区', '530101');
INSERT INTO `kl_area` VALUES ('2745', '171', null, '五华区', '530102');
INSERT INTO `kl_area` VALUES ('2746', '171', null, '盘龙区', '530103');
INSERT INTO `kl_area` VALUES ('2747', '171', null, '官渡区', '530111');
INSERT INTO `kl_area` VALUES ('2748', '171', null, '西山区', '530112');
INSERT INTO `kl_area` VALUES ('2749', '171', null, '东川区', '530113');
INSERT INTO `kl_area` VALUES ('2750', '171', null, '呈贡区', '530114');
INSERT INTO `kl_area` VALUES ('2751', '171', null, '晋宁县', '530122');
INSERT INTO `kl_area` VALUES ('2752', '171', null, '富民县', '530124');
INSERT INTO `kl_area` VALUES ('2753', '171', null, '宜良县', '530125');
INSERT INTO `kl_area` VALUES ('2754', '171', null, '石林彝族自治县', '530126');
INSERT INTO `kl_area` VALUES ('2755', '171', null, '嵩明县', '530127');
INSERT INTO `kl_area` VALUES ('2756', '171', null, '禄劝彝族苗族自治县', '530128');
INSERT INTO `kl_area` VALUES ('2757', '171', null, '寻甸回族彝族自治县', '530129');
INSERT INTO `kl_area` VALUES ('2758', '171', null, '安宁市', '530181');
INSERT INTO `kl_area` VALUES ('2759', '112', null, '市辖区', '511501');
INSERT INTO `kl_area` VALUES ('2760', '139', null, '市辖区', '520101');
INSERT INTO `kl_area` VALUES ('2761', '112', null, '翠屏区', '511502');
INSERT INTO `kl_area` VALUES ('2762', '139', null, '南明区', '520102');
INSERT INTO `kl_area` VALUES ('2763', '112', null, '南溪区', '511503');
INSERT INTO `kl_area` VALUES ('2764', '139', null, '云岩区', '520103');
INSERT INTO `kl_area` VALUES ('2765', '112', null, '宜宾县', '511521');
INSERT INTO `kl_area` VALUES ('2766', '139', null, '花溪区', '520111');
INSERT INTO `kl_area` VALUES ('2767', '112', null, '江安县', '511523');
INSERT INTO `kl_area` VALUES ('2768', '139', null, '乌当区', '520112');
INSERT INTO `kl_area` VALUES ('2769', '112', null, '长宁县', '511524');
INSERT INTO `kl_area` VALUES ('2770', '112', null, '高县', '511525');
INSERT INTO `kl_area` VALUES ('2771', '139', null, '白云区', '520113');
INSERT INTO `kl_area` VALUES ('2772', '112', null, '珙县', '511526');
INSERT INTO `kl_area` VALUES ('2773', '174', null, '市辖区', '530301');
INSERT INTO `kl_area` VALUES ('2774', '139', null, '观山湖区', '520115');
INSERT INTO `kl_area` VALUES ('2775', '112', null, '筠连县', '511527');
INSERT INTO `kl_area` VALUES ('2776', '174', null, '麒麟区', '530302');
INSERT INTO `kl_area` VALUES ('2777', '139', null, '开阳县', '520121');
INSERT INTO `kl_area` VALUES ('2778', '174', null, '马龙县', '530321');
INSERT INTO `kl_area` VALUES ('2779', '112', null, '兴文县', '511528');
INSERT INTO `kl_area` VALUES ('2780', '139', null, '息烽县', '520122');
INSERT INTO `kl_area` VALUES ('2781', '174', null, '陆良县', '530322');
INSERT INTO `kl_area` VALUES ('2782', '112', null, '屏山县', '511529');
INSERT INTO `kl_area` VALUES ('2783', '139', null, '修文县', '520123');
INSERT INTO `kl_area` VALUES ('2784', '174', null, '师宗县', '530323');
INSERT INTO `kl_area` VALUES ('2785', '139', null, '清镇市', '520181');
INSERT INTO `kl_area` VALUES ('2786', '174', null, '罗平县', '530324');
INSERT INTO `kl_area` VALUES ('2787', '174', null, '富源县', '530325');
INSERT INTO `kl_area` VALUES ('2788', '174', null, '会泽县', '530326');
INSERT INTO `kl_area` VALUES ('2789', '174', null, '沾益县', '530328');
INSERT INTO `kl_area` VALUES ('2790', '174', null, '宣威市', '530381');
INSERT INTO `kl_area` VALUES ('2791', '113', null, '市辖区', '511601');
INSERT INTO `kl_area` VALUES ('2792', '113', null, '广安区', '511602');
INSERT INTO `kl_area` VALUES ('2793', '113', null, '前锋区', '511603');
INSERT INTO `kl_area` VALUES ('2794', '141', null, '钟山区', '520201');
INSERT INTO `kl_area` VALUES ('2795', '113', null, '岳池县', '511621');
INSERT INTO `kl_area` VALUES ('2796', '141', null, '六枝特区', '520203');
INSERT INTO `kl_area` VALUES ('2797', '113', null, '武胜县', '511622');
INSERT INTO `kl_area` VALUES ('2798', '141', null, '水城县', '520221');
INSERT INTO `kl_area` VALUES ('2799', '113', null, '邻水县', '511623');
INSERT INTO `kl_area` VALUES ('2800', '176', null, '市辖区', '530401');
INSERT INTO `kl_area` VALUES ('2801', '141', null, '盘县', '520222');
INSERT INTO `kl_area` VALUES ('2802', '113', null, '华蓥市', '511681');
INSERT INTO `kl_area` VALUES ('2803', '176', null, '红塔区', '530402');
INSERT INTO `kl_area` VALUES ('2804', '176', null, '江川县', '530421');
INSERT INTO `kl_area` VALUES ('2805', '176', null, '澄江县', '530422');
INSERT INTO `kl_area` VALUES ('2806', '176', null, '通海县', '530423');
INSERT INTO `kl_area` VALUES ('2807', '176', null, '华宁县', '530424');
INSERT INTO `kl_area` VALUES ('2808', '176', null, '易门县', '530425');
INSERT INTO `kl_area` VALUES ('2809', '176', null, '峨山彝族自治县', '530426');
INSERT INTO `kl_area` VALUES ('2810', '176', null, '新平彝族傣族自治县', '530427');
INSERT INTO `kl_area` VALUES ('2811', '176', null, '元江哈尼族彝族傣族自治县', '530428');
INSERT INTO `kl_area` VALUES ('2812', '143', null, '市辖区', '520301');
INSERT INTO `kl_area` VALUES ('2813', '114', null, '市辖区', '511701');
INSERT INTO `kl_area` VALUES ('2814', '143', null, '红花岗区', '520302');
INSERT INTO `kl_area` VALUES ('2815', '114', null, '通川区', '511702');
INSERT INTO `kl_area` VALUES ('2816', '143', null, '汇川区', '520303');
INSERT INTO `kl_area` VALUES ('2817', '178', null, '市辖区', '530501');
INSERT INTO `kl_area` VALUES ('2818', '114', null, '达川区', '511703');
INSERT INTO `kl_area` VALUES ('2819', '143', null, '遵义县', '520321');
INSERT INTO `kl_area` VALUES ('2820', '178', null, '隆阳区', '530502');
INSERT INTO `kl_area` VALUES ('2821', '114', null, '宣汉县', '511722');
INSERT INTO `kl_area` VALUES ('2822', '178', null, '施甸县', '530521');
INSERT INTO `kl_area` VALUES ('2823', '143', null, '桐梓县', '520322');
INSERT INTO `kl_area` VALUES ('2824', '114', null, '开江县', '511723');
INSERT INTO `kl_area` VALUES ('2825', '178', null, '腾冲县', '530522');
INSERT INTO `kl_area` VALUES ('2826', '143', null, '绥阳县', '520323');
INSERT INTO `kl_area` VALUES ('2827', '114', null, '大竹县', '511724');
INSERT INTO `kl_area` VALUES ('2828', '178', null, '龙陵县', '530523');
INSERT INTO `kl_area` VALUES ('2829', '143', null, '正安县', '520324');
INSERT INTO `kl_area` VALUES ('2830', '178', null, '昌宁县', '530524');
INSERT INTO `kl_area` VALUES ('2831', '114', null, '渠县', '511725');
INSERT INTO `kl_area` VALUES ('2832', '143', null, '道真仡佬族苗族自治县', '520325');
INSERT INTO `kl_area` VALUES ('2833', '114', null, '万源市', '511781');
INSERT INTO `kl_area` VALUES ('2834', '143', null, '务川仡佬族苗族自治县', '520326');
INSERT INTO `kl_area` VALUES ('2835', '143', null, '凤冈县', '520327');
INSERT INTO `kl_area` VALUES ('2836', '143', null, '湄潭县', '520328');
INSERT INTO `kl_area` VALUES ('2837', '143', null, '余庆县', '520329');
INSERT INTO `kl_area` VALUES ('2838', '143', null, '习水县', '520330');
INSERT INTO `kl_area` VALUES ('2839', '143', null, '赤水市', '520381');
INSERT INTO `kl_area` VALUES ('2840', '143', null, '仁怀市', '520382');
INSERT INTO `kl_area` VALUES ('2841', '180', null, '市辖区', '530601');
INSERT INTO `kl_area` VALUES ('2842', '115', null, '市辖区', '511801');
INSERT INTO `kl_area` VALUES ('2843', '180', null, '昭阳区', '530602');
INSERT INTO `kl_area` VALUES ('2844', '115', null, '雨城区', '511802');
INSERT INTO `kl_area` VALUES ('2845', '180', null, '鲁甸县', '530621');
INSERT INTO `kl_area` VALUES ('2846', '115', null, '名山区', '511803');
INSERT INTO `kl_area` VALUES ('2847', '180', null, '巧家县', '530622');
INSERT INTO `kl_area` VALUES ('2848', '115', null, '荥经县', '511822');
INSERT INTO `kl_area` VALUES ('2849', '180', null, '盐津县', '530623');
INSERT INTO `kl_area` VALUES ('2850', '115', null, '汉源县', '511823');
INSERT INTO `kl_area` VALUES ('2851', '180', null, '大关县', '530624');
INSERT INTO `kl_area` VALUES ('2852', '115', null, '石棉县', '511824');
INSERT INTO `kl_area` VALUES ('2853', '145', null, '市辖区', '520401');
INSERT INTO `kl_area` VALUES ('2854', '180', null, '永善县', '530625');
INSERT INTO `kl_area` VALUES ('2855', '145', null, '西秀区', '520402');
INSERT INTO `kl_area` VALUES ('2856', '115', null, '天全县', '511825');
INSERT INTO `kl_area` VALUES ('2857', '180', null, '绥江县', '530626');
INSERT INTO `kl_area` VALUES ('2858', '145', null, '平坝县', '520421');
INSERT INTO `kl_area` VALUES ('2859', '115', null, '芦山县', '511826');
INSERT INTO `kl_area` VALUES ('2860', '180', null, '镇雄县', '530627');
INSERT INTO `kl_area` VALUES ('2861', '115', null, '宝兴县', '511827');
INSERT INTO `kl_area` VALUES ('2862', '145', null, '普定县', '520422');
INSERT INTO `kl_area` VALUES ('2863', '180', null, '彝良县', '530628');
INSERT INTO `kl_area` VALUES ('2864', '145', null, '镇宁布依族苗族自治县', '520423');
INSERT INTO `kl_area` VALUES ('2865', '180', null, '威信县', '530629');
INSERT INTO `kl_area` VALUES ('2866', '145', null, '关岭布依族苗族自治县', '520424');
INSERT INTO `kl_area` VALUES ('2867', '180', null, '水富县', '530630');
INSERT INTO `kl_area` VALUES ('2868', '145', null, '紫云苗族布依族自治县', '520425');
INSERT INTO `kl_area` VALUES ('2869', '116', null, '市辖区', '511901');
INSERT INTO `kl_area` VALUES ('2870', '116', null, '巴州区', '511902');
INSERT INTO `kl_area` VALUES ('2871', '116', null, '恩阳区', '511903');
INSERT INTO `kl_area` VALUES ('2872', '116', null, '通江县', '511921');
INSERT INTO `kl_area` VALUES ('2873', '116', null, '南江县', '511922');
INSERT INTO `kl_area` VALUES ('2874', '182', null, '市辖区', '530701');
INSERT INTO `kl_area` VALUES ('2875', '116', null, '平昌县', '511923');
INSERT INTO `kl_area` VALUES ('2876', '182', null, '古城区', '530702');
INSERT INTO `kl_area` VALUES ('2877', '147', null, '市辖区', '520501');
INSERT INTO `kl_area` VALUES ('2878', '182', null, '玉龙纳西族自治县', '530721');
INSERT INTO `kl_area` VALUES ('2879', '147', null, '七星关区', '520502');
INSERT INTO `kl_area` VALUES ('2880', '182', null, '永胜县', '530722');
INSERT INTO `kl_area` VALUES ('2881', '147', null, '大方县', '520521');
INSERT INTO `kl_area` VALUES ('2882', '182', null, '华坪县', '530723');
INSERT INTO `kl_area` VALUES ('2883', '147', null, '黔西县', '520522');
INSERT INTO `kl_area` VALUES ('2884', '182', null, '宁蒗彝族自治县', '530724');
INSERT INTO `kl_area` VALUES ('2885', '147', null, '金沙县', '520523');
INSERT INTO `kl_area` VALUES ('2886', '147', null, '织金县', '520524');
INSERT INTO `kl_area` VALUES ('2887', '147', null, '纳雍县', '520525');
INSERT INTO `kl_area` VALUES ('2888', '147', null, '威宁彝族回族苗族自治县', '520526');
INSERT INTO `kl_area` VALUES ('2889', '147', null, '赫章县', '520527');
INSERT INTO `kl_area` VALUES ('2890', '117', null, '市辖区', '512001');
INSERT INTO `kl_area` VALUES ('2891', '117', null, '雁江区', '512002');
INSERT INTO `kl_area` VALUES ('2892', '117', null, '安岳县', '512021');
INSERT INTO `kl_area` VALUES ('2893', '117', null, '乐至县', '512022');
INSERT INTO `kl_area` VALUES ('2894', '117', null, '简阳市', '512081');
INSERT INTO `kl_area` VALUES ('2895', '184', null, '市辖区', '530801');
INSERT INTO `kl_area` VALUES ('2896', '184', null, '思茅区', '530802');
INSERT INTO `kl_area` VALUES ('2897', '184', null, '宁洱哈尼族彝族自治县', '530821');
INSERT INTO `kl_area` VALUES ('2898', '184', null, '墨江哈尼族自治县', '530822');
INSERT INTO `kl_area` VALUES ('2899', '184', null, '景东彝族自治县', '530823');
INSERT INTO `kl_area` VALUES ('2900', '184', null, '景谷傣族彝族自治县', '530824');
INSERT INTO `kl_area` VALUES ('2901', '149', null, '市辖区', '520601');
INSERT INTO `kl_area` VALUES ('2902', '184', null, '镇沅彝族哈尼族拉祜族自治县', '530825');
INSERT INTO `kl_area` VALUES ('2903', '149', null, '碧江区', '520602');
INSERT INTO `kl_area` VALUES ('2904', '184', null, '江城哈尼族彝族自治县', '530826');
INSERT INTO `kl_area` VALUES ('2905', '149', null, '万山区', '520603');
INSERT INTO `kl_area` VALUES ('2906', '184', null, '孟连傣族拉祜族佤族自治县', '530827');
INSERT INTO `kl_area` VALUES ('2907', '149', null, '江口县', '520621');
INSERT INTO `kl_area` VALUES ('2908', '184', null, '澜沧拉祜族自治县', '530828');
INSERT INTO `kl_area` VALUES ('2909', '149', null, '玉屏侗族自治县', '520622');
INSERT INTO `kl_area` VALUES ('2910', '184', null, '西盟佤族自治县', '530829');
INSERT INTO `kl_area` VALUES ('2911', '149', null, '石阡县', '520623');
INSERT INTO `kl_area` VALUES ('2912', '149', null, '思南县', '520624');
INSERT INTO `kl_area` VALUES ('2913', '118', null, '汶川县', '513221');
INSERT INTO `kl_area` VALUES ('2914', '149', null, '印江土家族苗族自治县', '520625');
INSERT INTO `kl_area` VALUES ('2915', '118', null, '理县', '513222');
INSERT INTO `kl_area` VALUES ('2916', '149', null, '德江县', '520626');
INSERT INTO `kl_area` VALUES ('2917', '118', null, '茂县', '513223');
INSERT INTO `kl_area` VALUES ('2918', '149', null, '沿河土家族自治县', '520627');
INSERT INTO `kl_area` VALUES ('2919', '118', null, '松潘县', '513224');
INSERT INTO `kl_area` VALUES ('2920', '149', null, '松桃苗族自治县', '520628');
INSERT INTO `kl_area` VALUES ('2921', '118', null, '九寨沟县', '513225');
INSERT INTO `kl_area` VALUES ('2922', '118', null, '金川县', '513226');
INSERT INTO `kl_area` VALUES ('2923', '118', null, '小金县', '513227');
INSERT INTO `kl_area` VALUES ('2924', '118', null, '黑水县', '513228');
INSERT INTO `kl_area` VALUES ('2925', '118', null, '马尔康县', '513229');
INSERT INTO `kl_area` VALUES ('2926', '118', null, '壤塘县', '513230');
INSERT INTO `kl_area` VALUES ('2927', '118', null, '阿坝县', '513231');
INSERT INTO `kl_area` VALUES ('2928', '118', null, '若尔盖县', '513232');
INSERT INTO `kl_area` VALUES ('2929', '118', null, '红原县', '513233');
INSERT INTO `kl_area` VALUES ('2930', '186', null, '市辖区', '530901');
INSERT INTO `kl_area` VALUES ('2931', '186', null, '临翔区', '530902');
INSERT INTO `kl_area` VALUES ('2932', '186', null, '凤庆县', '530921');
INSERT INTO `kl_area` VALUES ('2933', '186', null, '云县', '530922');
INSERT INTO `kl_area` VALUES ('2934', '186', null, '永德县', '530923');
INSERT INTO `kl_area` VALUES ('2935', '186', null, '镇康县', '530924');
INSERT INTO `kl_area` VALUES ('2936', '186', null, '双江拉祜族佤族布朗族傣族自治县', '530925');
INSERT INTO `kl_area` VALUES ('2937', '186', null, '耿马傣族佤族自治县', '530926');
INSERT INTO `kl_area` VALUES ('2938', '186', null, '沧源佤族自治县', '530927');
INSERT INTO `kl_area` VALUES ('2939', '150', null, '兴义市', '522301');
INSERT INTO `kl_area` VALUES ('2940', '150', null, '兴仁县', '522322');
INSERT INTO `kl_area` VALUES ('2941', '150', null, '普安县', '522323');
INSERT INTO `kl_area` VALUES ('2942', '150', null, '晴隆县', '522324');
INSERT INTO `kl_area` VALUES ('2943', '150', null, '贞丰县', '522325');
INSERT INTO `kl_area` VALUES ('2944', '150', null, '望谟县', '522326');
INSERT INTO `kl_area` VALUES ('2945', '150', null, '册亨县', '522327');
INSERT INTO `kl_area` VALUES ('2946', '119', null, '康定县', '513321');
INSERT INTO `kl_area` VALUES ('2947', '150', null, '安龙县', '522328');
INSERT INTO `kl_area` VALUES ('2948', '119', null, '泸定县', '513322');
INSERT INTO `kl_area` VALUES ('2949', '119', null, '丹巴县', '513323');
INSERT INTO `kl_area` VALUES ('2950', '119', null, '九龙县', '513324');
INSERT INTO `kl_area` VALUES ('2951', '119', null, '雅江县', '513325');
INSERT INTO `kl_area` VALUES ('2952', '119', null, '道孚县', '513326');
INSERT INTO `kl_area` VALUES ('2953', '119', null, '炉霍县', '513327');
INSERT INTO `kl_area` VALUES ('2954', '119', null, '甘孜县', '513328');
INSERT INTO `kl_area` VALUES ('2955', '119', null, '新龙县', '513329');
INSERT INTO `kl_area` VALUES ('2956', '119', null, '德格县', '513330');
INSERT INTO `kl_area` VALUES ('2957', '119', null, '白玉县', '513331');
INSERT INTO `kl_area` VALUES ('2958', '188', null, '楚雄市', '532301');
INSERT INTO `kl_area` VALUES ('2959', '119', null, '石渠县', '513332');
INSERT INTO `kl_area` VALUES ('2960', '188', null, '双柏县', '532322');
INSERT INTO `kl_area` VALUES ('2961', '119', null, '色达县', '513333');
INSERT INTO `kl_area` VALUES ('2962', '188', null, '牟定县', '532323');
INSERT INTO `kl_area` VALUES ('2963', '119', null, '理塘县', '513334');
INSERT INTO `kl_area` VALUES ('2964', '188', null, '南华县', '532324');
INSERT INTO `kl_area` VALUES ('2965', '119', null, '巴塘县', '513335');
INSERT INTO `kl_area` VALUES ('2966', '188', null, '姚安县', '532325');
INSERT INTO `kl_area` VALUES ('2967', '119', null, '乡城县', '513336');
INSERT INTO `kl_area` VALUES ('2968', '188', null, '大姚县', '532326');
INSERT INTO `kl_area` VALUES ('2969', '119', null, '稻城县', '513337');
INSERT INTO `kl_area` VALUES ('2970', '188', null, '永仁县', '532327');
INSERT INTO `kl_area` VALUES ('2971', '119', null, '得荣县', '513338');
INSERT INTO `kl_area` VALUES ('2972', '151', null, '凯里市', '522601');
INSERT INTO `kl_area` VALUES ('2973', '188', null, '元谋县', '532328');
INSERT INTO `kl_area` VALUES ('2974', '151', null, '黄平县', '522622');
INSERT INTO `kl_area` VALUES ('2975', '188', null, '武定县', '532329');
INSERT INTO `kl_area` VALUES ('2976', '151', null, '施秉县', '522623');
INSERT INTO `kl_area` VALUES ('2977', '188', null, '禄丰县', '532331');
INSERT INTO `kl_area` VALUES ('2978', '151', null, '三穗县', '522624');
INSERT INTO `kl_area` VALUES ('2979', '151', null, '镇远县', '522625');
INSERT INTO `kl_area` VALUES ('2980', '151', null, '岑巩县', '522626');
INSERT INTO `kl_area` VALUES ('2981', '151', null, '天柱县', '522627');
INSERT INTO `kl_area` VALUES ('2982', '151', null, '锦屏县', '522628');
INSERT INTO `kl_area` VALUES ('2983', '151', null, '剑河县', '522629');
INSERT INTO `kl_area` VALUES ('2984', '151', null, '台江县', '522630');
INSERT INTO `kl_area` VALUES ('2985', '151', null, '黎平县', '522631');
INSERT INTO `kl_area` VALUES ('2986', '151', null, '榕江县', '522632');
INSERT INTO `kl_area` VALUES ('2987', '151', null, '从江县', '522633');
INSERT INTO `kl_area` VALUES ('2988', '151', null, '雷山县', '522634');
INSERT INTO `kl_area` VALUES ('2989', '151', null, '麻江县', '522635');
INSERT INTO `kl_area` VALUES ('2990', '151', null, '丹寨县', '522636');
INSERT INTO `kl_area` VALUES ('2991', '190', null, '个旧市', '532501');
INSERT INTO `kl_area` VALUES ('2992', '190', null, '开远市', '532502');
INSERT INTO `kl_area` VALUES ('2993', '190', null, '蒙自市', '532503');
INSERT INTO `kl_area` VALUES ('2994', '190', null, '弥勒市', '532504');
INSERT INTO `kl_area` VALUES ('2995', '190', null, '屏边苗族自治县', '532523');
INSERT INTO `kl_area` VALUES ('2996', '192', null, '文山市', '532601');
INSERT INTO `kl_area` VALUES ('2997', '190', null, '建水县', '532524');
INSERT INTO `kl_area` VALUES ('2998', '192', null, '砚山县', '532622');
INSERT INTO `kl_area` VALUES ('2999', '190', null, '石屏县', '532525');
INSERT INTO `kl_area` VALUES ('3000', '192', null, '西畴县', '532623');
INSERT INTO `kl_area` VALUES ('3001', '190', null, '泸西县', '532527');
INSERT INTO `kl_area` VALUES ('3002', '192', null, '麻栗坡县', '532624');
INSERT INTO `kl_area` VALUES ('3003', '190', null, '元阳县', '532528');
INSERT INTO `kl_area` VALUES ('3004', '192', null, '马关县', '532625');
INSERT INTO `kl_area` VALUES ('3005', '152', null, '都匀市', '522701');
INSERT INTO `kl_area` VALUES ('3006', '190', null, '红河县', '532529');
INSERT INTO `kl_area` VALUES ('3007', '192', null, '丘北县', '532626');
INSERT INTO `kl_area` VALUES ('3008', '152', null, '福泉市', '522702');
INSERT INTO `kl_area` VALUES ('3009', '190', null, '金平苗族瑶族傣族自治县', '532530');
INSERT INTO `kl_area` VALUES ('3010', '192', null, '广南县', '532627');
INSERT INTO `kl_area` VALUES ('3011', '152', null, '荔波县', '522722');
INSERT INTO `kl_area` VALUES ('3012', '190', null, '绿春县', '532531');
INSERT INTO `kl_area` VALUES ('3013', '192', null, '富宁县', '532628');
INSERT INTO `kl_area` VALUES ('3014', '152', null, '贵定县', '522723');
INSERT INTO `kl_area` VALUES ('3015', '190', null, '河口瑶族自治县', '532532');
INSERT INTO `kl_area` VALUES ('3016', '152', null, '瓮安县', '522725');
INSERT INTO `kl_area` VALUES ('3017', '152', null, '独山县', '522726');
INSERT INTO `kl_area` VALUES ('3018', '152', null, '平塘县', '522727');
INSERT INTO `kl_area` VALUES ('3019', '152', null, '罗甸县', '522728');
INSERT INTO `kl_area` VALUES ('3020', '152', null, '长顺县', '522729');
INSERT INTO `kl_area` VALUES ('3021', '152', null, '龙里县', '522730');
INSERT INTO `kl_area` VALUES ('3022', '152', null, '惠水县', '522731');
INSERT INTO `kl_area` VALUES ('3023', '152', null, '三都水族自治县', '522732');
INSERT INTO `kl_area` VALUES ('3024', '194', null, '景洪市', '532801');
INSERT INTO `kl_area` VALUES ('3025', '194', null, '勐海县', '532822');
INSERT INTO `kl_area` VALUES ('3026', '194', null, '勐腊县', '532823');
INSERT INTO `kl_area` VALUES ('3027', '231', null, '那曲县', '542421');
INSERT INTO `kl_area` VALUES ('3028', '231', null, '嘉黎县', '542422');
INSERT INTO `kl_area` VALUES ('3029', '231', null, '比如县', '542423');
INSERT INTO `kl_area` VALUES ('3030', '196', null, '大理市', '532901');
INSERT INTO `kl_area` VALUES ('3031', '231', null, '聂荣县', '542424');
INSERT INTO `kl_area` VALUES ('3032', '196', null, '漾濞彝族自治县', '532922');
INSERT INTO `kl_area` VALUES ('3033', '231', null, '安多县', '542425');
INSERT INTO `kl_area` VALUES ('3034', '196', null, '祥云县', '532923');
INSERT INTO `kl_area` VALUES ('3035', '231', null, '申扎县', '542426');
INSERT INTO `kl_area` VALUES ('3036', '196', null, '宾川县', '532924');
INSERT INTO `kl_area` VALUES ('3037', '231', null, '索县', '542427');
INSERT INTO `kl_area` VALUES ('3038', '196', null, '弥渡县', '532925');
INSERT INTO `kl_area` VALUES ('3039', '231', null, '班戈县', '542428');
INSERT INTO `kl_area` VALUES ('3040', '196', null, '南涧彝族自治县', '532926');
INSERT INTO `kl_area` VALUES ('3041', '231', null, '巴青县', '542429');
INSERT INTO `kl_area` VALUES ('3042', '196', null, '巍山彝族回族自治县', '532927');
INSERT INTO `kl_area` VALUES ('3043', '231', null, '尼玛县', '542430');
INSERT INTO `kl_area` VALUES ('3044', '196', null, '永平县', '532928');
INSERT INTO `kl_area` VALUES ('3045', '231', null, '双湖县', '542431');
INSERT INTO `kl_area` VALUES ('3046', '196', null, '云龙县', '532929');
INSERT INTO `kl_area` VALUES ('3047', '196', null, '洱源县', '532930');
INSERT INTO `kl_area` VALUES ('3048', '196', null, '剑川县', '532931');
INSERT INTO `kl_area` VALUES ('3049', '196', null, '鹤庆县', '532932');
INSERT INTO `kl_area` VALUES ('3050', '232', null, '普兰县', '542521');
INSERT INTO `kl_area` VALUES ('3051', '232', null, '札达县', '542522');
INSERT INTO `kl_area` VALUES ('3052', '232', null, '噶尔县', '542523');
INSERT INTO `kl_area` VALUES ('3053', '232', null, '日土县', '542524');
INSERT INTO `kl_area` VALUES ('3054', '232', null, '革吉县', '542525');
INSERT INTO `kl_area` VALUES ('3055', '197', null, '瑞丽市', '533102');
INSERT INTO `kl_area` VALUES ('3056', '232', null, '改则县', '542526');
INSERT INTO `kl_area` VALUES ('3057', '197', null, '芒市', '533103');
INSERT INTO `kl_area` VALUES ('3058', '232', null, '措勤县', '542527');
INSERT INTO `kl_area` VALUES ('3059', '197', null, '梁河县', '533122');
INSERT INTO `kl_area` VALUES ('3060', '197', null, '盈江县', '533123');
INSERT INTO `kl_area` VALUES ('3061', '197', null, '陇川县', '533124');
INSERT INTO `kl_area` VALUES ('3062', '233', null, '林芝县', '542621');
INSERT INTO `kl_area` VALUES ('3063', '233', null, '工布江达县', '542622');
INSERT INTO `kl_area` VALUES ('3064', '233', null, '米林县', '542623');
INSERT INTO `kl_area` VALUES ('3065', '233', null, '墨脱县', '542624');
INSERT INTO `kl_area` VALUES ('3066', '199', null, '泸水县', '533321');
INSERT INTO `kl_area` VALUES ('3067', '233', null, '波密县', '542625');
INSERT INTO `kl_area` VALUES ('3068', '199', null, '福贡县', '533323');
INSERT INTO `kl_area` VALUES ('3069', '233', null, '察隅县', '542626');
INSERT INTO `kl_area` VALUES ('3070', '199', null, '贡山独龙族怒族自治县', '533324');
INSERT INTO `kl_area` VALUES ('3071', '233', null, '朗县', '542627');
INSERT INTO `kl_area` VALUES ('3072', '199', null, '兰坪白族普米族自治县', '533325');
INSERT INTO `kl_area` VALUES ('3073', '247', null, '市辖区', '610101');
INSERT INTO `kl_area` VALUES ('3074', '201', null, '香格里拉县', '533421');
INSERT INTO `kl_area` VALUES ('3075', '247', null, '新城区', '610102');
INSERT INTO `kl_area` VALUES ('3076', '201', null, '德钦县', '533422');
INSERT INTO `kl_area` VALUES ('3077', '247', null, '碑林区', '610103');
INSERT INTO `kl_area` VALUES ('3078', '201', null, '维西傈僳族自治县', '533423');
INSERT INTO `kl_area` VALUES ('3079', '247', null, '莲湖区', '610104');
INSERT INTO `kl_area` VALUES ('3080', '247', null, '灞桥区', '610111');
INSERT INTO `kl_area` VALUES ('3081', '247', null, '未央区', '610112');
INSERT INTO `kl_area` VALUES ('3082', '247', null, '雁塔区', '610113');
INSERT INTO `kl_area` VALUES ('3083', '247', null, '阎良区', '610114');
INSERT INTO `kl_area` VALUES ('3084', '247', null, '临潼区', '610115');
INSERT INTO `kl_area` VALUES ('3085', '247', null, '长安区', '610116');
INSERT INTO `kl_area` VALUES ('3086', '247', null, '蓝田县', '610122');
INSERT INTO `kl_area` VALUES ('3087', '247', null, '周至县', '610124');
INSERT INTO `kl_area` VALUES ('3088', '247', null, '户县', '610125');
INSERT INTO `kl_area` VALUES ('3089', '247', null, '高陵县', '610126');
INSERT INTO `kl_area` VALUES ('3090', '224', null, '市辖区', '540101');
INSERT INTO `kl_area` VALUES ('3091', '224', null, '城关区', '540102');
INSERT INTO `kl_area` VALUES ('3092', '224', null, '林周县', '540121');
INSERT INTO `kl_area` VALUES ('3093', '224', null, '当雄县', '540122');
INSERT INTO `kl_area` VALUES ('3094', '224', null, '尼木县', '540123');
INSERT INTO `kl_area` VALUES ('3095', '224', null, '曲水县', '540124');
INSERT INTO `kl_area` VALUES ('3096', '224', null, '堆龙德庆县', '540125');
INSERT INTO `kl_area` VALUES ('3097', '224', null, '达孜县', '540126');
INSERT INTO `kl_area` VALUES ('3098', '224', null, '墨竹工卡县', '540127');
INSERT INTO `kl_area` VALUES ('3099', '250', null, '市辖区', '610201');
INSERT INTO `kl_area` VALUES ('3100', '250', null, '王益区', '610202');
INSERT INTO `kl_area` VALUES ('3101', '250', null, '印台区', '610203');
INSERT INTO `kl_area` VALUES ('3102', '250', null, '耀州区', '610204');
INSERT INTO `kl_area` VALUES ('3103', '250', null, '宜君县', '610222');
INSERT INTO `kl_area` VALUES ('3104', '226', null, '昌都县', '542121');
INSERT INTO `kl_area` VALUES ('3105', '226', null, '江达县', '542122');
INSERT INTO `kl_area` VALUES ('3106', '226', null, '贡觉县', '542123');
INSERT INTO `kl_area` VALUES ('3107', '226', null, '类乌齐县', '542124');
INSERT INTO `kl_area` VALUES ('3108', '226', null, '丁青县', '542125');
INSERT INTO `kl_area` VALUES ('3109', '226', null, '察雅县', '542126');
INSERT INTO `kl_area` VALUES ('3110', '253', null, '市辖区', '610301');
INSERT INTO `kl_area` VALUES ('3111', '226', null, '八宿县', '542127');
INSERT INTO `kl_area` VALUES ('3112', '253', null, '渭滨区', '610302');
INSERT INTO `kl_area` VALUES ('3113', '226', null, '左贡县', '542128');
INSERT INTO `kl_area` VALUES ('3114', '253', null, '金台区', '610303');
INSERT INTO `kl_area` VALUES ('3115', '226', null, '芒康县', '542129');
INSERT INTO `kl_area` VALUES ('3116', '253', null, '陈仓区', '610304');
INSERT INTO `kl_area` VALUES ('3117', '226', null, '洛隆县', '542132');
INSERT INTO `kl_area` VALUES ('3118', '253', null, '凤翔县', '610322');
INSERT INTO `kl_area` VALUES ('3119', '226', null, '边坝县', '542133');
INSERT INTO `kl_area` VALUES ('3120', '253', null, '岐山县', '610323');
INSERT INTO `kl_area` VALUES ('3121', '253', null, '扶风县', '610324');
INSERT INTO `kl_area` VALUES ('3122', '253', null, '眉县', '610326');
INSERT INTO `kl_area` VALUES ('3123', '253', null, '陇县', '610327');
INSERT INTO `kl_area` VALUES ('3124', '253', null, '千阳县', '610328');
INSERT INTO `kl_area` VALUES ('3125', '253', null, '麟游县', '610329');
INSERT INTO `kl_area` VALUES ('3126', '253', null, '凤县', '610330');
INSERT INTO `kl_area` VALUES ('3127', '253', null, '太白县', '610331');
INSERT INTO `kl_area` VALUES ('3128', '228', null, '乃东县', '542221');
INSERT INTO `kl_area` VALUES ('3129', '228', null, '扎囊县', '542222');
INSERT INTO `kl_area` VALUES ('3130', '228', null, '贡嘎县', '542223');
INSERT INTO `kl_area` VALUES ('3131', '228', null, '桑日县', '542224');
INSERT INTO `kl_area` VALUES ('3132', '228', null, '琼结县', '542225');
INSERT INTO `kl_area` VALUES ('3133', '228', null, '曲松县', '542226');
INSERT INTO `kl_area` VALUES ('3134', '228', null, '措美县', '542227');
INSERT INTO `kl_area` VALUES ('3135', '228', null, '洛扎县', '542228');
INSERT INTO `kl_area` VALUES ('3136', '228', null, '加查县', '542229');
INSERT INTO `kl_area` VALUES ('3137', '228', null, '隆子县', '542231');
INSERT INTO `kl_area` VALUES ('3138', '256', null, '市辖区', '610401');
INSERT INTO `kl_area` VALUES ('3139', '228', null, '错那县', '542232');
INSERT INTO `kl_area` VALUES ('3140', '256', null, '秦都区', '610402');
INSERT INTO `kl_area` VALUES ('3141', '228', null, '浪卡子县', '542233');
INSERT INTO `kl_area` VALUES ('3142', '256', null, '杨陵区', '610403');
INSERT INTO `kl_area` VALUES ('3143', '256', null, '渭城区', '610404');
INSERT INTO `kl_area` VALUES ('3144', '256', null, '三原县', '610422');
INSERT INTO `kl_area` VALUES ('3145', '256', null, '泾阳县', '610423');
INSERT INTO `kl_area` VALUES ('3146', '256', null, '乾县', '610424');
INSERT INTO `kl_area` VALUES ('3147', '256', null, '礼泉县', '610425');
INSERT INTO `kl_area` VALUES ('3148', '256', null, '永寿县', '610426');
INSERT INTO `kl_area` VALUES ('3149', '256', null, '彬县', '610427');
INSERT INTO `kl_area` VALUES ('3150', '256', null, '长武县', '610428');
INSERT INTO `kl_area` VALUES ('3151', '256', null, '旬邑县', '610429');
INSERT INTO `kl_area` VALUES ('3152', '256', null, '淳化县', '610430');
INSERT INTO `kl_area` VALUES ('3153', '256', null, '武功县', '610431');
INSERT INTO `kl_area` VALUES ('3154', '256', null, '兴平市', '610481');
INSERT INTO `kl_area` VALUES ('3155', '230', null, '日喀则市', '542301');
INSERT INTO `kl_area` VALUES ('3156', '230', null, '南木林县', '542322');
INSERT INTO `kl_area` VALUES ('3157', '230', null, '江孜县', '542323');
INSERT INTO `kl_area` VALUES ('3158', '230', null, '定日县', '542324');
INSERT INTO `kl_area` VALUES ('3159', '230', null, '萨迦县', '542325');
INSERT INTO `kl_area` VALUES ('3160', '230', null, '拉孜县', '542326');
INSERT INTO `kl_area` VALUES ('3161', '230', null, '昂仁县', '542327');
INSERT INTO `kl_area` VALUES ('3162', '230', null, '谢通门县', '542328');
INSERT INTO `kl_area` VALUES ('3163', '230', null, '白朗县', '542329');
INSERT INTO `kl_area` VALUES ('3164', '230', null, '仁布县', '542330');
INSERT INTO `kl_area` VALUES ('3165', '230', null, '康马县', '542331');
INSERT INTO `kl_area` VALUES ('3166', '230', null, '定结县', '542332');
INSERT INTO `kl_area` VALUES ('3167', '230', null, '仲巴县', '542333');
INSERT INTO `kl_area` VALUES ('3168', '230', null, '亚东县', '542334');
INSERT INTO `kl_area` VALUES ('3169', '230', null, '吉隆县', '542335');
INSERT INTO `kl_area` VALUES ('3170', '230', null, '聂拉木县', '542336');
INSERT INTO `kl_area` VALUES ('3171', '230', null, '萨嘎县', '542337');
INSERT INTO `kl_area` VALUES ('3172', '258', null, '市辖区', '610501');
INSERT INTO `kl_area` VALUES ('3173', '230', null, '岗巴县', '542338');
INSERT INTO `kl_area` VALUES ('3174', '258', null, '临渭区', '610502');
INSERT INTO `kl_area` VALUES ('3175', '258', null, '华县', '610521');
INSERT INTO `kl_area` VALUES ('3176', '258', null, '潼关县', '610522');
INSERT INTO `kl_area` VALUES ('3177', '258', null, '大荔县', '610523');
INSERT INTO `kl_area` VALUES ('3178', '258', null, '合阳县', '610524');
INSERT INTO `kl_area` VALUES ('3179', '258', null, '澄城县', '610525');
INSERT INTO `kl_area` VALUES ('3180', '258', null, '蒲城县', '610526');
INSERT INTO `kl_area` VALUES ('3181', '258', null, '白水县', '610527');
INSERT INTO `kl_area` VALUES ('3182', '258', null, '富平县', '610528');
INSERT INTO `kl_area` VALUES ('3183', '258', null, '韩城市', '610581');
INSERT INTO `kl_area` VALUES ('3184', '258', null, '华阴市', '610582');
INSERT INTO `kl_area` VALUES ('3185', '261', null, '市辖区', '610601');
INSERT INTO `kl_area` VALUES ('3186', '261', null, '宝塔区', '610602');
INSERT INTO `kl_area` VALUES ('3187', '261', null, '延长县', '610621');
INSERT INTO `kl_area` VALUES ('3188', '261', null, '延川县', '610622');
INSERT INTO `kl_area` VALUES ('3189', '261', null, '子长县', '610623');
INSERT INTO `kl_area` VALUES ('3190', '261', null, '安塞县', '610624');
INSERT INTO `kl_area` VALUES ('3191', '261', null, '志丹县', '610625');
INSERT INTO `kl_area` VALUES ('3192', '261', null, '吴起县', '610626');
INSERT INTO `kl_area` VALUES ('3193', '261', null, '甘泉县', '610627');
INSERT INTO `kl_area` VALUES ('3194', '261', null, '富县', '610628');
INSERT INTO `kl_area` VALUES ('3195', '261', null, '洛川县', '610629');
INSERT INTO `kl_area` VALUES ('3196', '261', null, '宜川县', '610630');
INSERT INTO `kl_area` VALUES ('3197', '261', null, '黄龙县', '610631');
INSERT INTO `kl_area` VALUES ('3198', '261', null, '黄陵县', '610632');
INSERT INTO `kl_area` VALUES ('3199', '263', null, '市辖区', '610701');
INSERT INTO `kl_area` VALUES ('3200', '263', null, '汉台区', '610702');
INSERT INTO `kl_area` VALUES ('3201', '263', null, '南郑县', '610721');
INSERT INTO `kl_area` VALUES ('3202', '263', null, '城固县', '610722');
INSERT INTO `kl_area` VALUES ('3203', '263', null, '洋县', '610723');
INSERT INTO `kl_area` VALUES ('3204', '263', null, '西乡县', '610724');
INSERT INTO `kl_area` VALUES ('3205', '263', null, '勉县', '610725');
INSERT INTO `kl_area` VALUES ('3206', '263', null, '宁强县', '610726');
INSERT INTO `kl_area` VALUES ('3207', '263', null, '略阳县', '610727');
INSERT INTO `kl_area` VALUES ('3208', '263', null, '镇巴县', '610728');
INSERT INTO `kl_area` VALUES ('3209', '263', null, '留坝县', '610729');
INSERT INTO `kl_area` VALUES ('3210', '263', null, '佛坪县', '610730');
INSERT INTO `kl_area` VALUES ('3211', '265', null, '市辖区', '610801');
INSERT INTO `kl_area` VALUES ('3212', '265', null, '榆阳区', '610802');
INSERT INTO `kl_area` VALUES ('3213', '265', null, '神木县', '610821');
INSERT INTO `kl_area` VALUES ('3214', '265', null, '府谷县', '610822');
INSERT INTO `kl_area` VALUES ('3215', '265', null, '横山县', '610823');
INSERT INTO `kl_area` VALUES ('3216', '265', null, '靖边县', '610824');
INSERT INTO `kl_area` VALUES ('3217', '265', null, '定边县', '610825');
INSERT INTO `kl_area` VALUES ('3218', '265', null, '绥德县', '610826');
INSERT INTO `kl_area` VALUES ('3219', '265', null, '米脂县', '610827');
INSERT INTO `kl_area` VALUES ('3220', '265', null, '佳县', '610828');
INSERT INTO `kl_area` VALUES ('3221', '265', null, '吴堡县', '610829');
INSERT INTO `kl_area` VALUES ('3222', '265', null, '清涧县', '610830');
INSERT INTO `kl_area` VALUES ('3223', '265', null, '子洲县', '610831');
INSERT INTO `kl_area` VALUES ('3224', '294', null, '市辖区', '620801');
INSERT INTO `kl_area` VALUES ('3225', '294', null, '崆峒区', '620802');
INSERT INTO `kl_area` VALUES ('3226', '294', null, '泾川县', '620821');
INSERT INTO `kl_area` VALUES ('3227', '294', null, '灵台县', '620822');
INSERT INTO `kl_area` VALUES ('3228', '294', null, '崇信县', '620823');
INSERT INTO `kl_area` VALUES ('3229', '294', null, '华亭县', '620824');
INSERT INTO `kl_area` VALUES ('3230', '294', null, '庄浪县', '620825');
INSERT INTO `kl_area` VALUES ('3231', '294', null, '静宁县', '620826');
INSERT INTO `kl_area` VALUES ('3232', '267', null, '市辖区', '610901');
INSERT INTO `kl_area` VALUES ('3233', '267', null, '汉滨区', '610902');
INSERT INTO `kl_area` VALUES ('3234', '267', null, '汉阴县', '610921');
INSERT INTO `kl_area` VALUES ('3235', '267', null, '石泉县', '610922');
INSERT INTO `kl_area` VALUES ('3236', '267', null, '宁陕县', '610923');
INSERT INTO `kl_area` VALUES ('3237', '267', null, '紫阳县', '610924');
INSERT INTO `kl_area` VALUES ('3238', '267', null, '岚皋县', '610925');
INSERT INTO `kl_area` VALUES ('3239', '267', null, '平利县', '610926');
INSERT INTO `kl_area` VALUES ('3240', '325', null, '同仁县', '632321');
INSERT INTO `kl_area` VALUES ('3241', '267', null, '镇坪县', '610927');
INSERT INTO `kl_area` VALUES ('3242', '325', null, '尖扎县', '632322');
INSERT INTO `kl_area` VALUES ('3243', '267', null, '旬阳县', '610928');
INSERT INTO `kl_area` VALUES ('3244', '325', null, '泽库县', '632323');
INSERT INTO `kl_area` VALUES ('3245', '267', null, '白河县', '610929');
INSERT INTO `kl_area` VALUES ('3246', '325', null, '河南蒙古族自治县', '632324');
INSERT INTO `kl_area` VALUES ('3247', '295', null, '市辖区', '620901');
INSERT INTO `kl_area` VALUES ('3248', '295', null, '肃州区', '620902');
INSERT INTO `kl_area` VALUES ('3249', '295', null, '金塔县', '620921');
INSERT INTO `kl_area` VALUES ('3250', '295', null, '瓜州县', '620922');
INSERT INTO `kl_area` VALUES ('3251', '295', null, '肃北蒙古族自治县', '620923');
INSERT INTO `kl_area` VALUES ('3252', '295', null, '阿克塞哈萨克族自治县', '620924');
INSERT INTO `kl_area` VALUES ('3253', '295', null, '玉门市', '620981');
INSERT INTO `kl_area` VALUES ('3254', '295', null, '敦煌市', '620982');
INSERT INTO `kl_area` VALUES ('3255', '269', null, '市辖区', '611001');
INSERT INTO `kl_area` VALUES ('3256', '269', null, '商州区', '611002');
INSERT INTO `kl_area` VALUES ('3257', '269', null, '洛南县', '611021');
INSERT INTO `kl_area` VALUES ('3258', '269', null, '丹凤县', '611022');
INSERT INTO `kl_area` VALUES ('3259', '269', null, '商南县', '611023');
INSERT INTO `kl_area` VALUES ('3260', '327', null, '共和县', '632521');
INSERT INTO `kl_area` VALUES ('3261', '269', null, '山阳县', '611024');
INSERT INTO `kl_area` VALUES ('3262', '327', null, '同德县', '632522');
INSERT INTO `kl_area` VALUES ('3263', '269', null, '镇安县', '611025');
INSERT INTO `kl_area` VALUES ('3264', '327', null, '贵德县', '632523');
INSERT INTO `kl_area` VALUES ('3265', '269', null, '柞水县', '611026');
INSERT INTO `kl_area` VALUES ('3266', '327', null, '兴海县', '632524');
INSERT INTO `kl_area` VALUES ('3267', '327', null, '贵南县', '632525');
INSERT INTO `kl_area` VALUES ('3268', '296', null, '市辖区', '621001');
INSERT INTO `kl_area` VALUES ('3269', '296', null, '西峰区', '621002');
INSERT INTO `kl_area` VALUES ('3270', '296', null, '庆城县', '621021');
INSERT INTO `kl_area` VALUES ('3271', '296', null, '环县', '621022');
INSERT INTO `kl_area` VALUES ('3272', '296', null, '华池县', '621023');
INSERT INTO `kl_area` VALUES ('3273', '296', null, '合水县', '621024');
INSERT INTO `kl_area` VALUES ('3274', '296', null, '正宁县', '621025');
INSERT INTO `kl_area` VALUES ('3275', '296', null, '宁县', '621026');
INSERT INTO `kl_area` VALUES ('3276', '296', null, '镇原县', '621027');
INSERT INTO `kl_area` VALUES ('3277', '282', null, '市辖区', '620101');
INSERT INTO `kl_area` VALUES ('3278', '282', null, '城关区', '620102');
INSERT INTO `kl_area` VALUES ('3279', '331', null, '玛沁县', '632621');
INSERT INTO `kl_area` VALUES ('3280', '282', null, '七里河区', '620103');
INSERT INTO `kl_area` VALUES ('3281', '331', null, '班玛县', '632622');
INSERT INTO `kl_area` VALUES ('3282', '282', null, '西固区', '620104');
INSERT INTO `kl_area` VALUES ('3283', '331', null, '甘德县', '632623');
INSERT INTO `kl_area` VALUES ('3284', '282', null, '安宁区', '620105');
INSERT INTO `kl_area` VALUES ('3285', '331', null, '达日县', '632624');
INSERT INTO `kl_area` VALUES ('3286', '282', null, '红古区', '620111');
INSERT INTO `kl_area` VALUES ('3287', '331', null, '久治县', '632625');
INSERT INTO `kl_area` VALUES ('3288', '282', null, '永登县', '620121');
INSERT INTO `kl_area` VALUES ('3289', '331', null, '玛多县', '632626');
INSERT INTO `kl_area` VALUES ('3290', '282', null, '皋兰县', '620122');
INSERT INTO `kl_area` VALUES ('3291', '282', null, '榆中县', '620123');
INSERT INTO `kl_area` VALUES ('3292', '297', null, '市辖区', '621101');
INSERT INTO `kl_area` VALUES ('3293', '297', null, '安定区', '621102');
INSERT INTO `kl_area` VALUES ('3294', '297', null, '通渭县', '621121');
INSERT INTO `kl_area` VALUES ('3295', '297', null, '陇西县', '621122');
INSERT INTO `kl_area` VALUES ('3296', '297', null, '渭源县', '621123');
INSERT INTO `kl_area` VALUES ('3297', '297', null, '临洮县', '621124');
INSERT INTO `kl_area` VALUES ('3298', '297', null, '漳县', '621125');
INSERT INTO `kl_area` VALUES ('3299', '297', null, '岷县', '621126');
INSERT INTO `kl_area` VALUES ('3300', '333', null, '玉树市', '632701');
INSERT INTO `kl_area` VALUES ('3301', '333', null, '杂多县', '632722');
INSERT INTO `kl_area` VALUES ('3302', '285', null, '市辖区', '620201');
INSERT INTO `kl_area` VALUES ('3303', '333', null, '称多县', '632723');
INSERT INTO `kl_area` VALUES ('3304', '333', null, '治多县', '632724');
INSERT INTO `kl_area` VALUES ('3305', '333', null, '囊谦县', '632725');
INSERT INTO `kl_area` VALUES ('3306', '333', null, '曲麻莱县', '632726');
INSERT INTO `kl_area` VALUES ('3307', '298', null, '市辖区', '621201');
INSERT INTO `kl_area` VALUES ('3308', '298', null, '武都区', '621202');
INSERT INTO `kl_area` VALUES ('3309', '298', null, '成县', '621221');
INSERT INTO `kl_area` VALUES ('3310', '298', null, '文县', '621222');
INSERT INTO `kl_area` VALUES ('3311', '298', null, '宕昌县', '621223');
INSERT INTO `kl_area` VALUES ('3312', '298', null, '康县', '621224');
INSERT INTO `kl_area` VALUES ('3313', '298', null, '西和县', '621225');
INSERT INTO `kl_area` VALUES ('3314', '298', null, '礼县', '621226');
INSERT INTO `kl_area` VALUES ('3315', '288', null, '市辖区', '620301');
INSERT INTO `kl_area` VALUES ('3316', '298', null, '徽县', '621227');
INSERT INTO `kl_area` VALUES ('3317', '288', null, '金川区', '620302');
INSERT INTO `kl_area` VALUES ('3318', '298', null, '两当县', '621228');
INSERT INTO `kl_area` VALUES ('3319', '288', null, '永昌县', '620321');
INSERT INTO `kl_area` VALUES ('3320', '335', null, '格尔木市', '632801');
INSERT INTO `kl_area` VALUES ('3321', '335', null, '德令哈市', '632802');
INSERT INTO `kl_area` VALUES ('3322', '335', null, '乌兰县', '632821');
INSERT INTO `kl_area` VALUES ('3323', '335', null, '都兰县', '632822');
INSERT INTO `kl_area` VALUES ('3324', '335', null, '天峻县', '632823');
INSERT INTO `kl_area` VALUES ('3325', '299', null, '临夏市', '622901');
INSERT INTO `kl_area` VALUES ('3326', '290', null, '市辖区', '620401');
INSERT INTO `kl_area` VALUES ('3327', '299', null, '临夏县', '622921');
INSERT INTO `kl_area` VALUES ('3328', '290', null, '白银区', '620402');
INSERT INTO `kl_area` VALUES ('3329', '299', null, '康乐县', '622922');
INSERT INTO `kl_area` VALUES ('3330', '343', null, '市辖区', '640101');
INSERT INTO `kl_area` VALUES ('3331', '290', null, '平川区', '620403');
INSERT INTO `kl_area` VALUES ('3332', '343', null, '兴庆区', '640104');
INSERT INTO `kl_area` VALUES ('3333', '299', null, '永靖县', '622923');
INSERT INTO `kl_area` VALUES ('3334', '290', null, '靖远县', '620421');
INSERT INTO `kl_area` VALUES ('3335', '343', null, '西夏区', '640105');
INSERT INTO `kl_area` VALUES ('3336', '299', null, '广河县', '622924');
INSERT INTO `kl_area` VALUES ('3337', '290', null, '会宁县', '620422');
INSERT INTO `kl_area` VALUES ('3338', '343', null, '金凤区', '640106');
INSERT INTO `kl_area` VALUES ('3339', '299', null, '和政县', '622925');
INSERT INTO `kl_area` VALUES ('3340', '290', null, '景泰县', '620423');
INSERT INTO `kl_area` VALUES ('3341', '343', null, '永宁县', '640121');
INSERT INTO `kl_area` VALUES ('3342', '299', null, '东乡族自治县', '622926');
INSERT INTO `kl_area` VALUES ('3343', '343', null, '贺兰县', '640122');
INSERT INTO `kl_area` VALUES ('3344', '299', null, '积石山保安族东乡族撒拉族自治县', '622927');
INSERT INTO `kl_area` VALUES ('3345', '343', null, '灵武市', '640181');
INSERT INTO `kl_area` VALUES ('3346', '291', null, '市辖区', '620501');
INSERT INTO `kl_area` VALUES ('3347', '291', null, '秦州区', '620502');
INSERT INTO `kl_area` VALUES ('3348', '291', null, '麦积区', '620503');
INSERT INTO `kl_area` VALUES ('3349', '291', null, '清水县', '620521');
INSERT INTO `kl_area` VALUES ('3350', '291', null, '秦安县', '620522');
INSERT INTO `kl_area` VALUES ('3351', '300', null, '合作市', '623001');
INSERT INTO `kl_area` VALUES ('3352', '291', null, '甘谷县', '620523');
INSERT INTO `kl_area` VALUES ('3353', '300', null, '临潭县', '623021');
INSERT INTO `kl_area` VALUES ('3354', '344', null, '市辖区', '640201');
INSERT INTO `kl_area` VALUES ('3355', '291', null, '武山县', '620524');
INSERT INTO `kl_area` VALUES ('3356', '300', null, '卓尼县', '623022');
INSERT INTO `kl_area` VALUES ('3357', '344', null, '大武口区', '640202');
INSERT INTO `kl_area` VALUES ('3358', '291', null, '张家川回族自治县', '620525');
INSERT INTO `kl_area` VALUES ('3359', '300', null, '舟曲县', '623023');
INSERT INTO `kl_area` VALUES ('3360', '344', null, '惠农区', '640205');
INSERT INTO `kl_area` VALUES ('3361', '344', null, '平罗县', '640221');
INSERT INTO `kl_area` VALUES ('3362', '300', null, '迭部县', '623024');
INSERT INTO `kl_area` VALUES ('3363', '300', null, '玛曲县', '623025');
INSERT INTO `kl_area` VALUES ('3364', '300', null, '碌曲县', '623026');
INSERT INTO `kl_area` VALUES ('3365', '300', null, '夏河县', '623027');
INSERT INTO `kl_area` VALUES ('3366', '292', null, '市辖区', '620601');
INSERT INTO `kl_area` VALUES ('3367', '292', null, '凉州区', '620602');
INSERT INTO `kl_area` VALUES ('3368', '345', null, '市辖区', '640301');
INSERT INTO `kl_area` VALUES ('3369', '292', null, '民勤县', '620621');
INSERT INTO `kl_area` VALUES ('3370', '345', null, '利通区', '640302');
INSERT INTO `kl_area` VALUES ('3371', '292', null, '古浪县', '620622');
INSERT INTO `kl_area` VALUES ('3372', '345', null, '红寺堡区', '640303');
INSERT INTO `kl_area` VALUES ('3373', '316', null, '市辖区', '630101');
INSERT INTO `kl_area` VALUES ('3374', '292', null, '天祝藏族自治县', '620623');
INSERT INTO `kl_area` VALUES ('3375', '345', null, '盐池县', '640323');
INSERT INTO `kl_area` VALUES ('3376', '316', null, '城东区', '630102');
INSERT INTO `kl_area` VALUES ('3377', '345', null, '同心县', '640324');
INSERT INTO `kl_area` VALUES ('3378', '316', null, '城中区', '630103');
INSERT INTO `kl_area` VALUES ('3379', '345', null, '青铜峡市', '640381');
INSERT INTO `kl_area` VALUES ('3380', '316', null, '城西区', '630104');
INSERT INTO `kl_area` VALUES ('3381', '316', null, '城北区', '630105');
INSERT INTO `kl_area` VALUES ('3382', '316', null, '大通回族土族自治县', '630121');
INSERT INTO `kl_area` VALUES ('3383', '316', null, '湟中县', '630122');
INSERT INTO `kl_area` VALUES ('3384', '316', null, '湟源县', '630123');
INSERT INTO `kl_area` VALUES ('3385', '293', null, '市辖区', '620701');
INSERT INTO `kl_area` VALUES ('3386', '293', null, '甘州区', '620702');
INSERT INTO `kl_area` VALUES ('3387', '293', null, '肃南裕固族自治县', '620721');
INSERT INTO `kl_area` VALUES ('3388', '293', null, '民乐县', '620722');
INSERT INTO `kl_area` VALUES ('3389', '346', null, '市辖区', '640401');
INSERT INTO `kl_area` VALUES ('3390', '293', null, '临泽县', '620723');
INSERT INTO `kl_area` VALUES ('3391', '346', null, '原州区', '640402');
INSERT INTO `kl_area` VALUES ('3392', '293', null, '高台县', '620724');
INSERT INTO `kl_area` VALUES ('3393', '346', null, '西吉县', '640422');
INSERT INTO `kl_area` VALUES ('3394', '293', null, '山丹县', '620725');
INSERT INTO `kl_area` VALUES ('3395', '318', null, '乐都区', '630202');
INSERT INTO `kl_area` VALUES ('3396', '346', null, '隆德县', '640423');
INSERT INTO `kl_area` VALUES ('3397', '318', null, '平安县', '630221');
INSERT INTO `kl_area` VALUES ('3398', '346', null, '泾源县', '640424');
INSERT INTO `kl_area` VALUES ('3399', '318', null, '民和回族土族自治县', '630222');
INSERT INTO `kl_area` VALUES ('3400', '346', null, '彭阳县', '640425');
INSERT INTO `kl_area` VALUES ('3401', '318', null, '互助土族自治县', '630223');
INSERT INTO `kl_area` VALUES ('3402', '318', null, '化隆回族自治县', '630224');
INSERT INTO `kl_area` VALUES ('3403', '318', null, '循化撒拉族自治县', '630225');
INSERT INTO `kl_area` VALUES ('3404', '348', null, '市辖区', '640501');
INSERT INTO `kl_area` VALUES ('3405', '348', null, '沙坡头区', '640502');
INSERT INTO `kl_area` VALUES ('3406', '321', null, '门源回族自治县', '632221');
INSERT INTO `kl_area` VALUES ('3407', '348', null, '中宁县', '640521');
INSERT INTO `kl_area` VALUES ('3408', '321', null, '祁连县', '632222');
INSERT INTO `kl_area` VALUES ('3409', '348', null, '海原县', '640522');
INSERT INTO `kl_area` VALUES ('3410', '321', null, '海晏县', '632223');
INSERT INTO `kl_area` VALUES ('3411', '321', null, '刚察县', '632224');
INSERT INTO `kl_area` VALUES ('3412', '354', null, '市辖区', '650101');
INSERT INTO `kl_area` VALUES ('3413', '354', null, '天山区', '650102');
INSERT INTO `kl_area` VALUES ('3414', '354', null, '沙依巴克区', '650103');
INSERT INTO `kl_area` VALUES ('3415', '354', null, '新市区', '650104');
INSERT INTO `kl_area` VALUES ('3416', '354', null, '水磨沟区', '650105');
INSERT INTO `kl_area` VALUES ('3417', '354', null, '头屯河区', '650106');
INSERT INTO `kl_area` VALUES ('3418', '354', null, '达坂城区', '650107');
INSERT INTO `kl_area` VALUES ('3419', '354', null, '米东区', '650109');
INSERT INTO `kl_area` VALUES ('3420', '354', null, '乌鲁木齐县', '650121');
INSERT INTO `kl_area` VALUES ('3421', '372', null, '和田市', '653201');
INSERT INTO `kl_area` VALUES ('3422', '372', null, '和田县', '653221');
INSERT INTO `kl_area` VALUES ('3423', '372', null, '墨玉县', '653222');
INSERT INTO `kl_area` VALUES ('3424', '372', null, '皮山县', '653223');
INSERT INTO `kl_area` VALUES ('3425', '372', null, '洛浦县', '653224');
INSERT INTO `kl_area` VALUES ('3426', '372', null, '策勒县', '653225');
INSERT INTO `kl_area` VALUES ('3427', '372', null, '于田县', '653226');
INSERT INTO `kl_area` VALUES ('3428', '372', null, '民丰县', '653227');
INSERT INTO `kl_area` VALUES ('3429', '356', null, '市辖区', '650201');
INSERT INTO `kl_area` VALUES ('3430', '356', null, '独山子区', '650202');
INSERT INTO `kl_area` VALUES ('3431', '356', null, '克拉玛依区', '650203');
INSERT INTO `kl_area` VALUES ('3432', '356', null, '白碱滩区', '650204');
INSERT INTO `kl_area` VALUES ('3433', '356', null, '乌尔禾区', '650205');
INSERT INTO `kl_area` VALUES ('3434', '373', null, '伊宁市', '654002');
INSERT INTO `kl_area` VALUES ('3435', '373', null, '奎屯市', '654003');
INSERT INTO `kl_area` VALUES ('3436', '373', null, '伊宁县', '654021');
INSERT INTO `kl_area` VALUES ('3437', '358', null, '吐鲁番市', '652101');
INSERT INTO `kl_area` VALUES ('3438', '373', null, '察布查尔锡伯自治县', '654022');
INSERT INTO `kl_area` VALUES ('3439', '358', null, '鄯善县', '652122');
INSERT INTO `kl_area` VALUES ('3440', '373', null, '霍城县', '654023');
INSERT INTO `kl_area` VALUES ('3441', '358', null, '托克逊县', '652123');
INSERT INTO `kl_area` VALUES ('3442', '373', null, '巩留县', '654024');
INSERT INTO `kl_area` VALUES ('3443', '373', null, '新源县', '654025');
INSERT INTO `kl_area` VALUES ('3444', '373', null, '昭苏县', '654026');
INSERT INTO `kl_area` VALUES ('3445', '373', null, '特克斯县', '654027');
INSERT INTO `kl_area` VALUES ('3446', '373', null, '尼勒克县', '654028');
INSERT INTO `kl_area` VALUES ('3447', '360', null, '哈密市', '652201');
INSERT INTO `kl_area` VALUES ('3448', '360', null, '巴里坤哈萨克自治县', '652222');
INSERT INTO `kl_area` VALUES ('3449', '360', null, '伊吾县', '652223');
INSERT INTO `kl_area` VALUES ('3450', '374', null, '塔城市', '654201');
INSERT INTO `kl_area` VALUES ('3451', '374', null, '乌苏市', '654202');
INSERT INTO `kl_area` VALUES ('3452', '374', null, '额敏县', '654221');
INSERT INTO `kl_area` VALUES ('3453', '374', null, '沙湾县', '654223');
INSERT INTO `kl_area` VALUES ('3454', '374', null, '托里县', '654224');
INSERT INTO `kl_area` VALUES ('3455', '374', null, '裕民县', '654225');
INSERT INTO `kl_area` VALUES ('3456', '374', null, '和布克赛尔蒙古自治县', '654226');
INSERT INTO `kl_area` VALUES ('3457', '362', null, '昌吉市', '652301');
INSERT INTO `kl_area` VALUES ('3458', '362', null, '阜康市', '652302');
INSERT INTO `kl_area` VALUES ('3459', '362', null, '呼图壁县', '652323');
INSERT INTO `kl_area` VALUES ('3460', '362', null, '玛纳斯县', '652324');
INSERT INTO `kl_area` VALUES ('3461', '362', null, '奇台县', '652325');
INSERT INTO `kl_area` VALUES ('3462', '362', null, '吉木萨尔县', '652327');
INSERT INTO `kl_area` VALUES ('3463', '362', null, '木垒哈萨克自治县', '652328');
INSERT INTO `kl_area` VALUES ('3464', '375', null, '阿勒泰市', '654301');
INSERT INTO `kl_area` VALUES ('3465', '375', null, '布尔津县', '654321');
INSERT INTO `kl_area` VALUES ('3466', '375', null, '富蕴县', '654322');
INSERT INTO `kl_area` VALUES ('3467', '375', null, '福海县', '654323');
INSERT INTO `kl_area` VALUES ('3468', '375', null, '哈巴河县', '654324');
INSERT INTO `kl_area` VALUES ('3469', '375', null, '青河县', '654325');
INSERT INTO `kl_area` VALUES ('3470', '375', null, '吉木乃县', '654326');
INSERT INTO `kl_area` VALUES ('3471', '364', null, '博乐市', '652701');
INSERT INTO `kl_area` VALUES ('3472', '364', null, '阿拉山口市', '652702');
INSERT INTO `kl_area` VALUES ('3473', '364', null, '精河县', '652722');
INSERT INTO `kl_area` VALUES ('3474', '364', null, '温泉县', '652723');
INSERT INTO `kl_area` VALUES ('3475', '376', null, '石河子市', '659001');
INSERT INTO `kl_area` VALUES ('3476', '376', null, '阿拉尔市', '659002');
INSERT INTO `kl_area` VALUES ('3477', '376', null, '图木舒克市', '659003');
INSERT INTO `kl_area` VALUES ('3478', '376', null, '五家渠市', '659004');
INSERT INTO `kl_area` VALUES ('3479', '366', null, '库尔勒市', '652801');
INSERT INTO `kl_area` VALUES ('3480', '366', null, '轮台县', '652822');
INSERT INTO `kl_area` VALUES ('3481', '366', null, '尉犁县', '652823');
INSERT INTO `kl_area` VALUES ('3482', '366', null, '若羌县', '652824');
INSERT INTO `kl_area` VALUES ('3483', '366', null, '且末县', '652825');
INSERT INTO `kl_area` VALUES ('3484', '366', null, '焉耆回族自治县', '652826');
INSERT INTO `kl_area` VALUES ('3485', '366', null, '和静县', '652827');
INSERT INTO `kl_area` VALUES ('3486', '366', null, '和硕县', '652828');
INSERT INTO `kl_area` VALUES ('3487', '366', null, '博湖县', '652829');
INSERT INTO `kl_area` VALUES ('3488', '368', null, '阿克苏市', '652901');
INSERT INTO `kl_area` VALUES ('3489', '368', null, '温宿县', '652922');
INSERT INTO `kl_area` VALUES ('3490', '368', null, '库车县', '652923');
INSERT INTO `kl_area` VALUES ('3491', '368', null, '沙雅县', '652924');
INSERT INTO `kl_area` VALUES ('3492', '368', null, '新和县', '652925');
INSERT INTO `kl_area` VALUES ('3493', '368', null, '拜城县', '652926');
INSERT INTO `kl_area` VALUES ('3494', '368', null, '乌什县', '652927');
INSERT INTO `kl_area` VALUES ('3495', '368', null, '阿瓦提县', '652928');
INSERT INTO `kl_area` VALUES ('3496', '368', null, '柯坪县', '652929');
INSERT INTO `kl_area` VALUES ('3497', '370', null, '阿图什市', '653001');
INSERT INTO `kl_area` VALUES ('3498', '370', null, '阿克陶县', '653022');
INSERT INTO `kl_area` VALUES ('3499', '370', null, '阿合奇县', '653023');
INSERT INTO `kl_area` VALUES ('3500', '370', null, '乌恰县', '653024');
INSERT INTO `kl_area` VALUES ('3501', '371', null, '喀什市', '653101');
INSERT INTO `kl_area` VALUES ('3502', '371', null, '疏附县', '653121');
INSERT INTO `kl_area` VALUES ('3503', '371', null, '疏勒县', '653122');
INSERT INTO `kl_area` VALUES ('3504', '371', null, '英吉沙县', '653123');
INSERT INTO `kl_area` VALUES ('3505', '371', null, '泽普县', '653124');
INSERT INTO `kl_area` VALUES ('3506', '371', null, '莎车县', '653125');
INSERT INTO `kl_area` VALUES ('3507', '371', null, '叶城县', '653126');
INSERT INTO `kl_area` VALUES ('3508', '371', null, '麦盖提县', '653127');
INSERT INTO `kl_area` VALUES ('3509', '371', null, '岳普湖县', '653128');
INSERT INTO `kl_area` VALUES ('3510', '371', null, '伽师县', '653129');
INSERT INTO `kl_area` VALUES ('3511', '371', null, '巴楚县', '653130');
INSERT INTO `kl_area` VALUES ('3512', '371', null, '塔什库尔干塔吉克自治县', '653131');
INSERT INTO `kl_area` VALUES ('47402', '338', null, '市辖区', '441900');

-- ----------------------------
-- Table structure for kl_article
-- ----------------------------
DROP TABLE IF EXISTS `kl_article`;
CREATE TABLE `kl_article` (
  `article_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(5) NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL DEFAULT '',
  `content` longtext NOT NULL,
  `pic` int(11) NOT NULL DEFAULT '0',
  `attachment` int(11) NOT NULL DEFAULT '0',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `position` varchar(50) DEFAULT NULL,
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `views` int(11) DEFAULT '0',
  `color` varchar(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7956 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_article
-- ----------------------------
INSERT INTO `kl_article` VALUES ('7952', '1454', '公司最新通知', '<p>你好这个是自动保存的草稿，现在是测试过程，看看在编辑过程中能不能保存成功<br/></p>', '0', '0', '', '0,2', '1444899457', '1446195922', '1', '0', '#FFFFFF');
INSERT INTO `kl_article` VALUES ('7953', '0', '测试草稿文章', '<p>aaa1111111111111111111111111111111111233333333333333333311111111233333333331<br/></p>', '0', '0', '', '0', '1446195818', '1448296025', '2', '0', '#063263');
INSERT INTO `kl_article` VALUES ('7954', '0', '这是一个草稿', '', '0', '0', '', '1,2,3,6', '1446426368', '1446511597', '1', '5', '#6B54FF');
INSERT INTO `kl_article` VALUES ('7955', '0', '测试文章测试文章测试文章', '<p><br/> &nbsp;<img src=\"/Uploads/image/20150828/1440727929997132.png\"/></p>', '15639', '0', '', '0', '1446859921', '1450148622', '1', '0', '#FFFFFF');

-- ----------------------------
-- Table structure for kl_cart
-- ----------------------------
DROP TABLE IF EXISTS `kl_cart`;
CREATE TABLE `kl_cart` (
  `cart_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `goods_id` int(11) DEFAULT NULL,
  `num` int(11) DEFAULT '1',
  `selected` tinyint(1) DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=MyISAM AUTO_INCREMENT=871 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_cart
-- ----------------------------
INSERT INTO `kl_cart` VALUES ('869', '1', '1', '1', '0', null, null);
INSERT INTO `kl_cart` VALUES ('870', '1', '1', '2', '1', null, '1449537128');

-- ----------------------------
-- Table structure for kl_category
-- ----------------------------
DROP TABLE IF EXISTS `kl_category`;
CREATE TABLE `kl_category` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `name` varchar(255) DEFAULT NULL COMMENT '标志',
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `meta_title` varchar(50) DEFAULT '' COMMENT 'SEO的网页标题',
  `meta_keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `meta_descr` varchar(255) DEFAULT '' COMMENT '描述',
  `create_time` int(10) unsigned DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned DEFAULT '0' COMMENT '更新时间',
  `icon` int(10) unsigned DEFAULT '0' COMMENT '分类图标',
  `sort` int(10) unsigned DEFAULT '0' COMMENT '排序（同级有效）',
  `category_type` varchar(50) NOT NULL DEFAULT 'article',
  `status` tinyint(4) DEFAULT '0' COMMENT '数据状态',
  `list_tpl` varchar(50) DEFAULT NULL,
  `detail_tpl` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=1635 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- ----------------------------
-- Records of kl_category
-- ----------------------------
INSERT INTO `kl_category` VALUES ('1', '0', 'yingshizhizuo', 'QQ签名', '', '', '', '1379474947', '1432662816', '255', '2', 'article', '1', '', '');
INSERT INTO `kl_category` VALUES ('67', '0', 'zhuangshisheji', '其它分类', '', '', '', '1396328210', '1432662816', '0', '9', 'article', '1', '', '');
INSERT INTO `kl_category` VALUES ('80', '0', 'guanyuwomen', 'QQ说说', '', '', 'asdf', '1408393655', '1432662817', '254', '1', 'article', '1', '', '');
INSERT INTO `kl_category` VALUES ('1454', '0', 'aiqing', '爱情说说', '爱情_伤感', '伤感爱情说说,爱情说说心情短语,爱情说说带图片', '', '0', '1437545279', '0', '0', 'article', '1', '', '');
INSERT INTO `kl_category` VALUES ('84', '0', 'other', '其它说说', '', '', '', '0', '1433651145', '0', '0', 'article', '1', '', '');
INSERT INTO `kl_category` VALUES ('85', '0', 'shanggan', '伤感说说', '', '', '', '0', '1433650745', '0', '0', 'article', '1', '', '');
INSERT INTO `kl_category` VALUES ('86', '1630', 'gexing', '个性说说', 'QQ个性说说_个性签名', '个性说说大全,个性签名', '', '0', '1437545664', '0', '0', 'goods', '1', '', '');
INSERT INTO `kl_category` VALUES ('89', '1633', 'jingdian', '经典说说', 'QQ经典说说', '经典说说心情短语，经典说说 别人必评，经典说说带图片', '', '0', '1437545545', '0', '0', 'goods', '1', '', '');
INSERT INTO `kl_category` VALUES ('90', '80', 'gaoxiao', '搞笑说说', '搞笑大全说说', '爆笑笑话,搞笑的空间说说', '', '0', '1437545901', '0', '0', 'article', '1', '', '');
INSERT INTO `kl_category` VALUES ('506', '80', 'qinglv', '情侣说说', '情侣说说_头像_签名', '情侣个性签名,情侣头像', '', '0', '1437545793', '0', '0', 'article', '1', '', '');
INSERT INTO `kl_category` VALUES ('740', '80', 'lizhi', '励志说说', '励志名言_图片', '励志名言_励志名言图片', '', '0', '1437545974', '0', '0', 'article', '1', '', '');
INSERT INTO `kl_category` VALUES ('932', '80', 'kongjian', '空间说说', 'qq空间说说', 'qq空间说说带图片，空间素材', '', '0', '1437546043', '0', '0', 'article', '1', '', '');
INSERT INTO `kl_category` VALUES ('1634', '80', 'qqshuoshuodaquan', 'qq说说大全', '', '', '', '0', '0', '0', '0', 'article', '1', null, null);
INSERT INTO `kl_category` VALUES ('1633', '0', 'tuan', '图案分组', '', '', '', '1435029184', '1435029184', '0', '0', 'goods', '1', '', '');
INSERT INTO `kl_category` VALUES ('1632', '0', 'shuoshuotupian', '说说图片', '', '', '', '0', '0', '0', '0', 'goods', '1', null, null);
INSERT INTO `kl_category` VALUES ('1631', '0', 'xinqingshuoshuo', '心情说说', '', '', '', '0', '0', '0', '0', 'goods', '1', null, null);
INSERT INTO `kl_category` VALUES ('1630', '0', 'tupianshuoshuo', '图片说说', '', '', '', '0', '0', '0', '0', 'goods', '1', null, null);
INSERT INTO `kl_category` VALUES ('1629', '0', 'weimei', '唯美说说', '', '', '', '0', '1435124853', '0', '0', 'goods', '1', '', '');
INSERT INTO `kl_category` VALUES ('1628', '0', 'remenshuoshuo', '热门说说', '', '', '', '0', '0', '0', '0', 'goods', '1', null, null);

-- ----------------------------
-- Table structure for kl_comments
-- ----------------------------
DROP TABLE IF EXISTS `kl_comments`;
CREATE TABLE `kl_comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned DEFAULT '0',
  `arc_id` int(11) unsigned DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `qq` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `ip` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_comments
-- ----------------------------
INSERT INTO `kl_comments` VALUES ('7', '0', '0', null, 'Your articles are for when it ablsluteoy, positively, needs to be understood overnight.', 'Magda', null, '2cznls5scty@gmail.com', 'http://www.zhaokeli.com', null, '1', '190.199.75.60', '委内瑞拉', '1437543792');
INSERT INTO `kl_comments` VALUES ('2', '7', '0', null, 'asdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdf', '', null, 'sadf', null, null, '1', '2130706433', '保留地址', '1434535628');
INSERT INTO `kl_comments` VALUES ('3', '7', '0', null, 'sadf', '', null, '735579768@qq.com', null, null, '1', '127.0.0.1', '保留地址', '1434535940');
INSERT INTO `kl_comments` VALUES ('4', '0', '0', null, 'asdfasdf', '赵克立', null, '735579768@qq.com', null, null, '1', '222.142.94.103', '河南省平顶山市联通', '1434543159');
INSERT INTO `kl_comments` VALUES ('6', '0', '0', null, 'alert(\'sdf\');', 'asdf', null, '735579768@qq.com', null, null, '1', '123.15.190.20', '河南省新乡市联通', '1435379877');
INSERT INTO `kl_comments` VALUES ('8', '0', '0', null, 'Way to use the internet to help people solve preosbml!', 'Maggie', null, 'u8c2zvjtlc@gmail.com', null, null, '1', '79.172.242.181', '匈牙利', '1437544341');
INSERT INTO `kl_comments` VALUES ('9', '6', '0', null, '你好这个代码有问题', '赵克立', null, '735579768@qq.com', null, null, '1', '127.0.0.1', '保留地址', '1445909981');
INSERT INTO `kl_comments` VALUES ('10', '6', '0', null, 'alert,console', '啊哦', null, '735579768@qq.com', null, null, '1', '127.0.0.1', '保留地址', '1445910253');
INSERT INTO `kl_comments` VALUES ('11', '7', '0', null, 'asdf', '你好', null, 'love-_-love@msn.cn', null, null, '1', '127.0.0.1', '保留地址', '1445911558');
INSERT INTO `kl_comments` VALUES ('22', '0', '0', null, '你好这是个测试的内容', null, null, null, '', null, '1', '127.0.0.1', '保留地址', '1450168158');

-- ----------------------------
-- Table structure for kl_config
-- ----------------------------
DROP TABLE IF EXISTS `kl_config`;
CREATE TABLE `kl_config` (
  `config_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` varchar(50) NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `note` varchar(100) NOT NULL COMMENT '配置说明',
  `value` text NOT NULL COMMENT '配置值',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  `no_del` tinyint(1) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `data_reg` varchar(50) DEFAULT NULL,
  `data_ok` varchar(50) DEFAULT NULL,
  `data_err` varchar(50) DEFAULT NULL,
  `data_ts` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`config_id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_config
-- ----------------------------
INSERT INTO `kl_config` VALUES ('1', 'WEB_SITE_TITLE', 'string', '网站标题', '1', '0:系统配置\r\n1:基本配置\r\n', '网站标题前台显示标题', '说说大全_说说心情短语__爱你酷', '1378898976', '1418384205', '1', '1', '3', '1', null, null, null, null);
INSERT INTO `kl_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', 'textarea', '网站描述', '1', '', '网站搜索引擎描述', '爱你酷,爱生活，爱自己，就过来酷一把吧！说说大全', '1378898976', '1418384207', '1', '1', '3', '3', null, null, null, null);
INSERT INTO `kl_config` VALUES ('3', 'WEB_SITE_KEYWORD', 'string', '网站关键字', '1', '', '网站搜索引擎关键字', '说说大全,说说心情短语,爱情,伤感,个性,经典,带图片的说说', '1378898976', '1418384206', '1', '1', '3', '2', null, null, null, null);
INSERT INTO `kl_config` VALUES ('4', 'WEB_SITE_CLOSE', 'select', '网站维护', '1', '0:关闭\r\n1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '0', '1378898976', '1431178105', '1', '1', '3', '16', null, null, null, null);
INSERT INTO `kl_config` VALUES ('57', 'ADMIN_TITLE', 'string', '管理平台标题', '2', '', '', '爱你酷管理后台', '1409239276', '1418384047', '1', '1', '3', '0', null, null, null, null);
INSERT INTO `kl_config` VALUES ('58', 'DRAFTBOX_TIME', 'number', '保存草稿的时间', '2', '', '等待多久保存草稿(单位秒)', '30', '1409351555', '1418382153', '1', '1', '3', '9', null, null, null, null);
INSERT INTO `kl_config` VALUES ('10', 'WEB_SITE_ICP', 'string', '网站备案号', '1', '987987', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '我的备案号', '1378900335', '1431579898', '1', '1', '3', '9', null, null, null, null);
INSERT INTO `kl_config` VALUES ('37', 'SHOW_PAGE_TRACE', 'select', '是否显示页面Trace', '2', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1', '1387165685', '1433904075', '1', '1', '3', '6', null, null, null, null);
INSERT INTO `kl_config` VALUES ('39', 'URL_CASE_INSENSITIVE', 'select', '地址不区分大小写', '2', '0:区分大小写\r\n1:不区分大小写', '网站访问的地址不区分大小写', '0', '1392955163', '1427959216', '1', '1', '3', '1', null, null, null, null);
INSERT INTO `kl_config` VALUES ('42', 'MAIL_SMTP_HOST', 'string', 'SMTP服务器', '3', '', '', 'mail.ainiku.com', '1393438336', '1418384053', '1', '1', '3', '1', null, null, null, null);
INSERT INTO `kl_config` VALUES ('43', 'MAIL_SMTP_PORT', 'number', 'SMTP服务器端口', '3', '', '默认25', '25', '1393438384', '1418384175', '1', '1', '3', '2', null, null, null, null);
INSERT INTO `kl_config` VALUES ('44', 'MAIL_SMTP_USER', 'string', 'SMTP服务器用户名', '3', '', '填写您的完整用户名(如xxx@163.com)', 'service', '1393438416', '1418384176', '1', '1', '3', '3', null, null, null, null);
INSERT INTO `kl_config` VALUES ('45', 'MAIL_SMTP_PASS', 'string', 'SMTP服务器密码', '3', '', '填写您的密码', 'adminrootkl', '1393438502', '1418384176', '1', '1', '3', '4', null, null, null, null);
INSERT INTO `kl_config` VALUES ('46', 'MAIL_SMTP_CE', 'umeditor', '测试邮件内容', '3', '', '填写测试邮件地址', '<p><img src=\"http://user.ainiku.loc/Uploads/image/20150828/1440726455171.png\"/>邮件测试内容<img src=\"/Uploads/image/20150828/1440727929997132.png\" title=\"1440727929997132.png\" alt=\"Screenshot_2015-08-06-09-10-25.png\" width=\"513\" height=\"804\" style=\"width: 513px; height: 804px; float: left;\"/></p><p><span class=\"edui-editor-imagescale-hand1\" style=\"position: absolute; width: 6px; height: 6px; overflow: hidden; font-size: 0px; display: block; cursor: n-resize; top: 0px; margin-top: -4px; left: 256.5px; margin-left: -4px; color: rgb(102, 102, 102); font-family: &#39;microsoft yahei&#39;, Cambria, &#39;Hoefler Text&#39;, &#39;Liberation Serif&#39;, Times, &#39;Times New Roman&#39;, serif; background-color: rgb(60, 157, 208);\"></span><span class=\"edui-editor-imagescale-hand2\" style=\"position: absolute; width: 6px; height: 6px; overflow: hidden; font-size: 0px; display: block; cursor: ne-resize; top: 0px; margin-top: -4px; left: 513px; margin-left: -3px; color: rgb(102, 102, 102); font-family: &#39;microsoft yahei&#39;, Cambria, &#39;Hoefler Text&#39;, &#39;Liberation Serif&#39;, Times, &#39;Times New Roman&#39;, serif; background-color: rgb(60, 157, 208);\"></span><span class=\"edui-editor-imagescale-hand3\" style=\"position: absolute; width: 6px; height: 6px; overflow: hidden; font-size: 0px; display: block; cursor: w-resize; top: 479px; margin-top: -4px; left: 0px; margin-left: -4px; color: rgb(102, 102, 102); font-family: &#39;microsoft yahei&#39;, Cambria, &#39;Hoefler Text&#39;, &#39;Liberation Serif&#39;, Times, &#39;Times New Roman&#39;, serif; background-color: rgb(60, 157, 208);\"></span><span class=\"edui-editor-imagescale-hand4\" style=\"position: absolute; width: 6px; height: 6px; overflow: hidden; font-size: 0px; display: block; cursor: e-resize; top: 479px; margin-top: -4px; left: 513px; margin-left: -3px; color: rgb(102, 102, 102); font-family: &#39;microsoft yahei&#39;, Cambria, &#39;Hoefler Text&#39;, &#39;Liberation Serif&#39;, Times, &#39;Times New Roman&#39;, serif; background-color: rgb(60, 157, 208);\"></span><span class=\"edui-editor-imagescale-hand5\" style=\"position: absolute; width: 6px; height: 6px; overflow: hidden; font-size: 0px; display: block; cursor: sw-resize; top: 958px; margin-top: -3px; left: 0px; margin-left: -4px; color: rgb(102, 102, 102); font-family: &#39;microsoft yahei&#39;, Cambria, &#39;Hoefler Text&#39;, &#39;Liberation Serif&#39;, Times, &#39;Times New Roman&#39;, serif; background-color: rgb(60, 157, 208);\"></span></p><p>&nbsp;&nbsp;<br/></p><p><br/></p><p><br/></p>', '1393438568', '1430586118', '1', '1', '3', '5', null, null, null, null);
INSERT INTO `kl_config` VALUES ('89', 'MAIL_SMTP_FROMEMAIL', 'string', '发送来源的邮箱', '3', '', '', 'service@ainiku.com', '1430587033', '1436116015', '1', '1', '3', '99', '^[\\w-]+(\\.[\\w-]+)*@[\\w-]+(\\.[\\w-]+)+$', '邮箱格式正确', '邮箱格式不正确', '请输入正确格式的邮箱');
INSERT INTO `kl_config` VALUES ('70', 'DEFAULT_COLOR', 'select', '后台默认主题颜色', '2', 'default:默认主题\r\nblack:黑色主题\r\nblue:蓝色主题\r\ngreen:蓝绿主题', '', 'blue', '1411604388', '1446778246', '1', '1', '3', '7', '', '', '', '');
INSERT INTO `kl_config` VALUES ('66', 'SHUIYIN_IMG', 'picture', '水印图片', '4', '', '最好用png透明图片效果最好,上传水印之前请先关闭图片添加水印', '10483', '1410641391', '1433664930', '1', '1', '3', '4', null, null, null, null);
INSERT INTO `kl_config` VALUES ('67', 'SHUIYIN_ON', 'radio', '图片是否添加水印', '4', '0:不添加\r\n1:图片水印\r\n2:文字水印', '此处开启后全站上传图片的地方都会自动加上水印包括LOGO等', '2', '1410641505', '1433689525', '1', '1', '3', '7', null, null, null, null);
INSERT INTO `kl_config` VALUES ('68', 'SHUIYIN_POS', 'radio', '图片水印的位置', '4', 'left:左下角\r\nright:右下角\r\ncenter:正中间', '水印添加的位置,开启添加水印后才有效', 'right', '1410664014', '1433664931', '1', '1', '3', '5', null, null, null, null);
INSERT INTO `kl_config` VALUES ('51', 'OPEN_DRAFTBOX', 'select', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能', '新增文章时的草稿功能配置', '1', '1399479229', '1418382309', '1', '1', '3', '12', null, null, null, null);
INSERT INTO `kl_config` VALUES ('59', 'THIRD_CODE', 'textarea', '第三方统计代码', '1', '', '', '<script>\r\nvar _hmt = _hmt || [];\r\n(function() {\r\n  var hm = document.createElement(\"script\");\r\n  hm.src = \"//hm.baidu.com/hm.js?5ad8c61c3dbcd1fcfdcd9120ca2bbb87\";\r\n  var s = document.getElementsByTagName(\"script\")[0]; \r\n  s.parentNode.insertBefore(hm, s);\r\n})();\r\n</script>\r\n', '1409655494', '1418384212', '1', '1', '3', '15', null, null, null, null);
INSERT INTO `kl_config` VALUES ('61', 'MEMBER_ACTION_LOG', 'select', '记录用户操作行为日志', '2', '0:不记录\r\n1:记录', '开启后用户操作日志可能会太多请记得清理日志', '0', '1410211304', '1426153479', '1', '1', '3', '2', null, null, null, null);
INSERT INTO `kl_config` VALUES ('62', 'CONFIG_GROUP', 'textarea', '配置分组', '2', '', '', '1:基本\r\n4:网站\r\n3:邮件\r\n2:系统\r\n5:支付\r\n6:联系', '1410428926', '1427959220', '1', '1', '3', '3', null, null, null, null);
INSERT INTO `kl_config` VALUES ('63', 'THUMB_WIDTH', 'number', '缩略图宽度', '4', '', '', '150', '1410452648', '1418384066', '1', '1', '3', '2', null, null, null, null);
INSERT INTO `kl_config` VALUES ('64', 'THUMB_HEIGHT', 'number', '缩略图高度', '4', '', '', '150', '1410452682', '1418384050', '1', '1', '3', '1', null, null, null, null);
INSERT INTO `kl_config` VALUES ('65', 'SITE_LOGO', 'picture', '网站LOGO', '1', '', '网站的logo图标文件,请先关闭添加水印功能后再上传', '15640', '1410454536', '1418384207', '1', '1', '3', '4', null, null, null, null);
INSERT INTO `kl_config` VALUES ('69', 'SHUIYIN_TIAOJIAN', 'string', '添加水印的图片大小', '4', '', '当宽高都大于设置的值时才会添加水印', '400X300', '1410717155', '1433664933', '1', '1', '3', '6', null, null, null, null);
INSERT INTO `kl_config` VALUES ('71', 'WEBDOMIN', 'string', '网站主页地址', '4', '', '以http://开头结尾不带/', 'http://ainiku.loc', '1412149788', '1418119039', '1', '1', '3', '0', null, null, null, null);
INSERT INTO `kl_config` VALUES ('72', 'ALIPAYUNAME', 'string', '支付宝账号', '5', '', '', '735579768@qq.com', '1412149864', '1418384167', '1', '1', '3', '1', null, null, null, null);
INSERT INTO `kl_config` VALUES ('73', 'ALIPAYVERIFY', 'password', '支付宝检验码', '5', '', '', 'dpon93lktfivsvgmyhg3i0frycgab4sn', '1412149914', '1418384064', '1', '1', '3', '2', null, null, null, null);
INSERT INTO `kl_config` VALUES ('74', 'ALIPAYSAFEID', 'password', '合作者身份ID', '5', '', '', '2088002656310382', '1412149954', '1418384167', '1', '1', '3', '3', null, null, null, null);
INSERT INTO `kl_config` VALUES ('75', 'ALIPAYAPI', 'select', '选择接口类型', '5', 'shuang:使用标准双接口\r\ndanbao:使用担保交易接口\r\njishi:使用即时到帐交易接口', '', 'danbao', '1412150024', '1428658187', '1', '1', '3', '4', null, null, null, null);
INSERT INTO `kl_config` VALUES ('76', 'ATTACH_SITE', 'file', '网站帮助附件', '4', '', '', '', '0', '1425822202', '1', '1', '3', '99', null, null, null, null);
INSERT INTO `kl_config` VALUES ('77', 'MAIL_SMTP_EMAILSUBJECT', 'string', '网站默认邮件主题', '3', '', '邮件内容的简要说明', '爱你酷测试邮件', '0', '1430587846', '1', '1', '3', '99', null, null, null, null);
INSERT INTO `kl_config` VALUES ('78', 'MAIL_SMTP_FROMNAME', 'string', '邮件发送者名字', '3', '', '一般设置成网站的名字,会显示在邮件发件人列表中', '爱你酷', '0', '1430587825', '1', '1', '3', '99', null, null, null, null);
INSERT INTO `kl_config` VALUES ('79', 'DEFAULT_THEME', 'select', '网站前台默认主题', '4', 'default:默认主题模板\r\nvivo:步步高模板\r\nmedia:广告公司模板', '', 'default', '1425822141', '1449199340', '1', '1', '3', '99', '', '', '', '');
INSERT INTO `kl_config` VALUES ('80', 'TPL_REG', 'textarea', '对模板进行正则替换', '4', '', '使用 *******##********进行设置每一个规则要换行前面是正则后面是替换的字符串', '', '1426141886', '1426141900', '1', '1', '3', '99', null, null, null, null);
INSERT INTO `kl_config` VALUES ('81', 'DEFAULT_IMG', 'picture', '默认图片', '4', '', '网站图片标签没有图片时的默认图片', '/Public/Static/images/default.png', '1426143797', '1427540129', '1', '1', '3', '99', null, null, null, null);
INSERT INTO `kl_config` VALUES ('82', 'LOG_RECORD', 'select', '记录系统运行日志', '2', 'true:记录日志\r\nfalse:不记录日志', '', 'true', '1427360073', '1427360081', '1', '1', '3', '99', null, null, null, null);
INSERT INTO `kl_config` VALUES ('86', 'DATA_CACHE_TIME', 'number', '系统缓存时间', '2', '', '缓存过期时间,0表示永久缓存', '2', '1427439168', '1427959226', '1', '1', '3', '99', null, null, null, null);
INSERT INTO `kl_config` VALUES ('83', 'SITE_BANQUAN', 'string', '版权所有', '6', '', '', '企业之家', '1427365041', '1427365289', '1', '1', '3', '3', null, null, null, null);
INSERT INTO `kl_config` VALUES ('84', 'SITE_ADDRESS', 'string', '公司地址', '6', '', '', '郑州市金水区花园路159号罗马假日2-30层', '1427365087', '1427365288', '1', '1', '3', '2', null, null, null, null);
INSERT INTO `kl_config` VALUES ('85', 'SITE_MOBILE', 'string', '电话/固话', '6', '', '', '13633719215', '1427365144', '1427365287', '1', '1', '3', '1', null, null, null, null);
INSERT INTO `kl_config` VALUES ('87', 'MAIL_SMTP_TESTBTN', 'custom', '点击发送测试邮件', '3', 'testmail', '', '', '1430584150', '1430587869', '1', '1', '3', '100', null, null, null, null);
INSERT INTO `kl_config` VALUES ('88', 'MAIL_SMTP_TESTEMAIL', 'string', '测试接收邮箱', '3', '', '', '735579768@qq.com', '1430586057', '1430587811', '1', '1', '3', '99', null, null, null, null);
INSERT INTO `kl_config` VALUES ('90', 'SITE_PRELOAD', 'select', '网站图片预加载', '1', '0:关闭\r\n1:开启', '', '1', '1431579890', '1431579897', '1', '1', '3', '99', null, null, null, null);
INSERT INTO `kl_config` VALUES ('91', 'SHUIYIN_TEXT', 'string', '水印文字', '4', '', '', 'www.ainiku.com', '1433664744', '1433689531', '1', '1', '3', '3', null, null, null, null);
INSERT INTO `kl_config` VALUES ('92', 'IP_BLACKLIST', 'textarea', 'IP黑名单', '2', '', '被禁止访问的IP用“,”分隔', '', '1434517015', '1434519157', '1', '1', '3', '99', null, null, null, null);
INSERT INTO `kl_config` VALUES ('93', 'ADMIN_SHOW_TAB', 'radio', '后台操作视图', '2', '0:正常视图\r\n1:TAB视图', '', '1', '1444297582', '1444297708', '1', '1', '0', '0', '', '', '', '');

-- ----------------------------
-- Table structure for kl_consignee_address
-- ----------------------------
DROP TABLE IF EXISTS `kl_consignee_address`;
CREATE TABLE `kl_consignee_address` (
  `consignee_address_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `consignee_name` varchar(255) DEFAULT NULL,
  `consignee_mobile` varchar(255) DEFAULT NULL,
  `consignee_diqu` varchar(255) DEFAULT NULL,
  `consignee_detail` varchar(255) DEFAULT NULL,
  `consignee_youbian` varchar(255) DEFAULT NULL,
  `consignee_email` varchar(255) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`consignee_address_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_consignee_address
-- ----------------------------
INSERT INTO `kl_consignee_address` VALUES ('1', '1', '赵凯旋', '13633719216', '1,33,405,0', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1020室', '4675000', null, null, '1449192952');
INSERT INTO `kl_consignee_address` VALUES ('2', '1', '赵克立', '13633719215', '1,32,381,0', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '467500', null, null, '1449195431');
INSERT INTO `kl_consignee_address` VALUES ('3', '1', '赵克立', '13633719215', '16,198,1911,0', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '4675000', null, '0', '1449192944');
INSERT INTO `kl_consignee_address` VALUES ('4', '1', '赵克立', '13633719215', '16,198,1911,0', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '467500', null, '0', '1449192936');
INSERT INTO `kl_consignee_address` VALUES ('6', '1', '张三', '13589758685', '4,84,595,0', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '460000', '735579768@qq.com', '0', '1449282590');
INSERT INTO `kl_consignee_address` VALUES ('12', '1', '测试地址', '13633719215', '4,97,742,0', 'asdfasdfasdf', '89797987', '735579768@qq.com', '1449560758', '1449560758');

-- ----------------------------
-- Table structure for kl_file
-- ----------------------------
DROP TABLE IF EXISTS `kl_file`;
CREATE TABLE `kl_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `uid` int(11) unsigned NOT NULL,
  `srcname` varchar(50) NOT NULL,
  `destname` varchar(50) NOT NULL,
  `path` varchar(255) NOT NULL,
  `size` int(10) unsigned DEFAULT '0' COMMENT '文件大小',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- ----------------------------
-- Records of kl_file
-- ----------------------------
INSERT INTO `kl_file` VALUES ('33', '0', 'default.png', '142616971865427.png', '/Uploads/file/image/20150312/142616971865427.png', '20101', '1426169718');
INSERT INTO `kl_file` VALUES ('34', '1', 'new02.gif', '142655777353798.gif', '/Uploads/file/image/20150317/142655777353798.gif', '4975', '1426557773');
INSERT INTO `kl_file` VALUES ('38', '1', '142726730561219.jpg', '142754239735364.jpg', '/Uploads/file/image/20150328/142754239735364.jpg', '26172', '1427542397');

-- ----------------------------
-- Table structure for kl_goods
-- ----------------------------
DROP TABLE IF EXISTS `kl_goods`;
CREATE TABLE `kl_goods` (
  `goods_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(50) unsigned DEFAULT NULL,
  `update_time` int(10) unsigned DEFAULT '0',
  `title` varchar(50) DEFAULT NULL,
  `content` longtext,
  `pic` int(10) DEFAULT '0',
  `xc` varchar(50) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `create_time` int(10) unsigned DEFAULT '0',
  `price` int(10) DEFAULT '0',
  `sale_num` int(10) DEFAULT '0',
  `stock` int(10) DEFAULT '0',
  `goods_type_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_goods
-- ----------------------------
INSERT INTO `kl_goods` VALUES ('1', '0', '1450148887', '测试文件测试文件测试文件', '<p>测试文件测试文件测试文件测试文件测试文件测试文件测试文件测试文件测试文件测试文件测试文件测试文件测试文件测试文件测试文件测试文件<img src=\"/Uploads/image/20150828/1440727929997132.png\"/></p><pre class=\"brush:php;toolbar:true\">你好\r\nif(!defined(&quot;ACCESS_ROOT&quot;))die(&quot;Invalid&nbsp;access&quot;);\r\nclass&nbsp;GoodsController&nbsp;extends&nbsp;HomeController&nbsp;{\r\n&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;index(){\r\n$Ip&nbsp;=&nbsp;new&nbsp;\\Org\\Net\\IpLocation();&nbsp;//&nbsp;实例化类\r\n$location&nbsp;=&nbsp;$Ip-&gt;getlocation(&#39;127.0.0.1&#39;);&nbsp;//&nbsp;\r\n&nbsp;&nbsp;$this-&gt;display();\r\n&nbsp;&nbsp;&nbsp;&nbsp;}\r\n	function&nbsp;detail($goods_id){\r\n		if(empty($goods_id))$this-&gt;_empty();\r\n		$info=M(&#39;Goods&#39;)-&gt;find($goods_id);\r\n		$this-&gt;assign(&#39;info&#39;,$info);\r\n		$this-&gt;display();\r\n		}</pre><p><br/></p>', '15639', '15634', '0,1,2', '1', '0', '100', '0', '10', '1');

-- ----------------------------
-- Table structure for kl_goods_attribute
-- ----------------------------
DROP TABLE IF EXISTS `kl_goods_attribute`;
CREATE TABLE `kl_goods_attribute` (
  `goods_attribute_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) unsigned NOT NULL,
  `goods_type_attribute_id` int(11) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`goods_attribute_id`)
) ENGINE=MyISAM AUTO_INCREMENT=110 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_goods_attribute
-- ----------------------------
INSERT INTO `kl_goods_attribute` VALUES ('103', '1', '2', 'jiage', '100-500', '1448201238');
INSERT INTO `kl_goods_attribute` VALUES ('102', '1', '1', 'fenbianlv', '300X200', '1448201238');
INSERT INTO `kl_goods_attribute` VALUES ('104', '1', '1', 'fenbianlv', '300X200', '1450079626');
INSERT INTO `kl_goods_attribute` VALUES ('105', '1', '2', 'jiage', '100-500', '1450079626');
INSERT INTO `kl_goods_attribute` VALUES ('106', '1', '1', 'fenbianlv', '300X200', '1450148810');
INSERT INTO `kl_goods_attribute` VALUES ('107', '1', '2', 'jiage', '100-500', '1450148810');
INSERT INTO `kl_goods_attribute` VALUES ('108', '1', '1', 'fenbianlv', '300X200', '1450148887');
INSERT INTO `kl_goods_attribute` VALUES ('109', '1', '2', 'jiage', '100-500', '1450148887');

-- ----------------------------
-- Table structure for kl_goods_type
-- ----------------------------
DROP TABLE IF EXISTS `kl_goods_type`;
CREATE TABLE `kl_goods_type` (
  `goods_type_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `table` varchar(50) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`goods_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_goods_type
-- ----------------------------
INSERT INTO `kl_goods_type` VALUES ('1', '手机', null, '1409763381', '1446779937', '0', '1');
INSERT INTO `kl_goods_type` VALUES ('3', '服装', null, '1409846233', '1409846233', '0', '1');
INSERT INTO `kl_goods_type` VALUES ('4', '基本', null, '0', '0', '0', '1');

-- ----------------------------
-- Table structure for kl_goods_type_attribute
-- ----------------------------
DROP TABLE IF EXISTS `kl_goods_type_attribute`;
CREATE TABLE `kl_goods_type_attribute` (
  `goods_type_attribute_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `goods_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `note` varchar(50) NOT NULL,
  `extra` varchar(255) NOT NULL,
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `type` varchar(50) NOT NULL,
  `value` varchar(255) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `extranote` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`goods_type_attribute_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_goods_type_attribute
-- ----------------------------
INSERT INTO `kl_goods_type_attribute` VALUES ('1', '1', 'fenbianlv', '分辨率', '', '300X200,300X600', '3', 'select', '1', '1409765675', '1448187055', '0', '1', '0');
INSERT INTO `kl_goods_type_attribute` VALUES ('2', '1', 'jiage', '价格', '', '100-500,500-1000,1000-10000', '3', 'select', '', '1409805922', '1429433228', '1', '1', '0');
INSERT INTO `kl_goods_type_attribute` VALUES ('3', '3', 'yanse', '颜色', '', '红色,绿色,蓝色', '3', 'select', '', '1409848423', '1435284365', '0', '1', '0');

-- ----------------------------
-- Table structure for kl_hooks
-- ----------------------------
DROP TABLE IF EXISTS `kl_hooks`;
CREATE TABLE `kl_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(12) NOT NULL,
  `mark` char(255) DEFAULT NULL,
  `pluginid` varchar(255) DEFAULT NULL,
  `descr` varchar(255) DEFAULT NULL,
  `type` char(50) DEFAULT 'other',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_hooks
-- ----------------------------
INSERT INTO `kl_hooks` VALUES ('1', '测试钩子', 'Test', '18', '测试钩子1', null, '1');
INSERT INTO `kl_hooks` VALUES ('4', '系统环境信息模板', 'AdminInfo', '7,4,25,26,32', '后台首页扩展钩子', 'system', '1');
INSERT INTO `kl_hooks` VALUES ('3', 'erweima', 'Erweima', '22', '生成二维码', null, '1');
INSERT INTO `kl_hooks` VALUES ('6', 'html编辑器', 'Editor', '7,6', 'html在线编辑器', 'system', '1');
INSERT INTO `kl_hooks` VALUES ('7', '文章详情页钩子', 'Articlefooter', '20', '文章详情页内容下面钩子', 'other', '1');
INSERT INTO `kl_hooks` VALUES ('8', '顶部导航钩子', 'Topnav', '27', '页面顶部钩子', 'other', '1');

-- ----------------------------
-- Table structure for kl_link
-- ----------------------------
DROP TABLE IF EXISTS `kl_link`;
CREATE TABLE `kl_link` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `url` varchar(50) NOT NULL,
  `pic` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_link
-- ----------------------------
INSERT INTO `kl_link` VALUES ('1', '博客', 'http://www.zhaokeli.com', '0', '0', '1', '0', '1435156623');
INSERT INTO `kl_link` VALUES ('4', '汝州吧', 'http://www.ruzhouba.com', '0', '1', '1', '1435222761', '1435222761');
INSERT INTO `kl_link` VALUES ('5', 'kanqq', 'http://www.kanqq.com/', '0', '1', '0', '1435367252', '1435367252');
INSERT INTO `kl_link` VALUES ('6', '个性签名', 'http://www.qqgexingqianming.com/', '0', '1', '0', '1435367410', '1435367410');

-- ----------------------------
-- Table structure for kl_member
-- ----------------------------
DROP TABLE IF EXISTS `kl_member`;
CREATE TABLE `kl_member` (
  `member_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `openid` varchar(50) DEFAULT NULL,
  `account` varchar(20) NOT NULL,
  `member_group_id` int(11) unsigned NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `diqu` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `email_activate` tinyint(1) DEFAULT '0',
  `reg_ip` varchar(50) DEFAULT NULL,
  `last_login_ip` varchar(50) DEFAULT NULL,
  `last_login_adr` varchar(50) DEFAULT NULL,
  `login` int(11) DEFAULT '0' COMMENT '登陆次数',
  `status` tinyint(4) DEFAULT '1',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `repassword` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_member
-- ----------------------------
INSERT INTO `kl_member` VALUES ('1', null, '100001', '1', 'admin', '0c72320405722be71ba98ade695850b5', '爱你酷', null, '13633719215', '735579768@qq.com', '1', null, '127.0.0.1', '保留地址', '373', '1', '1416647935', '1450147747', 'adminrootkl', null);
INSERT INTO `kl_member` VALUES ('4', null, '100002', '2', 'test', '0c72320405722be71ba98ade695850b5', null, null, '', '528759373@qq.com', '0', '2130706433', '127.0.0.1', '保留地址', '8', '1', '1417363401', '1445676802', 'adminrootkl', null);
INSERT INTO `kl_member` VALUES ('5', null, '100003', '2', '', '', null, null, null, '', '0', null, null, null, '0', '1', '1426937454', '1426937454', null, null);
INSERT INTO `kl_member` VALUES ('6', null, '100004', '2', '', '', null, null, null, '', '0', null, null, null, '0', '1', '1426937722', '1426937722', null, null);
INSERT INTO `kl_member` VALUES ('7', null, '100005', '2', '', '', null, null, '', '', '0', null, null, null, '0', '1', '1426937910', '1446874773', null, null);
INSERT INTO `kl_member` VALUES ('8', '372A677CC6CC64CE9EB3E9B30F79AF17', '82839355', '2', '٩(•̮̮̃•̃)─═SMAIL╄→', '', '٩(•̮̮̃•̃)─═SMAIL╄→', null, null, null, '0', null, '1.192.110.180', null, '0', '1', '1438216149', '1446875151', null, null);
INSERT INTO `kl_member` VALUES ('9', '7D8BAC10D5E29B392515CD99703A246F', '64571838', '2', '巧克力', null, '巧克力', '16,203,2034,23811', '1', '735579768@qq.com', '0', null, '127.0.0.1', null, '0', '1', '1428379778', '1446875150', null, null);
INSERT INTO `kl_member` VALUES ('10', null, '22733154', '3', 'bianji', '046c3445490145529d9b6f8aa82f1fe9', '', '16,198,1911,0', '13633719217', '7355797682@qq.com', '0', '2130706433', '127.0.0.1', '本机地址', '1', '1', '1433162939', '1450084058', null, '');

-- ----------------------------
-- Table structure for kl_member_group
-- ----------------------------
DROP TABLE IF EXISTS `kl_member_group`;
CREATE TABLE `kl_member_group` (
  `member_group_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `auth` text,
  `admin_index` varchar(50) DEFAULT '默认后台登陆主页',
  `noaccessurl` text,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `is_adminlogin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`member_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_member_group
-- ----------------------------
INSERT INTO `kl_member_group` VALUES ('1', '超级管理员', '[\"1\",\"42\",\"3\",\"2\",\"27\",\"28\",\"29\",\"30\",\"31\",\"4\",\"26\",\"32\",\"33\",\"34\",\"35\",\"36\",\"5\",\"37\",\"38\",\"39\",\"40\",\"6\",\"22\",\"23\",\"24\",\"25\",\"7\",\"18\",\"19\",\"20\",\"21\",\"8\",\"14\",\"15\",\"16\",\"17\",\"9\",\"10\",\"11\",\"12\",\"13\",\"41\",\"49\",\"50\",\"51\",\"52\",\"53\",\"54\",\"55\",\"56\",\"57\",\"58\",\"43\",\"44\",\"45\",\"46\",\"47\",\"48\",\"63\",\"59\",\"60\",\"61\",\"62\",\"64\",\"65\",\"66\",\"67\",\"68\",\"69\",\"70\",\"71\",\"72\",\"73\",\"74\",\"75\",\"76\"]', 'Index/index', '', '1417333548', '1447731815', '1', '1');
INSERT INTO `kl_member_group` VALUES ('2', '会员', '[\"1\",\"42\",\"3\",\"2\",\"27\",\"28\",\"29\",\"30\",\"31\",\"4\",\"26\",\"41\",\"50\",\"51\",\"52\",\"53\",\"54\",\"57\",\"58\",\"43\",\"45\",\"46\",\"47\",\"48\"]', 'Index/index', '添加分类:category/add', '1417364973', '1446875169', '1', '0');
INSERT INTO `kl_member_group` VALUES ('3', '网站编辑', '[\"78\",\"79\",\"80\",\"81\",\"69\",\"70\",\"71\",\"72\",\"73\",\"74\",\"75\",\"76\",\"77\",\"106\",\"86\",\"87\",\"88\",\"89\",\"90\",\"91\",\"92\",\"93\",\"107\",\"108\",\"109\",\"1\",\"42\",\"82\"]', 'Index/index', '', '1425052169', '1446875171', '1', '1');

-- ----------------------------
-- Table structure for kl_member_log
-- ----------------------------
DROP TABLE IF EXISTS `kl_member_log`;
CREATE TABLE `kl_member_log` (
  `member_log_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) unsigned NOT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `adr` varchar(255) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`member_log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=410 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_member_log
-- ----------------------------
INSERT INTO `kl_member_log` VALUES ('72', '1', '127.0.0.1', '本机地址', '1425460557');
INSERT INTO `kl_member_log` VALUES ('77', '1', '127.0.0.1', '本机地址', '1425788018');
INSERT INTO `kl_member_log` VALUES ('13', '2', '', 'IANA保留地址', '1410204690');
INSERT INTO `kl_member_log` VALUES ('76', '1', '127.0.0.1', '本机地址', '1425555682');
INSERT INTO `kl_member_log` VALUES ('75', '4', '127.0.0.1', '本机地址', '1425472359');
INSERT INTO `kl_member_log` VALUES ('74', '1', '127.0.0.1', '本机地址', '1425470675');
INSERT INTO `kl_member_log` VALUES ('73', '1', '127.0.0.1', '本机地址', '1425464479');
INSERT INTO `kl_member_log` VALUES ('81', '1', '127.0.0.1', '本机地址', '1426086624');
INSERT INTO `kl_member_log` VALUES ('80', '1', '127.0.0.1', '本机地址', '1425985837');
INSERT INTO `kl_member_log` VALUES ('79', '1', '127.0.0.1', '本机地址', '1425819464');
INSERT INTO `kl_member_log` VALUES ('78', '1', '127.0.0.1', '本机地址', '1425788196');
INSERT INTO `kl_member_log` VALUES ('53', '22', '', 'IANA保留地址', '1411904576');
INSERT INTO `kl_member_log` VALUES ('82', '1', '127.0.0.1', '本机地址', '1426169400');
INSERT INTO `kl_member_log` VALUES ('83', '1', '127.0.0.1', '本机地址', '1426220961');
INSERT INTO `kl_member_log` VALUES ('84', '1', '127.0.0.1', '本机地址', '1426252046');
INSERT INTO `kl_member_log` VALUES ('85', '1', '127.0.0.1', '本机地址', '1426376563');
INSERT INTO `kl_member_log` VALUES ('86', '1', '127.0.0.1', '本机地址', '1426380216');
INSERT INTO `kl_member_log` VALUES ('87', '1', '127.0.0.1', '本机地址', '1426390686');
INSERT INTO `kl_member_log` VALUES ('88', '1', '127.0.0.1', '本机地址', '1426666608');
INSERT INTO `kl_member_log` VALUES ('89', '1', '127.0.0.1', '本机地址', '1426837193');
INSERT INTO `kl_member_log` VALUES ('90', '1', '127.0.0.1', '本机地址', '1426908107');
INSERT INTO `kl_member_log` VALUES ('91', '1', '127.0.0.1', '本机地址', '1426929872');
INSERT INTO `kl_member_log` VALUES ('92', '1', '127.0.0.1', '本机地址', '1427180887');
INSERT INTO `kl_member_log` VALUES ('93', '1', '127.0.0.1', '本机地址', '1427260074');
INSERT INTO `kl_member_log` VALUES ('94', '1', '127.0.0.1', '本机地址', '1427279464');
INSERT INTO `kl_member_log` VALUES ('95', '1', '127.0.0.1', '本机地址', '1427286444');
INSERT INTO `kl_member_log` VALUES ('96', '1', '127.0.0.1', '本机地址', '1427287771');
INSERT INTO `kl_member_log` VALUES ('97', '1', '127.0.0.1', '本机地址', '1427344985');
INSERT INTO `kl_member_log` VALUES ('98', '1', '127.0.0.1', '本机地址', '1427346266');
INSERT INTO `kl_member_log` VALUES ('99', '1', '127.0.0.1', '本机地址', '1427346743');
INSERT INTO `kl_member_log` VALUES ('100', '1', '127.0.0.1', '本机地址', '1427350913');
INSERT INTO `kl_member_log` VALUES ('101', '1', '127.0.0.1', '本机地址', '1427501981');
INSERT INTO `kl_member_log` VALUES ('102', '1', '127.0.0.1', '本机地址', '1427511311');
INSERT INTO `kl_member_log` VALUES ('103', '1', '127.0.0.1', '本机地址', '1427514028');
INSERT INTO `kl_member_log` VALUES ('104', '1', '127.0.0.1', '本机地址', '1427521447');
INSERT INTO `kl_member_log` VALUES ('105', '1', '127.0.0.1', '本机地址', '1427589384');
INSERT INTO `kl_member_log` VALUES ('106', '1', '127.0.0.1', '本机地址', '1427608614');
INSERT INTO `kl_member_log` VALUES ('107', '1', '127.0.0.1', '本机地址', '1427907361');
INSERT INTO `kl_member_log` VALUES ('108', '1', '127.0.0.1', '本机地址', '1427958329');
INSERT INTO `kl_member_log` VALUES ('109', '1', '127.0.0.1', '本机地址', '1428026248');
INSERT INTO `kl_member_log` VALUES ('110', '1', '127.0.0.1', '本机地址', '1428084181');
INSERT INTO `kl_member_log` VALUES ('111', '1', '127.0.0.1', '本机地址', '1428128799');
INSERT INTO `kl_member_log` VALUES ('112', '1', '127.0.0.1', '本机地址', '1428223376');
INSERT INTO `kl_member_log` VALUES ('113', '1', '127.0.0.1', '本机地址', '1428244801');
INSERT INTO `kl_member_log` VALUES ('114', '1', '127.0.0.1', '本机地址', '1428323566');
INSERT INTO `kl_member_log` VALUES ('115', '1', '127.0.0.1', '本机地址', '1428323755');
INSERT INTO `kl_member_log` VALUES ('116', '1', '127.0.0.1', '本机地址', '1428323852');
INSERT INTO `kl_member_log` VALUES ('117', '1', '127.0.0.1', '本机地址', '1428323935');
INSERT INTO `kl_member_log` VALUES ('118', '1', null, '本机地址', '1428326968');
INSERT INTO `kl_member_log` VALUES ('119', '1', null, '本机地址', '1428327338');
INSERT INTO `kl_member_log` VALUES ('120', '1', null, '本机地址', '1428327445');
INSERT INTO `kl_member_log` VALUES ('121', '1', null, '本机地址', '1428327515');
INSERT INTO `kl_member_log` VALUES ('122', '1', null, '本机地址', '1428327547');
INSERT INTO `kl_member_log` VALUES ('123', '1', '127.0.0.1', '本机地址', '1428396490');
INSERT INTO `kl_member_log` VALUES ('124', '1', '127.0.0.1', '本机地址', '1428421967');
INSERT INTO `kl_member_log` VALUES ('125', '1', '127.0.0.1', '本机地址', '1428422195');
INSERT INTO `kl_member_log` VALUES ('126', '1', '127.0.0.1', '本机地址', '1428465037');
INSERT INTO `kl_member_log` VALUES ('127', '1', '127.0.0.1', '本机地址', '1428657692');
INSERT INTO `kl_member_log` VALUES ('128', '1', '127.0.0.1', '本机地址', '1428723006');
INSERT INTO `kl_member_log` VALUES ('129', '1', '127.0.0.1', '本机地址', '1428823581');
INSERT INTO `kl_member_log` VALUES ('130', '1', '127.0.0.1', '本机地址', '1428905012');
INSERT INTO `kl_member_log` VALUES ('131', '1', '127.0.0.1', '本机地址', '1428997728');
INSERT INTO `kl_member_log` VALUES ('132', '1', '127.0.0.1', '本机地址', '1429081873');
INSERT INTO `kl_member_log` VALUES ('133', '1', '127.0.0.1', '本机地址', '1429081942');
INSERT INTO `kl_member_log` VALUES ('134', '1', '127.0.0.1', '本机地址', '1429342240');
INSERT INTO `kl_member_log` VALUES ('135', '1', '127.0.0.1', '本机地址', '1429497587');
INSERT INTO `kl_member_log` VALUES ('136', '1', '127.0.0.1', '本机地址', '1429667478');
INSERT INTO `kl_member_log` VALUES ('137', '1', '127.0.0.1', '本机地址', '1429838017');
INSERT INTO `kl_member_log` VALUES ('144', '1', '127.0.0.1', '本机地址', '1430625952');
INSERT INTO `kl_member_log` VALUES ('139', '1', '127.0.0.1', '本机地址', '1430184951');
INSERT INTO `kl_member_log` VALUES ('140', '1', '127.0.0.1', '本机地址', '1430273335');
INSERT INTO `kl_member_log` VALUES ('141', '1', '127.0.0.1', '本机地址', '1430318625');
INSERT INTO `kl_member_log` VALUES ('142', '1', '127.0.0.1', '本机地址', '1430468575');
INSERT INTO `kl_member_log` VALUES ('143', '1', '127.0.0.1', '本机地址', '1430496682');
INSERT INTO `kl_member_log` VALUES ('145', '1', '127.0.0.1', '本机地址', '1430729851');
INSERT INTO `kl_member_log` VALUES ('146', '1', '127.0.0.1', '本机地址', '1430754677');
INSERT INTO `kl_member_log` VALUES ('147', '1', '127.0.0.1', '本机地址', '1430813736');
INSERT INTO `kl_member_log` VALUES ('148', '1', '127.0.0.1', '本机地址', '1430820891');
INSERT INTO `kl_member_log` VALUES ('149', '1', '127.0.0.1', '本机地址', '1430882709');
INSERT INTO `kl_member_log` VALUES ('150', '1', '127.0.0.1', '本机地址', '1430891697');
INSERT INTO `kl_member_log` VALUES ('151', '1', '127.0.0.1', '本机地址', '1430899835');
INSERT INTO `kl_member_log` VALUES ('152', '1', '127.0.0.1', '本机地址', '1430932274');
INSERT INTO `kl_member_log` VALUES ('153', '1', '127.0.0.1', '本机地址', '1430984958');
INSERT INTO `kl_member_log` VALUES ('154', '1', '127.0.0.1', '本机地址', '1431001075');
INSERT INTO `kl_member_log` VALUES ('155', '1', '127.0.0.1', '本机地址', '1431015107');
INSERT INTO `kl_member_log` VALUES ('156', '1', '127.0.0.1', '本机地址', '1431015711');
INSERT INTO `kl_member_log` VALUES ('157', '1', '127.0.0.1', '本机地址', '1431015842');
INSERT INTO `kl_member_log` VALUES ('158', '1', '127.0.0.1', '本机地址', '1431024824');
INSERT INTO `kl_member_log` VALUES ('159', '1', '127.0.0.1', '本机地址', '1431177933');
INSERT INTO `kl_member_log` VALUES ('160', '1', '127.0.0.1', '本机地址', '1431179620');
INSERT INTO `kl_member_log` VALUES ('161', '1', '127.0.0.1', '本机地址', '1431179706');
INSERT INTO `kl_member_log` VALUES ('162', '1', '127.0.0.1', '本机地址', '1431179828');
INSERT INTO `kl_member_log` VALUES ('163', '1', '127.0.0.1', '本机地址', '1431179941');
INSERT INTO `kl_member_log` VALUES ('164', '1', '127.0.0.1', '本机地址', '1431180023');
INSERT INTO `kl_member_log` VALUES ('165', '1', '127.0.0.1', '本机地址', '1431186009');
INSERT INTO `kl_member_log` VALUES ('166', '1', '127.0.0.1', '本机地址', '1431251965');
INSERT INTO `kl_member_log` VALUES ('167', '1', '127.0.0.1', '本机地址', '1431831701');
INSERT INTO `kl_member_log` VALUES ('168', '1', '127.0.0.1', '本机地址', '1431837275');
INSERT INTO `kl_member_log` VALUES ('169', '1', '127.0.0.1', '本机地址', '1431837459');
INSERT INTO `kl_member_log` VALUES ('170', '1', '127.0.0.1', '本机地址', '1431838510');
INSERT INTO `kl_member_log` VALUES ('171', '1', '127.0.0.1', '本机地址', '1431839955');
INSERT INTO `kl_member_log` VALUES ('172', '1', '127.0.0.1', '本机地址', '1431840241');
INSERT INTO `kl_member_log` VALUES ('173', '1', null, '本机地址', '1431840281');
INSERT INTO `kl_member_log` VALUES ('174', '1', '127.0.0.1', '本机地址', '1432127919');
INSERT INTO `kl_member_log` VALUES ('175', '1', '127.0.0.1', '本机地址', '1432218854');
INSERT INTO `kl_member_log` VALUES ('176', '1', '127.0.0.1', '本机地址', '1432228953');
INSERT INTO `kl_member_log` VALUES ('177', '1', '127.0.0.1', '本机地址', '1432393351');
INSERT INTO `kl_member_log` VALUES ('178', '1', '127.0.0.1', '本机地址', '1432393944');
INSERT INTO `kl_member_log` VALUES ('179', '1', '127.0.0.1', '本机地址', '1432422489');
INSERT INTO `kl_member_log` VALUES ('180', '1', '127.0.0.1', '本机地址', '1432524351');
INSERT INTO `kl_member_log` VALUES ('181', '1', '127.0.0.1', '本机地址', '1432560930');
INSERT INTO `kl_member_log` VALUES ('182', '1', '127.0.0.1', '本机地址', '1432650685');
INSERT INTO `kl_member_log` VALUES ('183', '1', '127.0.0.1', '本机地址', '1432705953');
INSERT INTO `kl_member_log` VALUES ('184', '1', '127.0.0.1', '本机地址', '1432810146');
INSERT INTO `kl_member_log` VALUES ('185', '1', '127.0.0.1', '本机地址', '1432892610');
INSERT INTO `kl_member_log` VALUES ('186', '1', '127.0.0.1', '本机地址', '1432973973');
INSERT INTO `kl_member_log` VALUES ('187', '1', '127.0.0.1', '本机地址', '1433061570');
INSERT INTO `kl_member_log` VALUES ('188', '1', '127.0.0.1', '本机地址', '1433161256');
INSERT INTO `kl_member_log` VALUES ('189', '10', '127.0.0.1', '本机地址', '1433163032');
INSERT INTO `kl_member_log` VALUES ('190', '1', '127.0.0.1', '本机地址', '1433253279');
INSERT INTO `kl_member_log` VALUES ('191', '1', '127.0.0.1', '本机地址', '1433330018');
INSERT INTO `kl_member_log` VALUES ('192', '1', '127.0.0.1', '本机地址', '1433510567');
INSERT INTO `kl_member_log` VALUES ('193', '1', '127.0.0.1', '本机地址', '1433608941');
INSERT INTO `kl_member_log` VALUES ('194', '1', '127.0.0.1', '本机地址', '1433644017');
INSERT INTO `kl_member_log` VALUES ('195', '1', '127.0.0.1', '本机地址', '1433658532');
INSERT INTO `kl_member_log` VALUES ('196', '1', '127.0.0.1', '本机地址', '1433773497');
INSERT INTO `kl_member_log` VALUES ('197', '1', '115.61.79.205', '河南省驻马店市联通', '1433903973');
INSERT INTO `kl_member_log` VALUES ('198', '1', '42.233.252.12', '河南省平顶山市联通', '1434159069');
INSERT INTO `kl_member_log` VALUES ('199', '1', '42.233.252.12', '河南省平顶山市联通', '1434164703');
INSERT INTO `kl_member_log` VALUES ('200', '1', '42.233.252.12', '河南省平顶山市联通', '1434183745');
INSERT INTO `kl_member_log` VALUES ('201', '1', '42.233.252.12', '河南省平顶山市联通', '1434190390');
INSERT INTO `kl_member_log` VALUES ('202', '1', '42.233.252.12', '河南省平顶山市联通', '1434194106');
INSERT INTO `kl_member_log` VALUES ('203', '1', '42.233.252.12', '河南省平顶山市联通', '1434208215');
INSERT INTO `kl_member_log` VALUES ('204', '1', '42.233.252.12', '河南省平顶山市联通', '1434263451');
INSERT INTO `kl_member_log` VALUES ('205', '1', '42.233.252.12', '河南省平顶山市联通', '1434287197');
INSERT INTO `kl_member_log` VALUES ('206', '1', '42.233.252.12', '河南省平顶山市联通', '1434297380');
INSERT INTO `kl_member_log` VALUES ('207', '1', '42.225.174.163', '河南省平顶山市联通', '1434334525');
INSERT INTO `kl_member_log` VALUES ('208', '1', '42.225.174.163', '河南省平顶山市联通', '1434367872');
INSERT INTO `kl_member_log` VALUES ('209', '1', '115.61.74.42', '河南省郑州市联通', '1434445391');
INSERT INTO `kl_member_log` VALUES ('210', '1', '115.61.74.42', '河南省郑州市联通', '1434456719');
INSERT INTO `kl_member_log` VALUES ('211', '1', '42.233.235.155', '河南省平顶山市联通', '1434502324');
INSERT INTO `kl_member_log` VALUES ('212', '1', '42.233.235.155', '河南省平顶山市联通', '1434506813');
INSERT INTO `kl_member_log` VALUES ('213', '1', '42.233.235.155', '河南省平顶山市联通', '1434516854');
INSERT INTO `kl_member_log` VALUES ('214', '1', '127.0.0.1', '保留地址', '1434528268');
INSERT INTO `kl_member_log` VALUES ('215', '1', '222.142.94.103', '河南省平顶山市联通', '1434534928');
INSERT INTO `kl_member_log` VALUES ('216', '1', '221.14.233.172', '河南省郑州市/义马市联通', '1434551088');
INSERT INTO `kl_member_log` VALUES ('217', '1', '221.14.233.172', '河南省郑州市/义马市联通', '1434589384');
INSERT INTO `kl_member_log` VALUES ('218', '1', '221.14.233.172', '河南省郑州市/义马市联通', '1434607643');
INSERT INTO `kl_member_log` VALUES ('219', '1', '127.0.0.1', '保留地址', '1434613248');
INSERT INTO `kl_member_log` VALUES ('220', '1', '221.14.233.172', '河南省郑州市/义马市联通', '1434637793');
INSERT INTO `kl_member_log` VALUES ('221', '1', '221.14.233.172', '河南省郑州市/义马市联通', '1434680243');
INSERT INTO `kl_member_log` VALUES ('222', '1', '221.14.233.172', '河南省郑州市/义马市联通', '1434683812');
INSERT INTO `kl_member_log` VALUES ('223', '1', '221.14.233.172', '河南省郑州市/义马市联通', '1434689235');
INSERT INTO `kl_member_log` VALUES ('224', '1', '221.14.233.172', '河南省郑州市/义马市联通', '1434713969');
INSERT INTO `kl_member_log` VALUES ('225', '1', '221.14.233.172', '河南省郑州市/义马市联通', '1434731084');
INSERT INTO `kl_member_log` VALUES ('226', '1', '115.61.79.207', '河南省驻马店市联通', '1434765919');
INSERT INTO `kl_member_log` VALUES ('227', '1', '115.61.79.207', '河南省驻马店市联通', '1434776982');
INSERT INTO `kl_member_log` VALUES ('228', '1', '115.61.79.207', '河南省驻马店市联通', '1434785189');
INSERT INTO `kl_member_log` VALUES ('229', '1', '115.61.79.207', '河南省郑州市联通', '1434799794');
INSERT INTO `kl_member_log` VALUES ('230', '1', '115.61.79.207', '河南省郑州市联通', '1434811020');
INSERT INTO `kl_member_log` VALUES ('231', '1', '115.61.79.207', '河南省郑州市联通', '1434815324');
INSERT INTO `kl_member_log` VALUES ('232', '1', '115.61.79.207', '河南省郑州市联通', '1434845666');
INSERT INTO `kl_member_log` VALUES ('233', '1', '115.61.79.207', '河南省郑州市联通', '1434868029');
INSERT INTO `kl_member_log` VALUES ('234', '1', '115.61.79.207', '河南省郑州市联通', '1434883232');
INSERT INTO `kl_member_log` VALUES ('235', '1', '42.233.193.35', '河南省平顶山市联通', '1434897861');
INSERT INTO `kl_member_log` VALUES ('236', '1', '127.0.0.1', '保留地址', '1434901517');
INSERT INTO `kl_member_log` VALUES ('237', '1', '42.233.193.35', '河南省平顶山市联通', '1434931743');
INSERT INTO `kl_member_log` VALUES ('238', '1', '42.233.193.35', '河南省平顶山市联通', '1434936939');
INSERT INTO `kl_member_log` VALUES ('239', '1', '127.0.0.1', '保留地址', '1434960444');
INSERT INTO `kl_member_log` VALUES ('240', '1', '219.156.251.177', '河南省平顶山市联通', '1434964313');
INSERT INTO `kl_member_log` VALUES ('241', '1', '219.156.251.177', '河南省平顶山市联通', '1434991964');
INSERT INTO `kl_member_log` VALUES ('242', '1', '219.156.251.177', '河南省平顶山市联通', '1435018845');
INSERT INTO `kl_member_log` VALUES ('243', '1', '127.0.0.1', '保留地址', '1435018763');
INSERT INTO `kl_member_log` VALUES ('244', '1', '219.156.251.177', '河南省平顶山市联通', '1435046298');
INSERT INTO `kl_member_log` VALUES ('245', '1', '219.156.251.177', '河南省平顶山市联通', '1435124724');
INSERT INTO `kl_member_log` VALUES ('246', '1', '127.0.0.1', '保留地址', '1435130773');
INSERT INTO `kl_member_log` VALUES ('247', '1', '219.156.251.177', '河南省平顶山市联通', '1435141235');
INSERT INTO `kl_member_log` VALUES ('248', '1', '127.0.0.1', '保留地址', '1435153239');
INSERT INTO `kl_member_log` VALUES ('249', '1', '219.156.251.177', '河南省平顶山市联通', '1435155619');
INSERT INTO `kl_member_log` VALUES ('250', '1', '123.15.190.20', '河南省新乡市联通', '1435207284');
INSERT INTO `kl_member_log` VALUES ('251', '1', '123.15.190.20', '河南省新乡市联通', '1435222707');
INSERT INTO `kl_member_log` VALUES ('252', '1', '123.15.190.20', '河南省新乡市联通', '1435277767');
INSERT INTO `kl_member_log` VALUES ('253', '1', '127.0.0.1', '保留地址', '1435278218');
INSERT INTO `kl_member_log` VALUES ('254', '1', '123.15.190.20', '河南省新乡市联通', '1435286544');
INSERT INTO `kl_member_log` VALUES ('255', '1', '123.15.190.20', '河南省新乡市联通', '1435324909');
INSERT INTO `kl_member_log` VALUES ('256', '1', '123.15.190.20', '河南省新乡市联通', '1435364660');
INSERT INTO `kl_member_log` VALUES ('257', '1', '123.15.190.20', '河南省新乡市联通', '1435367202');
INSERT INTO `kl_member_log` VALUES ('258', '1', '123.15.190.20', '河南省新乡市联通', '1435375662');
INSERT INTO `kl_member_log` VALUES ('259', '1', '123.15.190.20', '河南省新乡市联通', '1435379435');
INSERT INTO `kl_member_log` VALUES ('260', '1', '123.15.190.20', '河南省新乡市联通', '1435384831');
INSERT INTO `kl_member_log` VALUES ('261', '1', '123.15.190.20', '河南省新乡市联通', '1435396904');
INSERT INTO `kl_member_log` VALUES ('262', '1', '123.15.190.20', '河南省新乡市联通', '1435417926');
INSERT INTO `kl_member_log` VALUES ('263', '1', '123.15.190.20', '河南省新乡市联通', '1435450627');
INSERT INTO `kl_member_log` VALUES ('264', '1', '123.15.190.20', '河南省新乡市联通', '1435468620');
INSERT INTO `kl_member_log` VALUES ('265', '1', '123.15.190.20', '河南省新乡市联通', '1435482112');
INSERT INTO `kl_member_log` VALUES ('266', '1', '123.15.190.20', '河南省新乡市联通', '1435486598');
INSERT INTO `kl_member_log` VALUES ('267', '1', '115.61.74.26', '河南省郑州市联通', '1435505456');
INSERT INTO `kl_member_log` VALUES ('268', '1', '115.61.74.26', '河南省郑州市联通', '1435506584');
INSERT INTO `kl_member_log` VALUES ('269', '1', '127.0.0.1', '保留地址', '1435506989');
INSERT INTO `kl_member_log` VALUES ('270', '1', '115.61.74.26', '河南省郑州市联通', '1435507903');
INSERT INTO `kl_member_log` VALUES ('271', '1', '171.8.107.254', '河南省郑州市电信', '1435573992');
INSERT INTO `kl_member_log` VALUES ('272', '1', '1.192.18.235', '河南省郑州市电信', '1435644854');
INSERT INTO `kl_member_log` VALUES ('273', '1', '1.192.108.161', '河南省郑州市电信', '1435682858');
INSERT INTO `kl_member_log` VALUES ('274', '1', '127.0.0.1', '保留地址', '1435682997');
INSERT INTO `kl_member_log` VALUES ('275', '1', '171.13.227.28', '河南省郑州市电信', '1435711115');
INSERT INTO `kl_member_log` VALUES ('276', '1', '171.13.227.28', '河南省郑州市电信', '1435734297');
INSERT INTO `kl_member_log` VALUES ('277', '1', '127.0.0.1', '保留地址', '1435734833');
INSERT INTO `kl_member_log` VALUES ('278', '1', '123.149.205.139', '河南省郑州市电信', '1435752247');
INSERT INTO `kl_member_log` VALUES ('279', '1', '1.192.141.9', '河南省郑州市电信', '1435765036');
INSERT INTO `kl_member_log` VALUES ('280', '1', '171.13.225.131', '河南省郑州市电信', '1435773336');
INSERT INTO `kl_member_log` VALUES ('281', '1', '171.13.227.28', '河南省郑州市电信', '1435798305');
INSERT INTO `kl_member_log` VALUES ('282', '1', '127.0.0.1', '保留地址', '1435798304');
INSERT INTO `kl_member_log` VALUES ('283', '1', '171.13.227.28', '河南省郑州市电信', '1435806660');
INSERT INTO `kl_member_log` VALUES ('284', '1', '171.13.227.28', '河南省郑州市电信', '1435813559');
INSERT INTO `kl_member_log` VALUES ('285', '1', '127.0.0.1', '保留地址', '1435985834');
INSERT INTO `kl_member_log` VALUES ('286', '1', '1.192.102.51', '河南省郑州市电信', '1435989657');
INSERT INTO `kl_member_log` VALUES ('287', '1', '1.192.102.51', '河南省郑州市电信', '1435995724');
INSERT INTO `kl_member_log` VALUES ('288', '1', '1.192.102.51', '河南省郑州市电信', '1436006081');
INSERT INTO `kl_member_log` VALUES ('289', '1', '1.192.102.51', '河南省郑州市电信', '1436012357');
INSERT INTO `kl_member_log` VALUES ('290', '1', '171.8.107.227', '河南省郑州市电信', '1436111307');
INSERT INTO `kl_member_log` VALUES ('291', '1', '1.192.115.120', '河南省郑州市电信', '1436113611');
INSERT INTO `kl_member_log` VALUES ('292', '1', '171.13.229.136', '河南省郑州市电信', '1436168648');
INSERT INTO `kl_member_log` VALUES ('293', '1', '171.13.229.136', '河南省郑州市电信', '1436182111');
INSERT INTO `kl_member_log` VALUES ('294', '1', '123.149.118.201', '河南省郑州市电信', '1436183456');
INSERT INTO `kl_member_log` VALUES ('295', '1', '171.13.229.136', '河南省郑州市电信', '1436229833');
INSERT INTO `kl_member_log` VALUES ('296', '1', '171.13.225.28', '河南省郑州市电信', '1436404138');
INSERT INTO `kl_member_log` VALUES ('297', '1', '123.160.147.189', '河南省郑州市电信', '1436676768');
INSERT INTO `kl_member_log` VALUES ('298', '1', '1.192.98.242', '河南省郑州市电信', '1436885706');
INSERT INTO `kl_member_log` VALUES ('299', '1', '1.192.112.91', '河南省郑州市电信', '1436893198');
INSERT INTO `kl_member_log` VALUES ('300', '1', '1.192.142.150', '河南省郑州市电信', '1437017712');
INSERT INTO `kl_member_log` VALUES ('301', '1', '1.192.19.204', '河南省郑州市电信', '1437208829');
INSERT INTO `kl_member_log` VALUES ('302', '1', '1.192.17.119', '河南省郑州市电信', '1437456420');
INSERT INTO `kl_member_log` VALUES ('303', '1', '123.160.145.41', '河南省郑州市电信', '1437544001');
INSERT INTO `kl_member_log` VALUES ('304', '1', '127.0.0.1', '保留地址', '1439565052');
INSERT INTO `kl_member_log` VALUES ('305', '1', '127.0.0.1', '保留地址', '1439781463');
INSERT INTO `kl_member_log` VALUES ('306', '1', '127.0.0.1', '保留地址', '1440380840');
INSERT INTO `kl_member_log` VALUES ('307', '1', '127.0.0.1', '保留地址', '1440467017');
INSERT INTO `kl_member_log` VALUES ('308', '1', '127.0.0.1', '保留地址', '1440558308');
INSERT INTO `kl_member_log` VALUES ('309', '1', '127.0.0.1', '保留地址', '1440647226');
INSERT INTO `kl_member_log` VALUES ('310', '1', '127.0.0.1', '保留地址', '1440722921');
INSERT INTO `kl_member_log` VALUES ('311', '1', '127.0.0.1', '保留地址', '1440723224');
INSERT INTO `kl_member_log` VALUES ('312', '1', '127.0.0.1', '保留地址', '1443594593');
INSERT INTO `kl_member_log` VALUES ('313', '1', '127.0.0.1', '保留地址', '1443595111');
INSERT INTO `kl_member_log` VALUES ('314', '1', '127.0.0.1', '保留地址', '1443598811');
INSERT INTO `kl_member_log` VALUES ('315', '1', '127.0.0.1', '保留地址', '1443598878');
INSERT INTO `kl_member_log` VALUES ('316', '1', '127.0.0.1', '保留地址', '1443606989');
INSERT INTO `kl_member_log` VALUES ('317', '1', '127.0.0.1', '保留地址', '1444294732');
INSERT INTO `kl_member_log` VALUES ('318', '1', '127.0.0.1', '保留地址', '1444294819');
INSERT INTO `kl_member_log` VALUES ('319', '1', '127.0.0.1', '保留地址', '1444350962');
INSERT INTO `kl_member_log` VALUES ('320', '1', '127.0.0.1', '保留地址', '1444371061');
INSERT INTO `kl_member_log` VALUES ('321', '1', '127.0.0.1', '保留地址', '1444371422');
INSERT INTO `kl_member_log` VALUES ('322', '1', '127.0.0.1', '保留地址', '1444371487');
INSERT INTO `kl_member_log` VALUES ('323', '1', '127.0.0.1', '保留地址', '1444372659');
INSERT INTO `kl_member_log` VALUES ('324', '1', '127.0.0.1', '保留地址', '1444372757');
INSERT INTO `kl_member_log` VALUES ('325', '1', '127.0.0.1', '保留地址', '1444372918');
INSERT INTO `kl_member_log` VALUES ('326', '1', '127.0.0.1', '保留地址', '1444372984');
INSERT INTO `kl_member_log` VALUES ('327', '1', '127.0.0.1', '保留地址', '1444373357');
INSERT INTO `kl_member_log` VALUES ('328', '1', '127.0.0.1', '保留地址', '1444373438');
INSERT INTO `kl_member_log` VALUES ('329', '1', '127.0.0.1', '保留地址', '1444374084');
INSERT INTO `kl_member_log` VALUES ('330', '1', '127.0.0.1', '保留地址', '1444374506');
INSERT INTO `kl_member_log` VALUES ('331', '1', '127.0.0.1', '保留地址', '1444438872');
INSERT INTO `kl_member_log` VALUES ('332', '1', '127.0.0.1', '保留地址', '1444438873');
INSERT INTO `kl_member_log` VALUES ('333', '1', '127.0.0.1', '保留地址', '1444466470');
INSERT INTO `kl_member_log` VALUES ('334', '1', '127.0.0.1', '保留地址', '1444551236');
INSERT INTO `kl_member_log` VALUES ('335', '1', '127.0.0.1', '保留地址', '1444646317');
INSERT INTO `kl_member_log` VALUES ('336', '1', '127.0.0.1', '保留地址', '1444696274');
INSERT INTO `kl_member_log` VALUES ('337', '1', '127.0.0.1', '保留地址', '1444712384');
INSERT INTO `kl_member_log` VALUES ('338', '1', '127.0.0.1', '保留地址', '1444784847');
INSERT INTO `kl_member_log` VALUES ('339', '1', '127.0.0.1', '保留地址', '1444805245');
INSERT INTO `kl_member_log` VALUES ('340', '1', '127.0.0.1', '保留地址', '1444869426');
INSERT INTO `kl_member_log` VALUES ('341', '1', '127.0.0.1', '保留地址', '1444897873');
INSERT INTO `kl_member_log` VALUES ('342', '1', '127.0.0.1', '保留地址', '1444959240');
INSERT INTO `kl_member_log` VALUES ('343', '1', '127.0.0.1', '保留地址', '1444962610');
INSERT INTO `kl_member_log` VALUES ('344', '1', '127.0.0.1', '保留地址', '1444963411');
INSERT INTO `kl_member_log` VALUES ('345', '1', '127.0.0.1', '保留地址', '1444963991');
INSERT INTO `kl_member_log` VALUES ('346', '1', '127.0.0.1', '保留地址', '1444964532');
INSERT INTO `kl_member_log` VALUES ('347', '1', '127.0.0.1', '保留地址', '1444975051');
INSERT INTO `kl_member_log` VALUES ('348', '1', '127.0.0.1', '保留地址', '1444983882');
INSERT INTO `kl_member_log` VALUES ('349', '1', '127.0.0.1', '保留地址', '1445046900');
INSERT INTO `kl_member_log` VALUES ('350', '1', '127.0.0.1', '保留地址', '1445567642');
INSERT INTO `kl_member_log` VALUES ('351', '1', '127.0.0.1', '保留地址', '1445649901');
INSERT INTO `kl_member_log` VALUES ('352', '4', '127.0.0.1', '保留地址', '1445670570');
INSERT INTO `kl_member_log` VALUES ('353', '4', '127.0.0.1', '保留地址', '1445675835');
INSERT INTO `kl_member_log` VALUES ('354', '4', '127.0.0.1', '保留地址', '1445675876');
INSERT INTO `kl_member_log` VALUES ('355', '4', '127.0.0.1', '保留地址', '1445675989');
INSERT INTO `kl_member_log` VALUES ('356', '1', '127.0.0.1', '保留地址', '1445676623');
INSERT INTO `kl_member_log` VALUES ('357', '4', '127.0.0.1', '保留地址', '1445676802');
INSERT INTO `kl_member_log` VALUES ('358', '1', '127.0.0.1', '保留地址', '1445906647');
INSERT INTO `kl_member_log` VALUES ('359', '1', '127.0.0.1', '保留地址', '1445992458');
INSERT INTO `kl_member_log` VALUES ('360', '1', '127.0.0.1', '保留地址', '1446080713');
INSERT INTO `kl_member_log` VALUES ('361', '1', '127.0.0.1', '保留地址', '1446185590');
INSERT INTO `kl_member_log` VALUES ('362', '1', '127.0.0.1', '保留地址', '1446276356');
INSERT INTO `kl_member_log` VALUES ('363', '1', '127.0.0.1', '保留地址', '1446425763');
INSERT INTO `kl_member_log` VALUES ('364', '1', '127.0.0.1', '保留地址', '1446510953');
INSERT INTO `kl_member_log` VALUES ('365', '1', '127.0.0.1', '保留地址', '1446605393');
INSERT INTO `kl_member_log` VALUES ('366', '1', '127.0.0.1', '保留地址', '1446772991');
INSERT INTO `kl_member_log` VALUES ('367', '1', '127.0.0.1', '保留地址', '1446797422');
INSERT INTO `kl_member_log` VALUES ('368', '1', '127.0.0.1', '保留地址', '1446798322');
INSERT INTO `kl_member_log` VALUES ('369', '1', '127.0.0.1', '保留地址', '1446800501');
INSERT INTO `kl_member_log` VALUES ('370', '1', '127.0.0.1', '保留地址', '1446802231');
INSERT INTO `kl_member_log` VALUES ('371', '1', '127.0.0.1', '保留地址', '1446858733');
INSERT INTO `kl_member_log` VALUES ('372', '1', '127.0.0.1', '保留地址', '1446874958');
INSERT INTO `kl_member_log` VALUES ('373', '1', '127.0.0.1', '保留地址', '1446875137');
INSERT INTO `kl_member_log` VALUES ('374', '1', '127.0.0.1', '保留地址', '1446890721');
INSERT INTO `kl_member_log` VALUES ('375', '1', '127.0.0.1', '保留地址', '1446962691');
INSERT INTO `kl_member_log` VALUES ('376', '1', '127.0.0.1', '保留地址', '1447054312');
INSERT INTO `kl_member_log` VALUES ('377', '1', '127.0.0.1', '保留地址', '1447055646');
INSERT INTO `kl_member_log` VALUES ('378', '1', '127.0.0.1', '保留地址', '1447061561');
INSERT INTO `kl_member_log` VALUES ('379', '1', '127.0.0.1', '保留地址', '1447292762');
INSERT INTO `kl_member_log` VALUES ('380', '1', '127.0.0.1', '保留地址', '1447637266');
INSERT INTO `kl_member_log` VALUES ('381', '1', '127.0.0.1', '保留地址', '1447722835');
INSERT INTO `kl_member_log` VALUES ('382', '1', '127.0.0.1', '保留地址', '1447810482');
INSERT INTO `kl_member_log` VALUES ('383', '1', '127.0.0.1', '保留地址', '1447911479');
INSERT INTO `kl_member_log` VALUES ('384', '1', '127.0.0.1', '保留地址', '1447928375');
INSERT INTO `kl_member_log` VALUES ('385', '1', '127.0.0.1', '保留地址', '1448183518');
INSERT INTO `kl_member_log` VALUES ('386', '1', '127.0.0.1', '保留地址', '1448265713');
INSERT INTO `kl_member_log` VALUES ('387', '1', '127.0.0.1', '保留地址', '1448265833');
INSERT INTO `kl_member_log` VALUES ('388', '1', '127.0.0.1', '保留地址', '1448294665');
INSERT INTO `kl_member_log` VALUES ('389', '1', '127.0.0.1', '保留地址', '1448324716');
INSERT INTO `kl_member_log` VALUES ('390', '1', '127.0.0.1', '保留地址', '1448426142');
INSERT INTO `kl_member_log` VALUES ('391', '1', '127.0.0.1', '保留地址', '1448958937');
INSERT INTO `kl_member_log` VALUES ('392', '1', '127.0.0.1', '保留地址', '1448958938');
INSERT INTO `kl_member_log` VALUES ('393', '1', '127.0.0.1', '保留地址', '1449016790');
INSERT INTO `kl_member_log` VALUES ('394', '1', '127.0.0.1', '保留地址', '1449051238');
INSERT INTO `kl_member_log` VALUES ('395', '1', '127.0.0.1', '保留地址', '1449139152');
INSERT INTO `kl_member_log` VALUES ('396', '1', '127.0.0.1', '保留地址', '1449189146');
INSERT INTO `kl_member_log` VALUES ('397', '1', '127.0.0.1', '保留地址', '1449275948');
INSERT INTO `kl_member_log` VALUES ('398', '1', '127.0.0.1', '保留地址', '1449325693');
INSERT INTO `kl_member_log` VALUES ('399', '1', '127.0.0.1', '保留地址', '1449379655');
INSERT INTO `kl_member_log` VALUES ('400', '1', '127.0.0.1', '', '1449380005');
INSERT INTO `kl_member_log` VALUES ('401', '1', '127.0.0.1', '保留地址', '1449448863');
INSERT INTO `kl_member_log` VALUES ('402', '1', '127.0.0.1', '保留地址', '1449467900');
INSERT INTO `kl_member_log` VALUES ('403', '1', '127.0.0.1', '保留地址', '1449536923');
INSERT INTO `kl_member_log` VALUES ('404', '1', '127.0.0.1', '保留地址', '1449732631');
INSERT INTO `kl_member_log` VALUES ('405', '1', '127.0.0.1', '保留地址', '1449750988');
INSERT INTO `kl_member_log` VALUES ('406', '1', '127.0.0.1', '保留地址', '1449832543');
INSERT INTO `kl_member_log` VALUES ('407', '1', '127.0.0.1', '保留地址', '1450084889');
INSERT INTO `kl_member_log` VALUES ('408', '1', '127.0.0.1', '保留地址', '1450085078');
INSERT INTO `kl_member_log` VALUES ('409', '1', '127.0.0.1', '保留地址', '1450147747');

-- ----------------------------
-- Table structure for kl_menu
-- ----------------------------
DROP TABLE IF EXISTS `kl_menu`;
CREATE TABLE `kl_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) NOT NULL DEFAULT '默认' COMMENT '分组',
  `type` char(50) NOT NULL DEFAULT 'system',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `is_dev` tinyint(1) NOT NULL DEFAULT '0' COMMENT '开发模式下才显示',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=330 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_menu
-- ----------------------------
INSERT INTO `kl_menu` VALUES ('1', '首页', '0', 'Index/index', '', '', 'system', '0', '0', '0', '1', null, '1424958545');
INSERT INTO `kl_menu` VALUES ('68', '系统', '0', 'Config/group', '', '', 'system', '15', '0', '0', '1', null, '1448242795');
INSERT INTO `kl_menu` VALUES ('122', '后台菜单', '68', 'Menu/index', '', '9开发管理', 'system', '12', '0', '1', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('123', '添加导航', '68', 'Nav/add', '', '', 'system', '34', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('129', '用户', '0', 'Member/index', '', '', 'system', '11', '0', '0', '1', null, '1448242791');
INSERT INTO `kl_menu` VALUES ('130', '用户列表', '129', 'Member/index', '', '', 'system', '0', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('131', '用户组列表', '129', 'Membergroup/index', '', '', 'system', '1', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('132', '用户组编辑', '129', 'Membergroup/edit', '', '用户组管理', 'system', '62', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('133', '添加用户', '129', 'Member/add', '', '用户管理', 'system', '59', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('134', '修改密码', '129', 'Member/updatepwd', '', '用户管理', 'system', '60', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('135', '添加用户组', '129', 'Membergroup/add', '', '用户组管理', 'system', '61', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('136', '用户回收站', '129', 'Member/recycling', '', '', 'system', '3', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('137', '添加菜单', '68', 'Menu/add', '', '9开发管理', 'system', '35', '1', '0', '1', null, '1444447737');
INSERT INTO `kl_menu` VALUES ('140', '导航管理', '68', 'Nav/index', '', '', 'system', '0', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('141', '编辑菜单', '68', 'Menu/edit', '', '9开发管理', 'system', '37', '1', '0', '1', null, '1444447735');
INSERT INTO `kl_menu` VALUES ('147', '文章分类', '312', 'Category/index?category_type=article', '', '分类管理', 'system', '2', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('148', '添加分类', '312', 'Category/add', '', '', 'system', '109', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('146', '编辑导航', '68', 'Nav/edit', '', '', 'system', '38', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('149', '编辑分类', '312', 'Category/edit', '', '', 'system', '108', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('156', '配置管理', '68', 'Config/index', '', '9开发管理', 'system', '13', '0', '1', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('157', '网站设置', '68', 'Config/group', '', '', 'system', '1', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('158', '编辑配置', '68', 'Config/edit', '', '9开发管理', 'system', '43', '1', '0', '1', null, '1444447734');
INSERT INTO `kl_menu` VALUES ('159', '添加配置', '68', 'Config/add', '', '9开发管理', 'system', '44', '1', '0', '1', null, '1444447733');
INSERT INTO `kl_menu` VALUES ('161', '备份数据库', '68', 'Database/index?type=export', '', '8数据备份', 'system', '10', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('162', '还原数据库', '68', 'Database/index?type=import', '', '8数据备份', 'system', '11', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('165', '文章', '0', 'Article/index', '', '', 'system', '8', '0', '0', '1', null, '1448242789');
INSERT INTO `kl_menu` VALUES ('168', '友情链接', '68', 'Link/index', '', '', 'system', '2', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('169', '添加链接', '68', 'Link/add', '', '5友情链接', 'system', '46', '1', '0', '1', null, '1444448029');
INSERT INTO `kl_menu` VALUES ('170', '编辑链接', '68', 'Link/edit', '', '5友情链接', 'system', '47', '1', '0', '1', null, '1444448030');
INSERT INTO `kl_menu` VALUES ('174', '添加文章', '165', 'Article/add', '', '', 'system', '0', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('175', '编辑文章', '165', 'Article/edit', '', '', 'system', '76', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('251', '移动文档', '165', 'Article/move', '', '', 'system', '68', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('177', '草稿箱', '165', 'Article/draftbox', '', '', 'system', '2', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('178', '禁用文档', '165', 'Article/examine', '', '', 'system', '69', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('179', '文章回收站', '165', 'Article/recycle', '', '', 'system', '3', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('183', '编辑用户信息', '129', 'Member/edit', '', '', 'system', '58', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('186', '权限分配', '129', 'Membergroup/auth', '', '用户组管理', 'system', '57', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('187', '文档列表', '165', 'Article/index', '', '', 'system', '1', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('188', '更新状态', '68', 'Index/updatefield', '', '', 'system', '30', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('189', '删除分类', '312', 'Category/del', '', '', 'system', '106', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('190', '删除文章', '165', 'Article/dele', '', '', 'system', '71', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('191', '清空回收站', '165', 'Article/delall', '', '', 'system', '70', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('192', '添加模型', '68', 'Model/add', '', '9开发管理', 'system', '31', '1', '0', '1', null, '1444447741');
INSERT INTO `kl_menu` VALUES ('194', '恢复文档', '165', 'Article/huifu', '', '', 'system', '67', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('195', '移动到回收站', '165', 'Article/del', '', '', 'system', '66', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('196', '删除导航', '68', 'Nav/del', '', '', 'system', '32', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('197', '删除菜单', '68', 'Menu/del', '', '9开发管理', 'system', '33', '1', '0', '1', null, '1444447738');
INSERT INTO `kl_menu` VALUES ('198', '删除友情链接', '68', 'Link/del', '', '5友情链接', 'system', '20', '1', '0', '1', null, '1444448037');
INSERT INTO `kl_menu` VALUES ('199', '删除配置', '68', 'Config/del', '', '9开发管理', 'system', '19', '1', '0', '1', null, '1444447746');
INSERT INTO `kl_menu` VALUES ('228', '图片管理', '68', 'File/imglist', '', '', 'system', '3', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('229', '无关联图片', '68', 'File/nolinkimg', '', '', 'system', '7', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('230', 'UE上传', '68', 'File/ueupload', '', '', 'system', '6', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('231', '其它模块', '0', 'Msg/tixing', '', '', 'system', '0', '1', '0', '1', null, '1416672919');
INSERT INTO `kl_menu` VALUES ('232', '系统消息提醒', '231', 'Msg/tixing', '', '', 'system', '77', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('233', '登陆日志', '129', 'Member/log', '', '', 'system', '2', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('234', '广告列表', '68', 'Module/index', '', '7广告管理', 'system', '7', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('235', '广告位置', '68', 'Modulepos/index', '', '7广告管理', 'system', '8', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('236', '添加广告信息', '68', 'Module/add', '', '7广告管理', 'system', '5', '1', '0', '1', null, '1445653433');
INSERT INTO `kl_menu` VALUES ('237', '编辑广告信息', '68', 'Module/edit', '', '7广告管理', 'system', '4', '1', '0', '1', null, '1445653431');
INSERT INTO `kl_menu` VALUES ('238', '删除广告信息', '68', 'Module/del', '', '7广告管理', 'system', '8', '1', '0', '1', null, '1445653438');
INSERT INTO `kl_menu` VALUES ('239', '添加广告位置', '68', 'Modulepos/add', '', '7广告管理', 'system', '2', '1', '0', '1', null, '1445653412');
INSERT INTO `kl_menu` VALUES ('240', '编辑广告位置', '68', 'Modulepos/edit', '', '7广告管理', 'system', '1', '1', '0', '1', null, '1445653410');
INSERT INTO `kl_menu` VALUES ('241', '删除广告位置', '68', 'Modulepos/del', '', '7广告管理', 'system', '9', '1', '0', '1', null, '1445653440');
INSERT INTO `kl_menu` VALUES ('243', '生成缩略图', '68', 'File/createthumb', '', '', 'system', '10', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('253', '附件管理', '68', 'File/attach', '', '', 'system', '4', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('254', '网站打包', '68', 'Database/webtozip', '', '8数据备份', 'system', '9', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('255', '单页管理', '68', 'Single/index', '', '', 'system', '5', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('256', '添加单页', '68', 'Single/add', '', '', 'system', '15', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('257', '编辑单页', '68', 'Single/edit', '', '', 'system', '14', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('258', '删除单页', '68', 'Single/del', '', '', 'system', '13', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('259', '表单模型', '68', 'Model/index', '', '9开发管理', 'system', '15', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('260', '编辑模型', '68', 'Model/edit', '', '', 'system', '11', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('261', '删除模型', '68', 'Model/del', '', '', 'system', '0', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('262', '模型属性管理', '68', 'Modelattr/index', '', '', 'system', '12', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('263', '添加模型属性', '68', 'Modelattr/add', '', '', 'system', '16', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('264', '编辑模型属性', '68', 'Modelattr/edit', '', '', 'system', '18', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('265', '删除模型属性', '68', 'Modelattr/del', '', '', 'system', '3', '1', '0', '1', null, '1444447140');
INSERT INTO `kl_menu` VALUES ('266', '节点列表', '68', 'Node/index', '', '9开发管理', 'system', '14', '0', '0', '1', '1416905857', '1448266060');
INSERT INTO `kl_menu` VALUES ('267', '添加节点', '68', 'Node/add', '', '', 'system', '29', '1', '0', '1', '1416906242', '1444447140');
INSERT INTO `kl_menu` VALUES ('268', '编辑节点', '68', 'Node/edit', '', '', 'system', '22', '1', '0', '1', '1416906258', '1444447140');
INSERT INTO `kl_menu` VALUES ('269', '删除节点', '68', 'Node/del', '', '', 'system', '28', '1', '0', '1', '1416906278', '1444447140');
INSERT INTO `kl_menu` VALUES ('271', '产品', '0', 'Goods/index', '', '', 'system', '5', '0', '0', '1', '1426175591', '1448242783');
INSERT INTO `kl_menu` VALUES ('272', '产品列表', '271', 'Goods/index', '', '', 'system', '1', '0', '0', '1', '1426221065', '1448266060');
INSERT INTO `kl_menu` VALUES ('273', '产品草稿箱', '271', 'Goods/draftbox', '', '', 'system', '2', '0', '0', '1', '1426221140', '1448266060');
INSERT INTO `kl_menu` VALUES ('274', '添加新产品', '271', 'Goods/add', '', '', 'system', '0', '0', '0', '1', '1426221160', '1448266060');
INSERT INTO `kl_menu` VALUES ('275', '编辑产品', '271', 'Goods/edit', '', '', 'system', '81', '1', '0', '1', '1426221178', '1444447140');
INSERT INTO `kl_menu` VALUES ('276', '移动产品到回收站', '271', 'Goods/del', '', '', 'system', '82', '1', '0', '1', '1426221213', '1444447140');
INSERT INTO `kl_menu` VALUES ('277', '删除产品', '271', 'Goods/dele', '', '', 'system', '83', '1', '0', '1', '1426221229', '1444447140');
INSERT INTO `kl_menu` VALUES ('278', '产品分类', '312', 'Category/index?category_type=goods', '', '分类管理', 'system', '1', '0', '0', '1', '1426221267', '1448266060');
INSERT INTO `kl_menu` VALUES ('279', '产品回收站', '271', 'Goods/recycle', '', '', 'system', '3', '0', '0', '1', '1426221294', '1448266060');
INSERT INTO `kl_menu` VALUES ('280', '扩展', '0', 'Addons/index', '', '', 'system', '20', '0', '0', '1', '1426326306', '1427593176');
INSERT INTO `kl_menu` VALUES ('281', '插件管理', '280', 'Addons/index', '', '扩展管理', 'system', '2', '0', '0', '1', '1426326405', '1448266060');
INSERT INTO `kl_menu` VALUES ('282', '钩子列表', '280', 'Hook/index', '', '扩展管理', 'system', '3', '0', '0', '1', '1426326454', '1448266060');
INSERT INTO `kl_menu` VALUES ('283', '钩子管理', '280', 'Hook/manage', '', '', 'system', '94', '1', '0', '1', '1426338055', '1444447140');
INSERT INTO `kl_menu` VALUES ('284', '启用钩子', '280', 'Hook/qiyong', '', '', 'system', '93', '1', '0', '1', '1426338215', '1444447140');
INSERT INTO `kl_menu` VALUES ('285', '禁用钩子', '280', 'Hook/jinyong', '', '', 'system', '92', '1', '0', '1', '1426338240', '1444447140');
INSERT INTO `kl_menu` VALUES ('286', '删除钩子', '280', 'Hook/del', '', '', 'system', '91', '1', '0', '1', '1426338270', '1444447140');
INSERT INTO `kl_menu` VALUES ('287', '安装插件', '280', 'Addons/install', '', '', 'system', '90', '1', '0', '1', '1426338818', '1444447140');
INSERT INTO `kl_menu` VALUES ('288', '卸载插件', '280', 'Addons/unstall', '', '', 'system', '89', '1', '0', '1', '1426338842', '1444447140');
INSERT INTO `kl_menu` VALUES ('289', '启用插件', '280', 'Addons/qiyong', '', '', 'system', '88', '1', '0', '1', '1426338874', '1444447140');
INSERT INTO `kl_menu` VALUES ('290', '禁用插件', '280', 'Addons/jinyong', '', '', 'system', '87', '1', '0', '1', '1426338894', '1444447140');
INSERT INTO `kl_menu` VALUES ('300', '添加钩子', '280', 'Hook/add', '', '扩展管理', 'system', '86', '1', '0', '1', '1427593222', '1444447140');
INSERT INTO `kl_menu` VALUES ('302', '类型列表', '68', 'Goodstype/index', '', '6内容类型', 'system', '6', '0', '0', '1', '1429346478', '1448266060');
INSERT INTO `kl_menu` VALUES ('303', '类型属性', '68', 'Goodstypeattribute/index', '', '6内容类型', 'system', '27', '1', '0', '1', '1429347048', '1444448026');
INSERT INTO `kl_menu` VALUES ('304', '编辑类型属性', '68', 'Goodstypeattribute/edit', '', '6内容类型', 'system', '26', '1', '0', '1', '1429347664', '1444448023');
INSERT INTO `kl_menu` VALUES ('305', '编辑内容类型', '68', 'Goodstype/edit', '', '6内容类型', 'system', '21', '1', '0', '1', '1429349747', '1444448021');
INSERT INTO `kl_menu` VALUES ('306', '添加类型属性', '68', 'Goodstypeattribute/add', '', '6内容类型', 'system', '24', '1', '0', '1', '1429403360', '1444448022');
INSERT INTO `kl_menu` VALUES ('307', '添加内容类型', '68', 'Goodstype/add', '', '6内容类型', 'system', '23', '1', '0', '1', '1429403549', '1444448022');
INSERT INTO `kl_menu` VALUES ('311', '留言管理', '280', 'Addons/plugin?pn=Comments&pm=lists', '', '已装插件', 'Comments', '1', '0', '0', '1', null, '1448266060');
INSERT INTO `kl_menu` VALUES ('312', '文档', '0', 'Archive/index?model_id=1', '', '', 'system', '3', '0', '0', '1', '1434642128', '1448242786');
INSERT INTO `kl_menu` VALUES ('313', '文章管理', '312', 'Archive/index?model_id=1', '', '', 'system', '0', '0', '0', '1', '1434642161', '1448266060');
INSERT INTO `kl_menu` VALUES ('325', 'Excel工具', '280', 'Addons/plugin?pn=Phpexcel&pm=set', '', '已装插件', 'Phpexcel', '0', '0', '0', '1', null, null);
INSERT INTO `kl_menu` VALUES ('319', '添加文档', '312', 'Archive/add', '', '', 'system', '101', '1', '0', '1', '1440573658', '1444447140');
INSERT INTO `kl_menu` VALUES ('320', '编辑文档', '312', 'Archive/edit', '', '', 'system', '100', '1', '0', '1', '1440573775', '1444447140');
INSERT INTO `kl_menu` VALUES ('321', '删除文档', '312', 'Archive/del', '', '', 'system', '99', '1', '0', '1', '1440573796', '1444447140');
INSERT INTO `kl_menu` VALUES ('322', '文档回收站', '312', 'Archive/recycle', '', '', 'system', '98', '1', '0', '1', '1440574204', '1444447140');
INSERT INTO `kl_menu` VALUES ('323', '订单列表', '271', 'Order/index', '', '', 'system', '4', '0', '0', '1', '1447914208', '1448266060');
INSERT INTO `kl_menu` VALUES ('326', '二维码', '280', 'Addons/plugin?pn=Erweima&pm=set', '', '已装插件', 'Erweima', '0', '0', '0', '1', null, null);
INSERT INTO `kl_menu` VALUES ('327', '支付宝', '280', 'Addons/plugin?pn=Alipay&pm=set', '', '已装插件', 'Alipay', '0', '0', '0', '1', null, null);
INSERT INTO `kl_menu` VALUES ('328', '中国银联', '280', 'Addons/plugin?pn=Unionpay&pm=set', '', '已装插件', 'Unionpay', '0', '0', '0', '1', null, null);
INSERT INTO `kl_menu` VALUES ('329', '财付通', '280', 'Addons/plugin?pn=Tenpay&pm=set', '', '已装插件', 'Tenpay', '0', '0', '0', '1', null, null);

-- ----------------------------
-- Table structure for kl_model
-- ----------------------------
DROP TABLE IF EXISTS `kl_model`;
CREATE TABLE `kl_model` (
  `model_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `table` varchar(50) DEFAULT NULL,
  `modeltype` varchar(50) DEFAULT 'other',
  `sort` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `list_format` text,
  `recycle_format` text,
  `search_format` text,
  PRIMARY KEY (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_model
-- ----------------------------
INSERT INTO `kl_model` VALUES ('2', 'single', '单页主题', 'Single', 'system', '2', '1', '0', '1411890121', null, null, null);
INSERT INTO `kl_model` VALUES ('1', 'article', '文章', 'Article', 'system', '1', '1', '0', '1440575280', 'article_id:编号\r\ntitle:标题|<span class=\"el\">[title]</span>\r\ncategory_id|getCategoryTitle:分类|<span class=\"el\">[category_id]</span>\r\nupdate_time|time_format:最后更新\r\nstatus|totext:状态\r\nviews:浏览\r\narticle_id:操作:[EDIT]&id=[article_id]|编辑|btn,[DEL]&id=[article_id]|移动到回收站|btn btn-danger', 'article_id:编号\r\ntitle:标题|<span class=\"el\">[title]</span>\r\ncategory_id|getCategoryTitle:分类|<span class=\"el\">[category_id]</span>\r\nupdate_time|time_format:最后更新\r\nstatus:状态\r\nviews:浏览\r\narticle_id:操作:[HUIFU]&id=[article_id]|恢复|btn,[DELE]&id=[article_id]|彻底删除|btn btn-danger', 'title:文章标题');
INSERT INTO `kl_model` VALUES ('3', 'link', '友情链接', 'Link', 'system', '3', '1', '1411876677', '1411876677', null, null, null);
INSERT INTO `kl_model` VALUES ('4', 'goods', '产品', 'Goods', 'system', '0', '1', '1411882688', '1434646132', '', null, null);
INSERT INTO `kl_model` VALUES ('5', 'modulepos', '模块位置', 'Modulepos', 'system', '0', '1', '1411888108', '1411888108', null, null, null);
INSERT INTO `kl_model` VALUES ('6', 'module', '模块信息', 'Module', 'system', '0', '1', '1411888422', '1411888422', null, null, null);
INSERT INTO `kl_model` VALUES ('7', 'nav', '导航', 'Nav', 'system', '0', '1', '1411889286', '1411889286', null, null, null);
INSERT INTO `kl_model` VALUES ('8', 'comments', '留言', 'Comments', 'system', '0', '1', '1411890690', '1425556359', null, null, null);
INSERT INTO `kl_model` VALUES ('9', 'category', '内容分类', 'Category', 'system', '0', '1', '1411892541', '1434646071', '', null, null);
INSERT INTO `kl_model` VALUES ('10', 'menu', '后台菜单', 'Menu', 'system', '0', '1', '1411893504', '1444353066', null, null, null);
INSERT INTO `kl_model` VALUES ('11', 'goodscat', '产品分类', 'GoodsCat', 'system', '0', '1', '1411897060', '1434647208', '', '', null);
INSERT INTO `kl_model` VALUES ('12', 'goodstype', '产品类型', 'GoodsType', 'system', '0', '1', '1411897636', '1434984591', '', '', null);
INSERT INTO `kl_model` VALUES ('13', 'goodstypeattr', '类型属性', 'GoodsTypeAttribute', 'system', '0', '1', '1411898048', '1424359765', null, null, null);
INSERT INTO `kl_model` VALUES ('14', 'model', '表单模型', 'Model', 'system', '0', '1', '1412994694', '1434645853', '', null, null);
INSERT INTO `kl_model` VALUES ('16', 'modelattr', '表单模型属性', 'ModelAttr', 'system', '0', '1', '0', '1418119099', null, null, null);
INSERT INTO `kl_model` VALUES ('18', 'node', '节点表单', 'Node', 'system', '99', '1', '1416906329', '1416906329', null, null, null);
INSERT INTO `kl_model` VALUES ('19', 'membergroup', '用户组模型', 'MemberGroup', 'system', '0', '1', '1423588366', '1434646119', '', null, null);
INSERT INTO `kl_model` VALUES ('20', 'member', '用户模型', 'Member', 'system', '0', '1', '1433065869', '1434646111', '', null, null);
INSERT INTO `kl_model` VALUES ('22', 'config', '配置模型', 'config', 'system', '99', '1', '1435742136', '1435742136', '', '', null);

-- ----------------------------
-- Table structure for kl_model_attr
-- ----------------------------
DROP TABLE IF EXISTS `kl_model_attr`;
CREATE TABLE `kl_model_attr` (
  `model_attr_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `model_id` int(11) unsigned NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `note` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `field` varchar(50) DEFAULT NULL,
  `extra` text,
  `extranote` varchar(50) DEFAULT NULL,
  `is_require` tinyint(1) DEFAULT '0',
  `sort` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `is_show` tinyint(4) DEFAULT '1',
  `value` text,
  `attrtype` tinyint(1) DEFAULT '0',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `data_ts` varchar(50) DEFAULT NULL,
  `data_err` varchar(50) DEFAULT NULL,
  `data_ok` varchar(50) DEFAULT NULL,
  `data_reg` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`model_attr_id`)
) ENGINE=MyISAM AUTO_INCREMENT=166 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_model_attr
-- ----------------------------
INSERT INTO `kl_model_attr` VALUES ('1', '1', '内容', '文章内容', 'content', 'editor', 'content', '', '0', '0', '4', '1', '3', '', '0', '0', '1431833656', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('6', '3', '排序', '0', 'sort', 'number', 'sort', '', null, '0', '4', '1', '3', '1', '0', '1411877033', '1411877033', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('3', '3', '友情链接标题', '', 'title', 'string', 'title', '', null, '0', '1', '1', '3', '', '0', '1411876789', '1411878769', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('4', '3', '链接地址', '', 'url', 'string', 'url', '0', null, '0', '2', '1', '3', 'javascript:;', '0', '1411876886', '1411876886', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('5', '3', '链接图标', '', 'pic', 'picture', 'pic', '0', null, '0', '3', '1', '3', null, '1', '1411876909', '1411876923', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('7', '3', '链接状态', '友情链接顺序', 'status', 'radio', 'status', '0:禁用\r\n1:启用', null, '0', '5', '1', '3', '1', '0', '1411877171', '1411877965', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('8', '1', '所属分类', '', 'category_id', 'select', 'category_id', 'F_getCatelist', '1', '0', '1', '1', '3', '', '0', '1411879614', '1435684742', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('9', '1', '文章标题', '', 'title', 'string', 'title', '', '0', '1', '2', '1', '3', '', '0', '1411879735', '1435684085', '请输入文章标题,不能为空', '', '', '.+');
INSERT INTO `kl_model_attr` VALUES ('10', '1', '封面图片', '', 'pic', 'picture', 'pic', '', '0', '0', '5', '1', '3', '', '1', '1411879770', '1440399610', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('11', '1', '文章附加属性', '', 'position', 'checkbox', 'position', '1:首页,2:热点,3:图文,4:搞笑,5:伤感,6:个性,7:爱情,8:心情', '0', '0', '4', '1', '3', '', '1', '1411879852', '1433063132', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('12', '1', '附件', '', 'attachment', 'file', 'attachment', '', '0', '0', '6', '1', '3', '', '1', '1411879877', '1431833658', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('13', '1', '文章状态', '', 'status', 'radio', 'status', '0:禁用\r\n1:正常\r\n2:草稿', '0', '0', '8', '1', '3', '1', '0', '1411879920', '1431833660', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('14', '4', '产品分类', '', 'category_id', 'select', 'category_id', 'F_getCatelist=1,\'goods\'', '1', '0', '1', '1', '3', '', '0', '1411882747', '1435027434', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('15', '5', '模块位置名称', '', 'title', 'string', 'title', '', '0', '0', '1', '1', '3', '', '0', '1411888191', '1411888191', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('16', '5', '模板代码', '前台模板代码,调用方法:{:W(\'Adpos/index\',array(\'广告位置ID\'))}', 'tplcode', 'textarea', 'tplcode', '', '0', '0', '3', '1', '3', '', '0', '1411888231', '1427437580', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('17', '5', '排序', '', 'sort', 'number', 'sort', '', '0', '0', '4', '1', '3', '', '0', '1411888265', '1427437582', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('18', '6', '模块位置', '', 'modulepos_id', 'select', 'modulepos_id', 'F_getModuleposList', '1', '0', '1', '1', '3', '', '0', '1411888673', '1426565750', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('19', '6', '标题', '广告描述标题', 'title', 'string', 'title', '', '0', '0', '2', '1', '3', '', '0', '1411888700', '1411888700', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('20', '6', '链接', '广告链接,以http://开头的链接', 'url', 'string', 'url', '', '0', '0', '3', '1', '3', '', '0', '1411888729', '1411888729', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('21', '6', '图片', '', 'pic', 'picture', 'pic', '', '0', '0', '4', '1', '3', '', '1', '1411888753', '1411888753', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('22', '6', '排序', '', 'sort', 'number', 'sort', '', '0', '0', '5', '1', '3', '0', '0', '1411888777', '1411888950', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('23', '6', '状态', '', 'status', 'radio', 'status', '0:禁用\r\n1:启用', '0', '0', '6', '1', '3', '1', '1', '1411888833', '1411888974', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('24', '7', '上级导航', '所属的上级导航', 'pid', 'select', 'pid', 'F_getNavlist', '1', '0', '1', '1', '3', '', '0', '1411889336', '1420109335', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('25', '7', '导航标题', '', 'title', 'string', 'title', '', '0', '0', '2', '1', '3', '', '0', '1411889357', '1411889357', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('26', '7', '导航地址', '格式http://开头的地址', 'url', 'string', 'url', '', '0', '0', '3', '1', '3', '', '0', '1411889379', '1411889379', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('27', '7', 'SEO标题', '', 'meta_title', 'string', 'meta_title', '', '0', '0', '4', '1', '3', '', '1', '1411889415', '1411889415', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('28', '7', 'SEO关键字', '', 'meta_keywords', 'string', 'meta_keywords', '', '0', '0', '5', '1', '3', '', '1', '1411889435', '1411889435', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('29', '7', 'SEO描述', '', 'meta_descr', 'textarea', 'meta_descr', '', '0', '0', '6', '1', '3', '', '1', '1411889458', '1411889458', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('30', '7', '导航排序', '', 'sort', 'number', 'sort', '', '0', '0', '7', '1', '3', '0', '0', '1411889496', '1411889821', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('31', '7', '新窗口打开', '点击后在新窗口打开', 'target', 'radio', 'target', '0:否\r\n1:是', '0', '0', '8', '1', '3', '0', '0', '1411889564', '1427269756', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('32', '7', '显示/隐藏', '控制导航的显示隐藏', 'status', 'radio', 'status', '0:隐藏\r\n1:显示', '0', '0', '10', '1', '3', '1', '0', '1411889677', '1427269763', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('33', '2', '单页名字标题', '', 'title', 'string', 'title', '', '0', '0', '1', '1', '3', '', '0', '1411890158', '1424361459', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('34', '2', '单页内容', '', 'content', 'editor', 'content', '', '0', '0', '2', '1', '3', '', '0', '1411890183', '1411890183', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('35', '2', '单页顺序', '', 'sort', 'number', 'sort', '', '0', '0', '3', '1', '3', '0', '0', '1411890205', '1411890205', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('36', '2', '单页状态', '', 'status', 'radio', 'status', '0:禁用\r\n1:启用', '0', '0', '4', '1', '3', '1', '0', '1411890248', '1411890368', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('37', '4', '产品标题', '', 'title', 'string', 'title', '', '0', '0', '2', '1', '3', '', '0', '1411890798', '1426174377', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('38', '4', '产品描述', '', 'content', 'editor', 'content', '', '0', '0', '98', '1', '3', '', '0', '1411890824', '1428393341', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('39', '4', '产品图片', '', 'pic', 'cutpicture', 'pic', 'bili:1.3\r\nwidth:600\r\nheight:400', '0', '0', '4', '1', '3', '', '1', '1411890844', '1440469264', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('40', '4', '产品相册', '', 'xc', 'batchpicture', 'xc', '', '0', '0', '5', '1', '3', '', '1', '1411890863', '1428133510', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('41', '4', '产品标记', '', 'position', 'checkbox', 'position', '1:新品\r\n2:热销', '0', '0', '6', '1', '3', '1', '0', '1411890919', '1426221815', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('42', '4', '禁用/启用/草稿', '', 'status', 'radio', 'status', '0:禁用\r\n1:正常\r\n2:草稿', '0', '0', '8', '1', '3', '1', '0', '1411890969', '1426175404', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('43', '9', '所属的上级分类', '', 'pid', 'select', 'pid', 'F_getCatelist', '1', '0', '1', '1', '3', '', '0', '1411892587', '1411892587', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('44', '9', '分类标识符', '用于生成分类友好地址\'', 'name', 'string', 'name', '', '0', '0', '2', '1', '3', '', '0', '1411892622', '1411892622', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('45', '9', '分类名称', '', 'title', 'string', 'title', '', '0', '0', '3', '1', '3', '', '0', '1411892641', '1411892641', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('46', '9', 'SEO分类名称', '', 'meta_title', 'string', 'meta_title', '', '0', '0', '4', '1', '3', '', '1', '1411892667', '1411892667', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('47', '9', 'SEO分类关键字', '', 'meta_keywords', 'string', 'meta_keywords', '', '0', '0', '5', '1', '3', '', '1', '1411892701', '1411892701', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('48', '9', 'SEO分类描述', '', 'meta_descr', 'textarea', 'meta_descr', '', '0', '0', '6', '1', '3', '', '1', '1411892727', '1411892727', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('49', '9', '排序', '', 'sort', 'number', 'sort', '', '0', '0', '7', '1', '3', '0', '0', '1411892748', '1411892761', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('50', '9', '状态', '', 'status', 'radio', 'status', '0:禁用\r\n1:启用', '0', '0', '8', '1', '3', '1', '0', '1411892801', '1411893030', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('51', '9', '分类图片', '', 'icon', 'picture', 'icon', '', '0', '0', '9', '1', '3', '', '1', '1411892885', '1426405121', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('52', '10', '上级菜单', '所属的上级菜单', 'pid', 'select', 'pid', 'F_getMenuList', '1', '0', '1', '1', '3', '', '0', '1411893548', '1411893548', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('53', '10', '标题', '用于后台显示的标题', 'title', 'string', 'title', '', '0', '0', '2', '1', '3', '', '0', '1411893577', '1411893577', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('54', '10', '排序', '', 'sort', 'number', 'sort', '', '0', '0', '6', '1', '3', '0', '0', '1411893603', '1411893603', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('55', '10', '链接', 'U函数解析的URL或外链', 'url', 'string', 'url', '', '0', '0', '4', '1', '3', '', '0', '1411893648', '1411893648', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('56', '10', '菜单分组', '把菜单分组，用于后台左边分组', 'group', 'string', 'group', '', '0', '0', '5', '1', '3', '', '0', '1411893752', '1411893752', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('57', '10', '是否隐藏', '', 'hide', 'radio', 'hide', '0:否\r\n1:是', '0', '0', '7', '1', '3', '0', '0', '1411893791', '1411894032', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('58', '10', '是否在开发模式下才显示', '关闭开发模式后此配置项不显示', 'is_dev', 'radio', 'is_dev', '0:任何时候都可以显示\r\n1:只在开发模式下显示', '0', '0', '8', '1', '3', '0', '0', '1411893872', '1411893872', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('59', '11', '上级分类', '所属的上级分类', 'pid', 'select', 'pid', 'F_getGoodscatList', '1', '0', '1', '1', '3', '', '0', '1411897117', '1411897117', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('60', '11', '绑定类型', '将分类绑定类型', 'typeid', 'select', 'typeid', 'F_getGoodsType', '1', '0', '2', '1', '3', '', '0', '1411897161', '1411897161', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('61', '11', '产品分类名称', '', 'title', 'string', 'title', '', '0', '0', '3', '1', '3', '', '0', '1411897181', '1411897181', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('62', '11', '分类标识符', '', 'name', 'string', 'name', '', '0', '0', '4', '1', '3', '', '0', '1411897231', '1411897231', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('63', '11', '排序', '', 'sort', 'number', 'sort', '', '0', '0', '5', '1', '3', '0', '0', '1411897275', '1411897275', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('64', '11', '分类图标', '', 'icon', 'picture', 'icon', '', '0', '0', '6', '1', '3', '', '1', '1411897320', '1411897320', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('65', '11', '分类状态', '', 'status', 'radio', 'status', '0:禁用\r\n1:正常', '0', '0', '7', '1', '3', '1', '0', '1411897386', '1411897386', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('66', '12', '产品类型名称', '', 'title', 'string', 'title', '', '0', '0', '1', '1', '3', '', '0', '1411897745', '1411897745', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('67', '12', '排序', '', 'sort', 'number', 'sort', '', '0', '0', '2', '1', '3', '0', '0', '1411897770', '1411897770', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('68', '12', '状态', '', 'status', 'radio', 'status', '0:禁用\r\n1:启用', '0', '0', '3', '1', '3', '1', '0', '1411897809', '1411897809', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('69', '13', '所属类型', '', 'typeid', 'select', 'typeid', 'F_getGoodsType', '1', '0', '1', '1', '3', '', '0', '1411898161', '1411898161', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('70', '13', '属性标题名称', '', 'title', 'string', 'title', '', '0', '0', '2', '1', '3', '', '0', '1411898184', '1411898184', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('71', '13', '属性name标识', '生成表单使用', 'name', 'string', 'name', '', '0', '0', '3', '1', '3', '', '0', '1411898222', '1411898222', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('72', '13', '表单数据类型', '', 'type', 'select', 'type', 'getFormType', '1', '0', '4', '1', '3', '', '0', '1411898264', '1429417081', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('73', '13', '属性说明note', '备注', 'note', 'string', 'note', '', '0', '0', '5', '1', '3', '', '0', '1411898298', '1411898688', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('74', '13', '属性扩展数据extra', '如果属性是select,radio,checkbox等类似表单的话此项必填', 'extra', 'textarea', 'extra', '', '0', '0', '6', '1', '3', '', '0', '1411898357', '1411898669', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('75', '13', '属性默认值', '', 'value', 'string', 'value', '', '0', '0', '7', '1', '3', '', '0', '1411898415', '1429417005', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('76', '13', '排序', '', 'sort', 'number', 'sort', '', '0', '0', '8', '1', '3', '0', '0', '1411898438', '1411898438', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('77', '13', '什么时候显示', '', 'is_show', 'radio', 'is_show', '0:隐藏\r\n1:添加时显示\r\n2:编辑时显示\r\n3:添加编辑时都显示', '0', '0', '9', '1', '3', '1', '0', '1411898484', '1433066081', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('78', '13', '状态', '', 'status', 'radio', 'status', '0:禁用\r\n1:启用', '0', '0', '10', '1', '3', '1', '0', '1411898517', '1411898517', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('80', '14', '模型标识', '', 'name', 'string', 'name', '', '0', '0', '1', '1', '3', '', '0', '1412994751', '1416762491', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('81', '14', '模型名字', '', 'title', 'string', 'title', '', '0', '0', '2', '1', '3', '', '0', '1412994787', '1412994787', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('82', '14', '数据表', '', 'table', 'string', 'table', '', '0', '0', '3', '1', '3', '', '0', '1412994810', '1412994810', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('83', '14', '排序', '', 'sort', 'number', 'sort', '', '0', '0', '4', '1', '3', '', '0', '1412994836', '1412994836', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('84', '14', '模型状态', '', 'status', 'radio', 'status', '0:禁用\r\n1:正常', '0', '0', '5', '1', '3', '1', '0', '1412994917', '1412995072', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('85', '16', '所属模型', '', 'model_id', 'select', 'model_id', 'A_getModellist', '1', '1', '8', '1', '3', '', '0', '1416763306', '1416766932', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('86', '16', '表单标题', '', 'title', 'string', 'title', '', '0', '1', '9', '1', '3', '', '0', '1416763339', '1416766943', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('87', '16', '表单字段说明', '', 'note', 'string', 'note', '', '0', '0', '10', '1', '3', '', '0', '1416763377', '1416763377', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('88', '16', 'input表单的name值', '', 'name', 'string', 'name', '', '0', '1', '11', '1', '3', '', '0', '1416763404', '1416766964', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('89', '16', '数据库字段名字', '编辑内容的时候表单会填充这个字段的值', 'field', 'string', 'field', '', '0', '1', '12', '1', '3', '', '0', '1416763443', '1416766978', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('90', '16', '配置数据类型', '系统会根据不同的类型解析配置值', 'type', 'select', 'type', 'getFormType', '1', '1', '13', '1', '3', '', '0', '1416763492', '1416766997', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('91', '16', '字段附加值extra', '当值为枚举时有用', 'extra', 'textarea', 'extra', '', '0', '0', '14', '1', '3', '', '0', '1416763528', '1416767169', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('92', '16', '说明extra数据是函数返回还是字符串解析生成', '只有当extra数据不为空时有用', 'extranote', 'radio', 'extranote', '0:字符串解析\r\n1:系统函数返回', '0', '1', '15', '1', '3', '0', '0', '1416763619', '1423584925', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('93', '16', '字段默认值', '', 'value', 'textarea', 'value', '', '0', '0', '16', '1', '3', '', '0', '1416763655', '1423580197', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('94', '16', '排序', '', 'sort', 'number', 'sort', '', '0', '0', '17', '1', '3', '99', '0', '1416763698', '1416767027', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('95', '16', '是否必填项', '', 'is_require', 'radio', 'is_require', '0:否\r\n1:是', '0', '0', '18', '1', '3', '', '0', '1416763756', '1416767073', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('96', '16', '什么时候显示', '', 'is_show', 'radio', 'is_show', '0:隐藏\r\n1:添加时显示\r\n2:编辑时显示\r\n3:添加编辑时都显示', '0', '0', '19', '1', '3', '3', '0', '1416763809', '1433066508', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('97', '16', '状态', '', 'status', 'radio', 'status', '0:禁用\r\n1:正常', '0', '0', '20', '1', '3', '1', '0', '1416763913', '1416767097', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('98', '18', '节点标题', '', 'title', 'string', 'title', '', '0', '0', '81', '1', '3', '', '0', '1416906417', '1416906417', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('99', '18', '节点标识', '', 'name', 'string', 'name', '', '0', '0', '82', '1', '3', '', '0', '1416906437', '1416906437', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('100', '18', '上级节点', '', 'pid', 'select', 'pid', 'getNodeTree', '1', '0', '80', '1', '3', '', '0', '1416906492', '1417331475', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('101', '18', '节点说明', '', 'note', 'string', 'note', '', '0', '0', '99', '1', '3', '', '0', '1416925044', '1416925044', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('102', '19', '用户组名称', '', 'title', 'string', 'title', '', '0', '0', '98', '1', '3', '', '0', '1423588404', '1423589410', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('103', '19', '地址访问权限', '设置不可以访问的地址', 'noaccessurl', 'textarea', 'noaccessurl', '', '0', '0', '99', '1', '3', '', '0', '1423589398', '1423589398', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('104', '8', '留言内容', '留言的内容', 'content', 'textarea', 'content', '', '0', '1', '99', '1', '3', '', '0', '1425556537', '1425556537', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('105', '8', '状态', '状态', 'status', 'radio', 'status', '0:禁止\r\n1:正常', '0', '0', '99', '1', '3', '', '0', '1425556747', '1425556747', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('106', '8', '姓名', '姓名', 'name', 'string', 'name', '', '0', '0', '99', '1', '3', '', '0', '1425558112', '1425558112', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('107', '9', '分类类型标识符', '标识分类是文章还是产品', 'category_type', 'string', 'category_type', '', '0', '0', '99', '1', '3', '', '0', '1426176145', '1426223600', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('108', '9', '分类列表页模板', 'list_tpl', 'list_tpl', 'string', 'list_tpl', '', '0', '0', '4', '1', '3', '', '0', '1426411835', '1426412831', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('109', '9', '分类详情页模板', 'detail_tpl', 'detail_tpl', 'string', 'detail_tpl', '', '0', '0', '4', '1', '3', '', '0', '1426412879', '1426412896', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('110', '8', '邮箱', '', 'email', 'string', 'email', '', '0', '0', '99', '1', '3', '', '0', '1426426635', '1426426635', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('111', '8', 'ip地址', '', 'ip', 'string', 'ip', '', '0', '0', '99', '1', '3', '', '0', '1426426889', '1426426889', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('112', '19', '是否允许后台登陆', '是否允许此用户组的用户登陆', 'is_adminlogin', 'radio', 'is_adminlogin', '0:禁止登陆\r\n1:允许登陆', '0', '1', '99', '1', '3', '0', '0', '1427257603', '1427257650', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('113', '7', '导航图片', '属于此导航的图片,可用于当前导航的封面,banner等', 'pic', 'picture', 'pic', '', '0', '0', '9', '1', '3', '', '1', '1427269738', '1427269765', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('114', '5', '模块位置标识', '模块位置标识符(使用时可以用id或标识符)', 'name', 'string', 'name', '', '0', '0', '2', '1', '3', '', '0', '1427434484', '1427506217', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('115', '16', '属性类型TAB', '对属性进行TAB分页管理', 'attrtype', 'radio', 'attrtype', '0:基础\r\n1:扩展', '0', '0', '99', '1', '3', '0', '0', '1428129620', '1428129693', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('116', '4', '价格', '产品单价', 'price', 'number', 'price', '', '0', '0', '15', '1', '3', '', '0', '1428393069', '1428393362', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('117', '4', '销量', '销量', 'sale_num', 'number', 'sale_num', '', '0', '0', '16', '1', '3', '', '0', '1428393196', '1428393393', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('118', '4', '库存', '库存量', 'stock', 'number', 'stock', '', '0', '0', '20', '1', '3', '', '0', '1428393539', '1428393553', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('119', '19', '后台首页', '当前用户组登陆后的第一个页面', 'admin_index', 'string', 'admin_index', '', '0', '0', '99', '1', '3', 'Index/index', '0', '1428900942', '1428900942', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('120', '2', '主题模板', '模板文件默认为index', 'index_tpl', 'string', 'index_tpl', '', '0', '0', '15', '1', '3', '', '1', '1429004905', '1429116096', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('122', '2', '单页标识', '用于生成友好URL', 'name', 'string', 'name', '', '0', '0', '14', '1', '3', '', '1', '1429115503', '1429116093', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('124', '13', '说明extra数据是函数返回还是字符串解析生成', '只有当extra数据不为空时有用', 'extranote', 'radio', 'extranote', '0:字符串解析\r\n1:系统函数返回', '0', '0', '99', '1', '3', '0', '0', '1429407017', '1429417558', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('125', '4', '产品类型', '产品的扩展属性', 'goods_type_id', 'attribute', 'goods_type_id', '', '0', '0', '99', '1', '3', '', '1', '1429427075', '1429427083', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('126', '1', '标题颜色', '', 'color', 'color', 'color', '', '0', '0', '3', '1', '3', '', '0', '1431831769', '1431833655', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('127', '20', '所属用户组', '用户角色', 'member_group_id', 'select', 'member_group_id', 'getMemberGroupList', '1', '0', '2', '1', '3', '2', '0', '1433065973', '1433067263', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('128', '20', '用户名', '用户名要5位数以上', 'username', 'string', 'username', '', '0', '1', '3', '1', '1', '', '0', '1433066631', '1433067264', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('129', '20', '密码', '密码要5位数以上', 'password', 'password', 'password', '', '0', '1', '4', '1', '1', '', '0', '1433066670', '1433067264', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('130', '20', '确认密码', '请再次输入密码确认', 'repassword', 'password', 'repassword', '', '0', '1', '5', '1', '1', '', '0', '1433066723', '1433067265', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('131', '20', '昵称', '用户对应的一个昵称名字', 'nickname', 'string', 'nickname', '', '0', '0', '6', '1', '3', '', '0', '1433066762', '1433067266', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('132', '20', '邮箱', '', 'email', 'string', 'email', '', '0', '0', '7', '1', '3', '', '0', '1433066809', '1435685573', '请输入正确格式的邮箱', '邮箱格式不正确', '邮箱格式正确', '^[\\w-]+(\\.[\\w-]+)*@[\\w-]+(\\.[\\w-]+)+$');
INSERT INTO `kl_model_attr` VALUES ('133', '20', '手机号', '', 'mobile', 'string', 'mobile', '', '0', '1', '8', '1', '3', '', '0', '1433066845', '1436117906', '请输入正确格式的手机号', '手机号格式不正确', '手机号格式正确', '[mobile]');
INSERT INTO `kl_model_attr` VALUES ('134', '20', '会员状态', '', 'status', 'radio', 'status', '0:禁用\r\n1:正常', '0', '0', '9', '1', '3', '1', '0', '1433066890', '1433067269', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('135', '20', '地址', '', 'diqu', 'liandong', 'diqu', '', '0', '1', '0', '1', '3', '', '0', '1433067171', '1433067256', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('136', '20', '详细联系地址', '', 'address', 'string', 'address', '', '0', '0', '1', '1', '3', '', '0', '1433067224', '1433067262', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('137', '14', '列表格式', '生成当前模型的列表格式,标题:字段|函数', 'list_format', 'bigtextarea', 'list_format', '', '0', '0', '80', '1', '3', '', '0', '1434611254', '1439566488', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('138', '14', '回收站列表格式', '回收站列表的格式', 'recycle_format', 'bigtextarea', 'recycle_format', '', '0', '0', '90', '1', '3', '', '0', '1434643074', '1439566505', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('139', '14', '系统或自定义模型', '系统模型不能删除自定义模型可以自由删除', 'modeltype', 'radio', 'modeltype', 'system:系统模型\r\nother:自定义模型', '0', '0', '99', '1', '3', 'other', '0', '1434645783', '1434645832', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('145', '16', '表单验证提示信息', '', 'data_ts', 'string', 'data_ts', '', '0', '0', '99', '1', '3', '', '1', '1435683167', '1435683167', null, null, null, null);
INSERT INTO `kl_model_attr` VALUES ('146', '16', '表单验证失败提示', '', 'data_err', 'string', 'data_err', '', '0', '0', '99', '1', '3', '', '1', '1435683211', '1435683211', '', null, null, null);
INSERT INTO `kl_model_attr` VALUES ('147', '16', '表单验证成功提示', '', 'data_ok', 'string', 'data_ok', '', '0', '0', '99', '1', '3', '', '1', '1435683248', '1435683248', '', '', null, null);
INSERT INTO `kl_model_attr` VALUES ('148', '16', '表单验证正则式', '', 'data_reg', 'string', 'data_reg', '', '0', '0', '99', '1', '3', '', '1', '1435683289', '1435683488', '', '', '', null);
INSERT INTO `kl_model_attr` VALUES ('149', '22', '配置标识', '用于C函数调用，只能使用英文且不能重复', 'name', 'string', 'name', '', '0', '0', '1', '1', '3', '', '0', '1435743146', '1435744516', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('150', '22', '配置标题', '用于显示的配置标题', 'title', 'string', 'title', '', '0', '0', '2', '1', '3', '', '0', '1435743182', '1435744520', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('151', '22', '排序', '用于分组显示的顺序', 'sort', 'number', 'sort', '', '0', '0', '3', '1', '3', '', '0', '1435743215', '1435744521', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('152', '22', '配置类型', '系统会根据不同的类型解析配置值', 'type', 'select', 'type', 'getFormType', '1', '0', '4', '1', '3', '', '0', '1435743257', '1435744522', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('153', '22', '配置分组', '默认的是添加到默认分组', 'group', 'select', 'group', '1:基本\r\n4:网站\r\n3:邮件\r\n2:系统\r\n5:支付\r\n6:联系', '0', '0', '5', '1', '3', '', '0', '1435743473', '1435744523', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('158', '22', '配置详细说明', '', 'note', 'textarea', 'note', '', '0', '0', '8', '1', '3', '', '0', '1435744278', '1435744527', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('156', '22', '配置值', '配置的默认值', 'value', 'textarea', 'value', '', '0', '0', '6', '1', '3', '', '0', '1435744204', '1435744524', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('157', '22', '配置项', '如果属性是select,radio,checkbox等类似表单的话此项必填', 'extra', 'textarea', 'extra', '', '0', '0', '7', '1', '3', '', '0', '1435744239', '1435744525', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('159', '22', '只有在开发模式下才能显示', '关闭开发模式后此配置项不显示', 'no_del', 'radio', 'no_del', '0:是\r\n1:否', '0', '0', '9', '1', '3', '', '0', '1435744408', '1435745588', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('160', '22', '什么时候显示', '关闭开发模式后在网站设置中是否显示', 'is_show', 'radio', 'is_show', '0:隐藏\r\n1:添加时显示\r\n2:编辑时显示\r\n3:添加编辑时都显示', '0', '0', '10', '1', '3', '', '0', '1435744495', '1435744530', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('161', '22', '表单验证正则式', '', 'data_reg', 'string', 'data_reg', '', '0', '0', '99', '1', '3', '', '1', '1436115684', '1436115684', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('162', '22', '表单验证成功提示', '', 'data_ok', 'string', 'data_ok', '', '0', '0', '99', '1', '3', '', '1', '1436115738', '1436115738', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('163', '22', '表单验证失败提示', '', 'data_err', 'string', 'data_err', '', '0', '0', '99', '1', '3', '', '1', '1436115811', '1436115811', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('164', '22', '表单验证提示信息', '', 'data_ts', 'string', 'data_ts', '', '0', '0', '99', '1', '3', '', '1', '1436115872', '1436115872', '', '', '', '');
INSERT INTO `kl_model_attr` VALUES ('165', '14', '搜索字段格式', '位于列表页上面搜索的表单', 'search_format', 'bigtextarea', 'search_format', '', '0', '0', '79', '1', '3', '', '0', '1440571502', '1440571517', '', '', '', '');

-- ----------------------------
-- Table structure for kl_module
-- ----------------------------
DROP TABLE IF EXISTS `kl_module`;
CREATE TABLE `kl_module` (
  `module_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `modulepos_id` int(11) unsigned NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `pic` int(11) DEFAULT NULL,
  `sort` tinyint(4) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_module
-- ----------------------------
INSERT INTO `kl_module` VALUES ('1', '3', '首页幻灯片1', '', '246', '0', '0', '1425051680', '1');
INSERT INTO `kl_module` VALUES ('2', '3', '首页幻灯片2', 'http://www.zhaokeli.com', '245', '0', '1409930158', '1411263971', '1');
INSERT INTO `kl_module` VALUES ('3', '3', '幻灯片3', 'javascript:;', '247', '0', '0', '0', '1');
INSERT INTO `kl_module` VALUES ('4', '3', '幻灯片4', '', '248', '0', '0', '0', '1');
INSERT INTO `kl_module` VALUES ('5', '1', '联系电话', 'javascript:;', '268', '0', null, null, '1');
INSERT INTO `kl_module` VALUES ('6', '4', 'cntv', 'javascript:;', '269', '0', null, null, '1');
INSERT INTO `kl_module` VALUES ('7', '4', '河南', 'javascript:;', '270', '0', null, null, '1');
INSERT INTO `kl_module` VALUES ('8', '4', '电视台', 'javascript:;', '271', '0', null, null, '1');
INSERT INTO `kl_module` VALUES ('9', '4', '联通', 'javascript:;', '272', '0', null, null, '1');
INSERT INTO `kl_module` VALUES ('10', '1', '文章列表页banner', 'javascript:;', '274', '0', '1427522656', '1427522656', '1');
INSERT INTO `kl_module` VALUES ('11', '1', '文章详细页banner', 'javascript:;', '275', '0', '1427522937', '1427522937', '1');

-- ----------------------------
-- Table structure for kl_modulepos
-- ----------------------------
DROP TABLE IF EXISTS `kl_modulepos`;
CREATE TABLE `kl_modulepos` (
  `modulepos_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `tplcode` text,
  `sort` int(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`modulepos_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_modulepos
-- ----------------------------
INSERT INTO `kl_modulepos` VALUES ('1', '默认位置', '', '0', '1409928591', '1409928705', 'default');
INSERT INTO `kl_modulepos` VALUES ('3', '首页幻灯片', ' <ank:ad posid=\"3\" name=\"vo\">\r\n 这个是广告：{$vo.title}\r\n </ank:ad>', '1', '1409930190', '1450081949', 'huandengpian');
INSERT INTO `kl_modulepos` VALUES ('4', '合作伙伴', '<div>			\r\n<p class=\"pp2\">合作伙伴</p>\r\n			<p class=\"eng\">Partners</p>\r\n			<ul class=\"huoban_dv\"> \r\n           <ank:module modulepos_id=\"4\">\r\n<li><a href=\"{$vo.url}\"><img src=\"{$vo.pic|getPicture}\" width=\"54\" height=\"56\" alt=\"{$vo.title}\" /></a></li>\r\n			</ank:module>\r\n			</ul>\r\n			<div class=\"clear\"></div>\r\n		</div>', '1', null, '1450083763', 'hezuohuoban');
INSERT INTO `kl_modulepos` VALUES ('5', '联系我们', '<div class=\"lianxi\">\r\n			<p class=\"pp2\">联系我们</p>\r\n			<p class=\"eng\">Contact Us</p>\r\n			<div class=\"lxfs\">\r\n				<p class=\"pp3\">联系电话：0371-56701668 / 86060618<span style=\"width:60px; display:inline-block;\"> </span>13838034400   13213204400</p> \r\n				<p class=\"pp3\">联<span style=\"width:6px; display:inline-block;\"> </span>系<span style=\"width:6px; display:inline-block;\"> </span>人：王先生</p>\r\n				<p class=\"pp3\">E-MAIL<span style=\"width:6px; display:inline-block;\"> </span>：hntv1618@163.COM</p>\r\n				<p class=\"pp3\">地<span style=\"width:24px; display:inline-block;\"> </span>址：郑州市金水区花园路159号罗马假日2-30层</p>			\r\n			</div>\r\n		</div>', '1', null, '1450083693', 'lianxiwomen');

-- ----------------------------
-- Table structure for kl_nav
-- ----------------------------
DROP TABLE IF EXISTS `kl_nav`;
CREATE TABLE `kl_nav` (
  `nav_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) DEFAULT NULL COMMENT '频道标题',
  `url` char(100) DEFAULT NULL COMMENT '频道连接',
  `meta_title` varchar(50) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_descr` text,
  `sort` tinyint(10) unsigned DEFAULT '0' COMMENT '导航排序',
  `target` tinyint(1) DEFAULT '0',
  `create_time` int(10) unsigned DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '状态',
  `pic` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nav_id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_nav
-- ----------------------------
INSERT INTO `kl_nav` VALUES ('1', '0', '首页', '/', 'seo标题', 'seo关键字', 'seo描述', '0', '0', '1379475111', '1450083433', '1', '0');
INSERT INTO `kl_nav` VALUES ('5', '0', '代购专区', '/cate/gaoxiao.html', null, null, null, '2', '0', '1393176526', '1450079771', '1', '0');
INSERT INTO `kl_nav` VALUES ('9', '0', '秒杀专区', '/cate/lizhi.html', null, null, null, '3', '0', '1408463746', '1450079777', '1', '0');
INSERT INTO `kl_nav` VALUES ('7', '0', '礼品赠送', '/cate/gexing.html', '', '', '', '1', '0', '1396493193', '1450079724', '1', '0');
INSERT INTO `kl_nav` VALUES ('10', '0', '全部分类', '/allcate.html', null, null, null, '9', '0', '1408467223', '1450081907', '0', '0');
INSERT INTO `kl_nav` VALUES ('12', '0', '关于我们', '/cate/aiqing.html', '', '', '', '3', '0', '1411271599', '1450079793', '1', '0');
INSERT INTO `kl_nav` VALUES ('13', '0', '商品选购', '/cate/qinglv.html', '', '', '', '0', '0', '1426405281', '1450079716', '1', '0');
INSERT INTO `kl_nav` VALUES ('14', '0', '商城动态', '/cate/kongjian.html', '', '', '', '4', '0', '1426405533', '1450079755', '1', '0');
INSERT INTO `kl_nav` VALUES ('15', '0', '联系我们', '/cate/jingdian.html', '', '', '', '5', '0', '1426405547', '1450079760', '1', '0');
INSERT INTO `kl_nav` VALUES ('16', '0', '其它分类', '/cate/other.html', '', '', '', '7', '0', '1426405596', '1450081938', '0', '0');

-- ----------------------------
-- Table structure for kl_node
-- ----------------------------
DROP TABLE IF EXISTS `kl_node`;
CREATE TABLE `kl_node` (
  `node_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned DEFAULT '0',
  `title` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `note` varchar(100) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT '99',
  `is_all` tinyint(1) unsigned zerofill NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned DEFAULT '1',
  PRIMARY KEY (`node_id`)
) ENGINE=MyISAM AUTO_INCREMENT=129 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_node
-- ----------------------------
INSERT INTO `kl_node` VALUES ('1', '0', '系统功能', 'index', '', null, '1425472664', '98', '1', '1');
INSERT INTO `kl_node` VALUES ('2', '3', '添加配置', 'Config/add', null, '1416906873', '1416907190', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('3', '0', '配置模块', 'Config', null, '1416907157', '1417931606', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('4', '0', '数据库模块', '', null, '1416907400', '1417931605', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('5', '0', '文件管理模块', 'File', null, '1416907461', '1417931605', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('6', '0', '菜单模块', 'Menu', null, '1416907484', '1433170038', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('7', '0', '表单模块', 'Model', null, '1416907510', '1417931604', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('8', '0', '表单属性模块', 'Modelattr', null, '1416923977', '1417931603', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('9', '0', '节点模块', 'Node', null, '1416924010', '1417931602', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('10', '9', '节点列表', 'Node/index', null, '1416924149', '1416924149', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('11', '9', '添加节点', 'Node/add', null, '1416924194', '1416924194', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('12', '9', '编辑节点', 'Node/edit', null, '1416924217', '1416924217', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('13', '9', '删除节点', 'Node/del', null, '1416924237', '1417931623', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('14', '8', '表单属性列表', 'Modelattr/index', null, '1416924364', '1416924364', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('15', '8', '添加表单属性', 'Modelattr/add', null, '1416924393', '1416924393', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('16', '8', '编辑表单属性', 'Modelattr/edit', null, '1416924420', '1416924420', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('17', '8', '删除表单属性', 'Modelattr/del', null, '1416924441', '1416924441', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('18', '7', '表单列表', 'Model/index', null, '1416924485', '1416924485', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('19', '7', '添加表单', 'Model/add', null, '1416924510', '1416924510', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('20', '7', '编辑表单', 'Model/edit', null, '1416924526', '1416924526', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('21', '7', '删除表单', 'Model/del', null, '1416924541', '1416924541', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('22', '6', '菜单列表', 'Menu/index', null, '1416924602', '1433170035', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('23', '6', '添加菜单', 'Menu/add', null, '1416924623', '1433170031', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('24', '6', '编辑菜单', 'Menu/edit', null, '1416924641', '1433170029', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('25', '6', '删除菜单', 'Menu/del', null, '1416924657', '1433170027', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('26', '4', '网站打包', 'Database/webtozip', '', '1416924841', '1416925257', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('27', '3', '配置列表', 'Config/index', null, '1416924883', '1416924883', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('28', '3', '编辑配置', 'Config/edit', null, '1416924902', '1416924902', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('29', '3', '查看配置分组', 'Config/group', null, '1416924947', '1416924947', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('30', '3', '批量保存配置', 'Config/save', '查看配置分组后批量保存的操作', '1416925139', '1416925139', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('31', '3', '删除配置', 'Config/del', '', '1416925163', '1416925163', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('32', '4', '数据库备份还原', 'Database/index', '', '1416925217', '1416925217', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('33', '4', '优化数据表', 'Datebase/optimize', '', '1416925283', '1416925283', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('34', '4', '修复数据表', 'Database/repair', '', '1416925305', '1416925305', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('35', '4', '删除数据库备份', 'Database/del', '', '1416925397', '1416925397', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('36', '4', '删除网站备份', 'Database/delwebzip', '', '1416925438', '1416925438', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('37', '5', '附件列表', 'File/attach', '', '1416925519', '1416925519', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('38', '5', '删除附件', 'File/delattach', '', '1416925542', '1416925542', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('39', '5', '图片管理', 'File/imglist', '', '1416925564', '1416925564', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('40', '5', '删除图片', 'File/delimg', '', '1416925593', '1416925593', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('41', '0', '用户模块', 'Member', '', '1416925764', '1417931602', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('42', '1', '后台首页', 'Index/index', '', '1417333676', '1417333676', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('43', '0', '用户组模块', 'Membergroup', '', '1417346414', '1417931601', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('44', '43', '用户组列表', 'Membergroup/index', '', '1417346438', '1417346438', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('45', '43', '添加用户组', 'Membergroup/add', '', '1417346453', '1417346453', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('46', '43', '编辑用户组', 'Membergroup/edit', '', '1417346469', '1417346469', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('47', '43', '删除用户组', 'Membergroup/del', '', '1417346488', '1417346488', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('48', '43', '用户组授权', 'Membergroup/auth', '', '1417346512', '1417346512', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('49', '41', '用户列表', 'Member/index', '', '1417346558', '1417346558', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('50', '41', '用户回收站', 'Member/recycling', '', '1417346590', '1417346590', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('51', '41', '用户登陆日志', 'Member/log', '', '1417346611', '1417346611', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('52', '41', '删除用户登陆日志', 'Member/dellog', '', '1417346642', '1417346642', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('53', '41', '添加用户', 'Member/add', '', '1417346674', '1417346674', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('54', '41', '编辑用户信息', 'Member/edit', '', '1417346691', '1417346691', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('55', '41', '修改用户密码', 'Member/updatepwd', '', '1417346716', '1417346716', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('56', '41', '移动用户到回收站', 'Member/del', '', '1417346744', '1417346744', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('57', '41', '彻底删除用户', 'Member/dele', '', '1417346769', '1417346769', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('58', '41', '恢复用户帐号', 'Member/huifu', '', '1417346795', '1417346795', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('59', '111', '添加广告位', 'Modulepos/add', '', '1423497462', '1423497697', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('60', '110', '添加友情链接', 'Link/add', '', '1423497491', '1423497657', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('61', '110', '编辑友情链接', 'Link/edit', '', '1423497515', '1423497641', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('62', '110', '删除友情链接', 'Link/del', '', '1423497531', '1423497621', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('63', '0', '其它功能模块', 'Other', '', '1423497558', '1423497568', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('64', '111', '编辑广告位', 'Modulepos/edit', '', '1423497722', '1423497722', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('65', '111', '删除广告位', 'Modulepos/del', '', '1423497742', '1423497742', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('66', '112', '添加广告', 'Module/add', '', '1423497759', '1423497759', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('67', '112', '编辑广告', 'Module/edit', '', '1423497780', '1423497780', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('68', '112', '删除广告', 'Module/del', '', '1423497796', '1433170270', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('69', '0', '文章模块', 'Article', '', '1423503386', '1433169803', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('70', '69', '文章列表', 'Article/index', '', '1423503433', '1423503433', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('71', '69', '添加文章', 'Article/add', '', '1423503451', '1423503451', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('72', '69', '编辑文章', 'Article/edit', '', '1423503473', '1423503473', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('73', '69', '移动文章到回收站', 'Article/del', '', '1423503500', '1423503500', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('74', '69', '删除文章', 'Article/dele', '', '1423503550', '1423503550', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('75', '69', '文章草稿箱', 'Article/draftbox', '', '1423503625', '1423503625', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('76', '69', '文章回收站', 'Article/recycle', '', '1423503655', '1423503655', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('77', '69', '恢复文章', 'Article/huifu', '', '1423504140', '1423504140', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('78', '0', '分类模块', '', '', '1423504183', '1433170010', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('79', '78', '添加分类', 'Category/add', '', '1423504205', '1423504205', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('80', '78', '编辑分类', 'Category/edit', '', '1423504225', '1423504225', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('81', '78', '删除分类', 'Category/del', '', '1423504248', '1423504248', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('82', '1', '清除系统缓存', 'Other/clearCache', '', '1425472798', '1425472798', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('83', '0', '留言模块', '', '', '1425565620', '1433170406', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('84', '83', '删除留言', 'Comments/del', '', '1425565641', '1425565641', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('85', '83', '清空留言', 'Comments/delall', '', '1425565674', '1425565674', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('86', '0', '产品模块', 'Goods', '', '1426221360', '1426221368', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('87', '86', '添加产品', 'Goods/add', '', '1426221386', '1426221386', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('88', '86', '产品列表', 'Goods/index', '', '1426221404', '1426221404', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('89', '86', '产品草稿箱', 'Goods/draftbox', '', '1426221441', '1426221441', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('90', '86', '产品回收站', 'Goods/recycle', '', '1426221464', '1426221464', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('91', '86', '移动产品到回收站', 'Goods/del', '', '1426221491', '1426221491', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('92', '86', '删除产品', 'Goods/dele', '', '1426221509', '1426221509', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('93', '86', '编辑产品', 'Goods/edit', '', '1426221524', '1426221524', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('94', '78', '产品分类', 'Category/index?category_type=goods', '', '1426221553', '1426221553', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('95', '0', '扩展模块', 'Addons', '', '1426376684', '1426376710', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('96', '95', '插件管理', 'Addons/index', '', '1426376724', '1426376724', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('97', '95', '安装插件', 'Addons/install', '', '1426376951', '1426376951', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('98', '95', '卸载插件', 'Addons/unstall', '', '1426376978', '1426376978', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('99', '95', '启用插件', 'Addons/qiyong', '', '1426377006', '1426377006', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('100', '95', '禁用插件', 'Addons/jinyong', '', '1426377032', '1426377032', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('101', '95', '钩子管理', 'Hook/index', '', '1426377075', '1426377075', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('102', '95', '启用钩子', 'Hook/qiyong', '', '1426377098', '1426377098', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('103', '95', '禁用钩子', 'Hook/jinyong', '', '1426377123', '1426377123', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('104', '95', '设置钩子', 'Hook/manage', '', '1426377164', '1426377164', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('105', '95', '删除钩子', 'Hook/del', '', '1426377183', '1426377183', '99', '0', '1');
INSERT INTO `kl_node` VALUES ('106', '69', '清空文章回收站', 'Article/delall', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('107', '86', '移动产品', 'Goods/move', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('108', '86', '恢复产品', 'Goods/huifu', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('109', '86', '清空产品回收站', 'Goods/delall', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('110', '0', '友情链接', '', null, null, '1433170256', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('111', '0', '广告位', '', null, null, '1433170255', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('112', '0', '广告', '', null, null, '1433170254', '99', '1', '1');
INSERT INTO `kl_node` VALUES ('113', '0', '单页模块', '', '', null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('114', '113', '添加单页', 'Single/add', '', null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('115', '113', '编辑单页', 'Single/edit', '', null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('116', '113', '删除单页', 'Single/del', '', null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('117', '0', '导航模块', '', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('118', '117', '添加导航', 'Nav/add', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('119', '117', '编辑导航', 'Nav/edit', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('120', '117', '删除导航', 'Nav/del', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('121', '117', '导航列表', 'Nav/index', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('122', '113', '单页列表', 'Single/index', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('123', '111', '广告位列表', 'Modulepos/index', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('124', '112', '广告列表', 'Module/index', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('125', '78', '全部分类列表', 'Category/index', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('126', '110', '友情链接列表', 'Link/index', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('127', '83', '留言列表', 'Comments/index', null, null, null, '99', '0', '1');
INSERT INTO `kl_node` VALUES ('128', '78', '文章分类', 'Category/index?category_type=article', null, null, null, '99', '0', '1');

-- ----------------------------
-- Table structure for kl_order
-- ----------------------------
DROP TABLE IF EXISTS `kl_order`;
CREATE TABLE `kl_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned DEFAULT NULL,
  `order_sn` varchar(255) DEFAULT NULL,
  `consignee_diqu` varchar(255) DEFAULT NULL,
  `consignee_name` varchar(255) DEFAULT NULL,
  `consignee_detail` varchar(255) DEFAULT NULL,
  `consignee_mobile` varchar(255) DEFAULT NULL,
  `consignee_email` varchar(255) DEFAULT NULL,
  `order_total` double DEFAULT NULL,
  `order_status` tinyint(1) unsigned DEFAULT '1',
  `pay_type` varchar(255) DEFAULT NULL,
  `pay_trade_no` varchar(255) DEFAULT NULL,
  `pay_time` int(11) DEFAULT NULL,
  `fahuo_time` int(11) DEFAULT NULL,
  `wuliu_name` varchar(255) DEFAULT NULL,
  `wuliu_danhao` varchar(255) DEFAULT NULL,
  `youbian` varchar(255) DEFAULT NULL,
  `order_note` varchar(255) DEFAULT NULL,
  `action_note` varchar(255) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_order
-- ----------------------------
INSERT INTO `kl_order` VALUES ('10', '1', '1512051222437', '北京市市辖区石景山区', '赵克立', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '13633719215', null, '100', '2', null, null, null, null, null, null, '467500', '你好请在周五发货', null, '1449281182');
INSERT INTO `kl_order` VALUES ('11', '1', '1512054892419', '山西省太原市杏花岭区', '张三', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '13589758685', null, '200', '1', null, null, null, null, null, null, '460000', 'asdfasdfasdfasdf', null, '1449282611');
INSERT INTO `kl_order` VALUES ('12', '1', '1512059939517', '河南省郑州市金水区', '赵克立', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '13633719215', null, '700', '1', null, null, null, null, null, null, '4675000', '8888888888888888', null, '1449296280');
INSERT INTO `kl_order` VALUES ('9', '1', '1512055264858', '山西省太原市杏花岭区', '张三', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '13589758685', null, '200', '1', null, null, null, null, null, null, '460000', '', null, '1449280850');
INSERT INTO `kl_order` VALUES ('13', '1', '1512059665134', '河南省郑州市金水区', '赵克立', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '13633719215', null, '200', '1', null, null, null, null, null, null, '4675000', '', null, '1449326370');
INSERT INTO `kl_order` VALUES ('14', '1', '1512068737973', '河南省郑州市金水区', '赵克立', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '13633719215', null, '200', '1', null, null, null, null, null, null, '4675000', '', null, '1449379726');
INSERT INTO `kl_order` VALUES ('15', '1', '1512062780160', '河南省郑州市金水区', '赵克立', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '13633719215', null, '200', '1', null, null, null, null, null, null, '4675000', '', null, '1449400544');
INSERT INTO `kl_order` VALUES ('16', '1', '1512075502008', '北京市市辖区石景山区', '赵克立', '河南省郑州市金水区文化路与北环路交叉口路西瀚海爱特中心1004室', '13633719215', null, '1', '1', null, null, null, null, '', '', '467500', '', '', '1449449904');

-- ----------------------------
-- Table structure for kl_order_goods
-- ----------------------------
DROP TABLE IF EXISTS `kl_order_goods`;
CREATE TABLE `kl_order_goods` (
  `order_goods_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned DEFAULT NULL,
  `order_id` int(11) unsigned DEFAULT NULL,
  `goods_id` int(11) unsigned DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `total` double DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_order_goods
-- ----------------------------
INSERT INTO `kl_order_goods` VALUES ('10', '1', '11', '1', '2', '100', '200', '1449282611');
INSERT INTO `kl_order_goods` VALUES ('9', '1', '10', '1', '1', '100', '100', '1449281182');
INSERT INTO `kl_order_goods` VALUES ('8', '1', '9', '1', '2', '100', '200', '1449280850');
INSERT INTO `kl_order_goods` VALUES ('11', '1', '12', '1', '3', '100', '300', '1449296280');
INSERT INTO `kl_order_goods` VALUES ('12', '1', '12', '1', '4', '100', '400', '1449296280');
INSERT INTO `kl_order_goods` VALUES ('13', '1', '13', '1', '2', '100', '200', '1449326370');
INSERT INTO `kl_order_goods` VALUES ('14', '1', '14', '1', '2', '100', '200', '1449379726');
INSERT INTO `kl_order_goods` VALUES ('15', '1', '15', '1', '2', '100', '200', '1449400544');
INSERT INTO `kl_order_goods` VALUES ('16', '1', '16', '1', '1', '100', '100', '1449449904');

-- ----------------------------
-- Table structure for kl_picture
-- ----------------------------
DROP TABLE IF EXISTS `kl_picture`;
CREATE TABLE `kl_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `uid` int(11) unsigned NOT NULL,
  `srcname` varchar(255) DEFAULT NULL,
  `destname` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT '' COMMENT '路径',
  `thumbpath` varchar(255) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '状态',
  `from` varchar(50) DEFAULT NULL COMMENT 'image source',
  `extra` varchar(255) DEFAULT NULL,
  `sha1` varchar(50) DEFAULT NULL,
  `create_time` int(10) unsigned DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15641 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_picture
-- ----------------------------
INSERT INTO `kl_picture` VALUES ('15638', '1', 'b5159f246843b777cebb7241df5a264c.png', '1440726455171.png', '/Uploads/image/20150828/1440726455171.png', '/Uploads/image/thumb/20150828/1440726455171.png', '1', 'umeditor', null, 'a01a8523812fb8cc99e37a8866db5734eba72c4e', '1440726455');
INSERT INTO `kl_picture` VALUES ('15639', '1', 'Screenshot_2015-08-06-09-10-25.png', '1440727929997132.png', '/Uploads/image/20150828/1440727929997132.png', '/Uploads/image/thumb/20150828/1440727929997132.png', '1', 'ueditor', null, 'e4751a94a5add1cb4de4c8080747c316764c14d4', '1440727929');
INSERT INTO `kl_picture` VALUES ('15640', '1', 'asdf.png', '144429065269885.png', '/Uploads/image/20151008/144429065269885.png', '/Uploads/image/thumb/20151008/144429065269885.png', '1', null, null, 'adf595aed4a866b50b49491da2183d5a43cac233', '1444290652');

-- ----------------------------
-- Table structure for kl_single
-- ----------------------------
DROP TABLE IF EXISTS `kl_single`;
CREATE TABLE `kl_single` (
  `single_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `content` text,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `index_tpl` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`single_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kl_single
-- ----------------------------
INSERT INTO `kl_single` VALUES ('1', 'guanyuwomen', '关于我们', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; white-space: normal;\">河南金木水火文化传播有限公司，是一家集影视制作、活动策划、装饰设计、平面设计、商业摄影创作于一体的专业文化传播有限公司。 知识爆炸的气流， 激荡了思想的风暴 ，一群思维裂变的狂人 和 一群大脑卓越的绅士，激荡在这中原大地 ，艺术、 哲学、现代、无厘…… 思辨集结着逆袭灵魂，灵魂追逐着金色的路，路， 一路向前。 河南金木水火文化传播有限公司，拥有一流的人才质量管理体系，近年来与诸多大公司建立了良好的信誉合作。本公司注重人才培养，艺术设计精湛，技术力量雄厚，汇聚了一批优秀的专业艺术和技术人才。 河南金木水火文化传播有限公司拥有专业而且实践经验丰富的策划团队；有多年成功经验的三维动画制作师、有大片制作经验的特效设计师、多媒体设计师等后期制作团队；省级专业摄像师、北京胶片广告摄像师及北京著名导演等拍摄团队精诚协作；完全满足不同客户的不同档次广告创作需求。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; white-space: normal;\">河南金木水火文化传播有限公司是一支富有激情、精干而又充满活力的专业影视广告创作团队，新锐的创作思想，将数码技术与现代艺术进行完美结合，以专业的视角展示企业形象、传播产品信息，充分整合行业资源优势，以最大程度满足不同行业领域的客户需要，向社会各界提供一流的影视技术服务。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; white-space: normal;\">河南金木水火文化传播有限公司凭借多年专业影视制作经验及多个央视级别大片制作经验，在业界赢得良好口碑，运用国际先进视频技术及行业内先进的高端设备，为客户提供多种广告片及宣传片解决方案，在保持水准的前提下，降低制作费用，为企业提供前期编、导、拍、后期制作等全方位服务。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; white-space: normal;\">河南金木水火文化传播有限公司，是一家集影视制作、活动策划、装饰设计、平面设计、商业摄影创作于一体的专业文化传播有限公司。 知识爆炸的气流， 激荡了思想的风暴 ，一群思维裂变的狂人 和 一群大脑卓越的绅士，激荡在这中原大地 ，艺术、 哲学、现代、无厘…… 思辨集结着逆袭灵魂，灵魂追逐着金色的路，路， 一路向前。 河南金木水火文化传播有限公司，拥有一流的人才质量管理体系，近年来与诸多大公司建立了良好的信誉合作。本公司注重人才培养，艺术设计精湛，技术力量雄厚，汇聚了一批优秀的专业艺术和技术人才。 河南金木水火文化传播有限公司拥有专业而且实践经验丰富的策划团队；有多年成功经验的三维动画制作师、有大片制作经验的特效设计师、多媒体设计师等后期制作团队；省级专业摄像师、北京胶片广告摄像师及北京著名导演等拍摄团队精诚协作；完全满足不同客户的不同档次广告创作需求。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; white-space: normal;\">河南金木水火文化传播有限公司是一支富有激情、精干而又充满活力的专业影视广告创作团队，新锐的创作思想，将数码技术与现代艺术进行完美结合，以专业的视角展示企业形象、传播产品信息，充分整合行业资源优势，以最大程度满足不同行业领域的客户需要，向社会各界提供一流的影视技术服务。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; white-space: normal;\">河南金木水火文化传播有限公司凭借多年专业影视制作经验及多个央视级别大片制作经验，在业界赢得良好口碑，运用国际先进视频技术及行业内先进的高端设备，为客户提供多种广告片及宣传片解决方案，在保持水准的前提下，降低制作费用，为企业提供前期编、导、拍、后期制作等全方位服务。</p><p><br/></p>', '1411797457', '1429116136', '0', '1', '');
INSERT INTO `kl_single` VALUES ('2', 'qiyewenhua', '企业文化', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司，是一家集影视制作、活动策划、装饰设计、平面设计、商业摄影创作于一体的专业文化传播有限公司。 知识爆炸的气流， 激荡了思想的风暴 ，一群思维裂变的狂人 和 一群大脑卓越的绅士，激荡在这中原大地 ，艺术、 哲学、现代、无厘…… 思辨集结着逆袭灵魂，灵魂追逐着金色的路，路， 一路向前。 河南金木水火文化传播有限公司，拥有一流的人才质量管理体系，近年来与诸多大公司建立了良好的信誉合作。本公司注重人才培养，艺术设计精湛，技术力量雄厚，汇聚了一批优秀的专业艺术和技术人才。 河南金木水火文化传播有限公司拥有专业而且实践经验丰富的策划团队；有多年成功经验的三维动画制作师、有大片制作经验的特效设计师、多媒体设计师等后期制作团队；省级专业摄像师、北京胶片广告摄像师及北京著名导演等拍摄团队精诚协作；完全满足不同客户的不同档次广告创作需求。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司是一支富有激情、精干而又充满活力的专业影视广告创作团队，新锐的创作思想，将数码技术与现代艺术进行完美结合，以专业的视角展示企业形象、传播产品信息，充分整合行业资源优势，以最大程度满足不同行业领域的客户需要，向社会各界提供一流的影视技术服务。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司凭借多年专业影视制作经验及多个央视级别大片制作经验，在业界赢得良好口碑，运用国际先进视频技术及行业内先进的高端设备，为客户提供多种广告片及宣传片解决方案，在保持水准的前提下，降低制作费用，为企业提供前期编、导、拍、后期制作等全方位服务。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司，是一家集影视制作、活动策划、装饰设计、平面设计、商业摄影创作于一体的专业文化传播有限公司。 知识爆炸的气流， 激荡了思想的风暴 ，一群思维裂变的狂人 和 一群大脑卓越的绅士，激荡在这中原大地 ，艺术、 哲学、现代、无厘…… 思辨集结着逆袭灵魂，灵魂追逐着金色的路，路， 一路向前。 河南金木水火文化传播有限公司，拥有一流的人才质量管理体系，近年来与诸多大公司建立了良好的信誉合作。本公司注重人才培养，艺术设计精湛，技术力量雄厚，汇聚了一批优秀的专业艺术和技术人才。 河南金木水火文化传播有限公司拥有专业而且实践经验丰富的策划团队；有多年成功经验的三维动画制作师、有大片制作经验的特效设计师、多媒体设计师等后期制作团队；省级专业摄像师、北京胶片广告摄像师及北京著名导演等拍摄团队精诚协作；完全满足不同客户的不同档次广告创作需求。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司是一支富有激情、精干而又充满活力的专业影视广告创作团队，新锐的创作思想，将数码技术与现代艺术进行完美结合，以专业的视角展示企业形象、传播产品信息，充分整合行业资源优势，以最大程度满足不同行业领域的客户需要，向社会各界提供一流的影视技术服务。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司凭借多年专业影视制作经验及多个央视级别大片制作经验，在业界赢得良好口碑，运用国际先进视频技术及行业内先进的高端设备，为客户提供多种广告片及宣传片解决方案，在保持水准的前提下，降低制作费用，为企业提供前期编、导、拍、后期制作等全方位服务。</p><p><br/></p>', '1427628989', '1429116127', '0', '1', '');
INSERT INTO `kl_single` VALUES ('3', 'allcate', '全部分类', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">联系我们</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司，是一家集影视制作、活动策划、装饰设计、平面设计、商业摄影创作于一体的专业文化传播有限公司。 知识爆炸的气流， 激荡了思想的风暴 ，一群思维裂变的狂人 和 一群大脑卓越的绅士，激荡在这中原大地 ，艺术、 哲学、现代、无厘…… 思辨集结着逆袭灵魂，灵魂追逐着金色的路，路， 一路向前。 河南金木水火文化传播有限公司，拥有一流的人才质量管理体系，近年来与诸多大公司建立了良好的信誉合作。本公司注重人才培养，艺术设计精湛，技术力量雄厚，汇聚了一批优秀的专业艺术和技术人才。 河南金木水火文化传播有限公司拥有专业而且实践经验丰富的策划团队；有多年成功经验的三维动画制作师、有大片制作经验的特效设计师、多媒体设计师等后期制作团队；省级专业摄像师、北京胶片广告摄像师及北京著名导演等拍摄团队精诚协作；完全满足不同客户的不同档次广告创作需求。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司是一支富有激情、精干而又充满活力的专业影视广告创作团队，新锐的创作思想，将数码技术与现代艺术进行完美结合，以专业的视角展示企业形象、传播产品信息，充分整合行业资源优势，以最大程度满足不同行业领域的客户需要，向社会各界提供一流的影视技术服务。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司凭借多年专业影视制作经验及多个央视级别大片制作经验，在业界赢得良好口碑，运用国际先进视频技术及行业内先进的高端设备，为客户提供多种广告片及宣传片解决方案，在保持水准的前提下，降低制作费用，为企业提供前期编、导、拍、后期制作等全方位服务。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司，是一家集影视制作、活动策划、装饰设计、平面设计、商业摄影创作于一体的专业文化传播有限公司。 知识爆炸的气流， 激荡了思想的风暴 ，一群思维裂变的狂人 和 一群大脑卓越的绅士，激荡在这中原大地 ，艺术、 哲学、现代、无厘…… 思辨集结着逆袭灵魂，灵魂追逐着金色的路，路， 一路向前。 河南金木水火文化传播有限公司，拥有一流的人才质量管理体系，近年来与诸多大公司建立了良好的信誉合作。本公司注重人才培养，艺术设计精湛，技术力量雄厚，汇聚了一批优秀的专业艺术和技术人才。 河南金木水火文化传播有限公司拥有专业而且实践经验丰富的策划团队；有多年成功经验的三维动画制作师、有大片制作经验的特效设计师、多媒体设计师等后期制作团队；省级专业摄像师、北京胶片广告摄像师及北京著名导演等拍摄团队精诚协作；完全满足不同客户的不同档次广告创作需求。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司是一支富有激情、精干而又充满活力的专业影视广告创作团队，新锐的创作思想，将数码技术与现代艺术进行完美结合，以专业的视角展示企业形象、传播产品信息，充分整合行业资源优势，以最大程度满足不同行业领域的客户需要，向社会各界提供一流的影视技术服务。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; white-space: normal; color: rgb(134, 134, 134); font-family: Simsun; font-size: 12px; line-height: 24px; text-indent: 24px; background-color: rgb(255, 255, 255);\">河南金木水火文化传播有限公司凭借多年专业影视制作经验及多个央视级别大片制作经验，在业界赢得良好口碑，运用国际先进视频技术及行业内先进的高端设备，为客户提供多种广告片及宣传片解决方案，在保持水准的前提下，降低制作费用，为企业提供前期编、导、拍、后期制作等全方位服务。</p><p><br/></p>', '1427629071', '1433063524', '0', '1', 'index');
